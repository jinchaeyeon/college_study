package a;
import java.util.Scanner;

public class number{
	public static void main(String[] args){
		
		Scanner s = new Scanner(System.in);
		
		System.out.print("Input number 1 ?");
		int n1 = s.nextInt();
			
		System.out.print("Input number 2 ?");
		int n2 = s.nextInt();

		int count = 0;
		int sum = 0;
		int a = 0;
		
		for(int d = n1; d<n2+1; d++) {
			int answer = 0;
			for(int i= 1; i<d+1; i++) {
				a = d%i;
			
				if(i != 1 && a == 0 && i != d){
					answer = 1;
					break;
				}
			}
			
			if(answer == 0) {
				count++;
				sum = sum + d;
			}
		}
		
		System.out.print("Count = " + count + ", Sum = " + sum);
	}
}