package a;
import java.util.Scanner;

public class Many {
	public static void main(String args[]) {
		
		System.out.print("Input String ?");
		Scanner s = new Scanner(System.in);
		
		java.lang.String text = s.next();
		String a = "";

		for(int i = 0; i<text.length(); i++) {
			char e = text.charAt(i);
			if(Character.isUpperCase(e)) {
				a= a+toLowerCase(e);
			}
			else {
				a = a+e;
			}
		}
		
		String [] st = a.split("");
		int [] c = new int [50];
		String [] sr = new String [50];
		int k1 = 0;
		int k2 = 0;
		int count=1;
		int count2=0;
		
		sr[0] = st[0];
		
		for(int j=0; j<st.length; j++) {
			for(int k=j+1; k<st.length; k++) {
				if(st[j].equals(st[k])) {
					count++;
				}
				
				for(int ee = 1; ee<sr.length; ee++) {
					if(sr[j].equals(st[ee])) {
						count2++;
					}
				}
			}
			
			if(count != 0 && count2==0) {
				c[k1] = count;
				k1++;
				sr[k2] = st[j];
				k2++;
			}
			
			count = 1;
			count2= 0;
		}
		for(int d = 0; d<sr.length; d++) {
			System.out.print(sr[d]+" ");
		}
		
		for(int d = 0; d<c.length; d++) {
			System.out.print(c[d]+" ");
		}
	}
	
	public static char toLowerCase(char e) {
		return Character.toLowerCase(e);
	}
	

}
