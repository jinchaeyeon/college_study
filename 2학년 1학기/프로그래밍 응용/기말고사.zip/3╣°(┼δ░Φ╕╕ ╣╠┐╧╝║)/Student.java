package a;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Student {

	public static void main(String[] args) throws IOException {
		
		Scanner s = new Scanner(System.in);

		List list = new List();

		while(true) {
			System.out.print("1. Input, 2. Delete, 3. Modify, 4. Summary, 5. print, 6. Load file, 7. Exit ");
			int n = s.nextInt();
			
			switch(n){
				case 1 : 
					list.input();
					break;
				case 2:
					list.delete();
					break;
				case 3: 
					list.Modify();
					break;
				case 4:
					
				case 5:
					list.print();
					break;
				case 6:
					list.txtinput();
					break;
			}
			if(n==7){
				break;
			}
		}
	}
}

class Node{
	protected String id, name, kor, eng, math;
	protected Node next;
    
    public Node(String id, String name, String kor, String eng, String math,Node next) {
        setId(id);
        setname(name);
        setkor(kor);
        seteng(eng);
        setmath(math);
        setNext(next);
    }
    
    public String getId() {return id;}
    public void setId(String id) {this.id = id;}
    public String getname() {return name;}
    public void setname(String name) {this.name = name;}
    public String getkor() {return kor;}
    public void setkor(String kor) {this.kor = kor;}
    public String geteng() {return eng;}
    public void seteng(String eng) {this.eng = eng;}
    public String getmath() {return math;}
    public void setmath(String math) {this.math = math;}
    public Node getNext() {return next;}
    public void setNext(Node next) {this.next = next;} 
}

class List{
	protected Node head;
	int size;
	Scanner s = new Scanner(System.in);
	
	public List() {
		head = new Node(null,null,null,null,null,null);
		size = 0;
	}
	
	public boolean isEmply() {
		return head == head.getNext();
	}
	
	public void input() {
		System.out.print("Input (Id,name,kor,eng,math) ? ");

		String line = s.nextLine();
		String[] st = line.split(",");
		Node e = head;
		int count = 0;
		int count2 = size;
				
		if(size == 0) {
			head.setNext(new Node(st[0],st[1],st[2],st[3],st[4],null));
			size++;
			System.out.println("> OK");
		}
		else {
			count = size;
			Node f = head;
			while(count != 0) {
				f = f.getNext();
				count --;
			}
			f.setNext(new Node(st[0],st[1],st[2],st[3],st[4],null));
			f = f.getNext();
			size++;
			System.out.println("> OK");
		}
	}
	
	public void txtinput() throws IOException {
		System.out.print("Input filename?");
		String f1 = s.next();
		File file = new File(f1);
		
		if(file.exists()){
			System.out.println("Loaded from objects.txt");
			FileReader filereader = new FileReader(file);
			BufferedReader br = new BufferedReader(filereader);
			String line = "";

			while((line = br.readLine()) != null) {
				String[] st = line.split(",");
				if(size == 0) {
					head.setNext(new Node(st[0],st[1],st[2],st[3],st[4],null));
					size++;
				}
				else {
					int count2 = size;
					Node f = head;
					while(count2 != 0) {
						f = f.getNext();
						count2 --;
					}
					f.setNext(new Node(st[0],st[1],st[2],st[3],st[4],null));
					f = f.getNext();
					size++;
				}
			}
		}
	}
	
	public void print() {
		Node p = head.getNext();
		String Grade ="";
		while(p != null) {
			int avr = (Integer.parseInt(p.getkor()) + Integer.parseInt(p.getmath()) + Integer.parseInt(p.geteng()))/3;
			if(avr>=90) {
				Grade = "A";
			}
			else if(avr<90 && avr>=80) {
				Grade = "B";
			}
			else if(avr<80&& avr>=70) {
				Grade = "C";
			}
			else if(avr<70&&avr>=60) {
				Grade = "D";
			}
			else {
				Grade = "F";
			}
			System.out.println("[	" +p.getId() + "] [" + p.getname()+"	] score[ " + p.getkor()+ "," + p.geteng() + "," + p.getmath()+"] Average[" + avr+"] Grade["+Grade+"]");
			p = p.getNext();
		}
	}
	
	public void delete() {
		System.out.print("Input (ID) ?");
		String id = s.next();
		Node front = search(id);
		Node f = head;
		if(id.equals(f.getId())) {
			f = f.getNext();
			size--;
			System.out.println("OK");
		}
		else {
			Node t = front.getNext();
			front.setNext(t.getNext());
			t.setNext(null);
			size--;
			System.out.println("OK");
		}
	}
	
	public Node search(String id) {
		Node cur = head;
		Node pre = head;

		boolean f = false;
		
		while(cur != null) {
			pre = cur;
			if(cur.getNext() == null) {
				break;
			}
			cur = cur.getNext();
			if(cur.getId().equals(id)) {
				f = true;
				break;
			}
		}
		
		if(f == true) {
			return pre;
		}
		else {
			return null;
		}
	}
	
	public void Modify() {
		System.out.print("Input (Id,kor,eng,math) ? ");
		String line = s.nextLine();
		String[] st = line.split(",");
		Node front = search(st[0]);
		
		front.getNext().setkor(st[1]);
		front.getNext().seteng(st[2]);
		front.getNext().setmath(st[3]);
	}
}
