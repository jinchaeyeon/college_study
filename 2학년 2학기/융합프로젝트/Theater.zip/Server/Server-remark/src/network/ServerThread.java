package network;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import database.DAO.*;

import network.Protocol;

public class ServerThread extends Thread {

    private int ID;
    private Socket socket;
    private Connection conn;
    private Protocol p;
    private IO io;

    // 스레드 생성자
    public ServerThread(Socket socket, Connection conn) throws IOException {
        ID = socket.getPort();
        this.socket = socket;
        this.conn = conn;
        io = new IO(socket);
    }

    // 실행
    @Override
    public void run() {
        while (true) {
            try {
                p = io.read();
                handle(p);
            } catch (Exception e) {
                this.stop();
            }
        }
    }

    // 기능별 서버 핸들러
    public void handle(Protocol p) throws Exception {
        int packetType = p.getType();

        switch (packetType) {
            case Protocol.TYPE1_LOGIN_REQ: //로그인
                String[] s = (String[]) p.getBody();
                String SQL = "SELECT user_section FROM USERS WHERE user_id = ?";
                PreparedStatement pstmt = null;
                ResultSet rs = null;

                pstmt = conn.prepareStatement(SQL);
                pstmt.setString(1, s[0]);
                rs = pstmt.executeQuery();
                rs.next();

                Protocol sndData = new Protocol(Protocol.TYPE2_LOGIN_RES);
                sndData.setCode(Protocol.T2_CD1_SUCCESS);
                sndData.setBody(rs.getInt(1));
                io.send(sndData);
                break;

            case Protocol.TYPE3_REGISTER_REQ: // 등록
                io.send(registerReq(p));
                break;

            case Protocol.TYPE5_VIEW_REQ: // 조회
                io.send(viewReq(p));
                break;
            case Protocol.TYPE7_UPDATE_REQ: // 업데이트
                io.send(updateReq(p));
                break;
            case Protocol.TYPE9_DELETE_REQ: // 삭제
                io.send(deleteReq(p));
                break;
            case Protocol.TYPE11_CHECK_REQ: // 체크
                io.send(checkReq(p));
                break;
            case Protocol.TYPE13_LOGOUT_REQ: // 로그아웃
                logoutReq(p);
                break;
        }
    }

    public static Protocol viewReq(Protocol protocol) {
        Protocol sndData5 = new Protocol(Protocol.TYPE6_VIEW_RES);
        switch (protocol.getCode()) {
            case Protocol.T5_CD0_USER: // 유저 조회
                String id = (String) protocol.getBody();
                ArrayList<String> user = InquiryDAO.inquiryUsers(id);
                String[] userinfo = new String[user.size()];
                for (int i = 0; i < userinfo.length; i++)
                    userinfo[i] = user.get(i);
                sndData5.setBody(userinfo);
                return sndData5;

            case Protocol.T5_CD1_THEATER: // 상영관 조회
                ArrayList<String> theaterNameList = InquiryDAO.theaterNameList();
                String[] theater = new String[theaterNameList.size()];
                for (int i = 0; i < theater.length; i++)
                    theater[i] = theaterNameList.get(i);
                sndData5.setBody(theater);
                return sndData5;

            case Protocol.T5_CD2_THEATERINFO: // 상영관 정보 조회
                String thname = (String) protocol.getBody();
                ArrayList<String> thinfo = InquiryDAO.theaterInfo(thname);
                String[] thInfo = new String[thinfo.size()];
                for (int i = 0; i < thInfo.length; i++)
                    thInfo[i] = thinfo.get(i);
                sndData5.setBody(thInfo);
                return sndData5;

            case Protocol.T5_CD3_SCHEDULE: // 상영 시간표 조회
                String[] s3 = (String[]) protocol.getBody();
                ArrayList<String> schedule = InquiryDAO.showAllShowing(s3);
                String[] schedules = new String[schedule.size()];
                for (int i = 0; i < schedules.length; i++)
                    schedules[i] = schedule.get(i);
                sndData5.setBody(schedules);
                return sndData5;

            case Protocol.T5_CD4_SEAT: // 좌석조회
                String[] s4 = (String[]) protocol.getBody();
                ArrayList<String> seatInfo = InquiryDAO.showSeat(s4);
                String[] seats = new String[seatInfo.size()];
                for (int i = 0; i < seats.length; i++)
                    seats[i] = seatInfo.get(i);
                sndData5.setBody(seats);
                return sndData5;

            case Protocol.T5_CD5_MOVIELIST: // 영화 조회
                int state = (int) protocol.getBody();
                ArrayList<String> list = InquiryDAO.MovTitle(state);
                String[] movie = new String[list.size()];
                for (int i = 0; i < movie.length; i++)
                    movie[i] = list.get(i);
                sndData5.setBody(movie);
                return sndData5;

            case Protocol.T5_CD6_MOVIEINFOMATION: // 영화 정보 조회
                String s6 = (String) protocol.getBody();
                ArrayList<String> movieInfo = InquiryDAO.selectMovieInfo(s6);
                String[] movieInformation = new String[movieInfo.size()];
                for (int i = 0; i < movieInformation.length; i++)
                    movieInformation[i] = movieInfo.get(i);

                sndData5.setBody(movieInformation);
                return sndData5;

            case Protocol.T5_CD7_TICKETING: // 예매 조회
                String[] s7 = (String[]) protocol.getBody();
                String userid = s7[0];
                String mvname = s7[1];
                ArrayList<String> ticketing = TicketingDAO.selectMyTicket(userid, mvname);
                String[] mytickets = new String[ticketing.size()];
                for (int i = 0; i < mytickets.length; i++)
                    mytickets[i] = ticketing.get(i);
                sndData5.setBody(mytickets);
                return sndData5;

            case Protocol.T5_CD9_REVIEW: // 리뷰 조회
                String title = (String) protocol.getBody();
                ArrayList<String> reviewContents = ReviewsDAO.showReview(title);
                String[] review = new String[reviewContents.size()];
                for (int i = 0; i < review.length; i++)
                    review[i] = reviewContents.get(i);
                sndData5.setBody(review);
                return sndData5;

            case Protocol.T5_CD10_MOVIES_STAT: // 영화 통계 조회
                String title4stat = (String) protocol.getBody();
                ArrayList<String> mvstat = StatsDAO.movieStat(title4stat);
                String[] mvstatInfo = new String[mvstat.size()];
                for (int i = 0; i < mvstatInfo.length; i++)
                    mvstatInfo[i] = mvstat.get(i);
                sndData5.setBody(mvstatInfo);
                return sndData5;

            case Protocol.T5_CD11_THEATERS_STAT: //영화관 통계 조회
                String theaterName = (String) protocol.getBody();
                ArrayList<String> theaterStatsArrayList = StatsDAO.theaterStats(theaterName);
                //String배열로 바꾸기
                String[] theaterStatsStringArray = new String[theaterStatsArrayList.size()];
                for (int i = 0; i < theaterStatsStringArray.length; i++)
                    theaterStatsStringArray[i] = theaterStatsArrayList.get(i);
                sndData5.setBody(theaterStatsStringArray);
                return sndData5;

            case Protocol.T5_CD12_TOTALPRICE: // 총 금액 조회
                String[] s12 = (String[]) protocol.getBody();
                int total = TicketingDAO.totalPrice(s12);
                sndData5.setBody(String.valueOf(total));
                return sndData5;

            case Protocol.T5_CD13_TOTALSTAR: // 총 별점 조회
                String mvtitle = (String) protocol.getBody();
                double totalstar = StatsDAO.star(mvtitle);
                sndData5.setBody(String.valueOf(String.format("%.2f", totalstar)));
                return sndData5;
        }
        return protocol;
    }

    public static Protocol registerReq(Protocol protocol) {
        Protocol sndData3 = new Protocol(Protocol.TYPE4_REGISTER_RES);
        switch (protocol.getCode()) {
            case Protocol.T3_CD0_USER:
               // String[] s0 = (String[]) protocol.getBody();
                int signUpResult = ManagementDAO.insertUser((String[]) protocol.getBody());
                sndData3.setCode(signUpResult);
                return sndData3;
            case Protocol.T3_CD1_THEATER:
                String[] s1 = (String[]) protocol.getBody();
                int theaterResult = ManagementDAO.insertTheater(s1);
                sndData3.setCode(theaterResult);
                return sndData3;
            case Protocol.T3_CD2_SCREENHALL:
                String[] s2 = (String[]) protocol.getBody();
                int scrResult = ManagementDAO.insertScreenHall(s2);
                sndData3.setCode(scrResult);
                return sndData3;
            case Protocol.T3_CD3_SHOWING:
                String[] s3 = (String[]) protocol.getBody();
                int showResult = ManagementDAO.insertShowing(s3);
                sndData3.setCode(showResult);
                return sndData3;
            case Protocol.T3_CD4_TICKETPRICES:
                String[] s4 = (String[]) protocol.getBody();
                int priceResult = ManagementDAO.insertTicketPrice(s4);
                sndData3.setCode(priceResult);
                return sndData3;
            case Protocol.T3_CD5_MOVIE:
                String[] s5 = (String[]) protocol.getBody();
                int movieupResult = ManagementDAO.insertMovie(s5);
                sndData3.setCode(movieupResult);
                return sndData3;
            case Protocol.T3_CD6_TICKETING:
                String[] s6 = (String[]) protocol.getBody();
                int ticketingResult = TicketingDAO.insertTicketing(s6);
                sndData3.setCode(ticketingResult);
                return sndData3;
            case Protocol.T3_CD7_PAYMENT:
                String[] s7 = (String[]) protocol.getBody();
                int paymentResult = PaymentsDAO.doPay(s7);
                sndData3.setCode(paymentResult);
                return sndData3;
            case Protocol.T3_CD8_REVIEW:
                String[] s8 = (String[]) protocol.getBody();
                int reviewResult = ReviewsDAO.insertReview(s8);
                sndData3.setCode(reviewResult);
                return sndData3;
        }
        return sndData3;
    }

    public static Protocol updateReq(Protocol protocol) throws SQLException, ClassNotFoundException {
        Protocol sndData7 = new Protocol(Protocol.TYPE8_UPDATE_RES);
        switch (protocol.getCode()) {
            case Protocol.T7_CD0_CURRENTMOVIE:
                sndData7.setCode(ManagementDAO.updateMovieState());
                return sndData7;

            case Protocol.T7_CD1_THEATHERNAME: //영화관 이름 수정
                String[] s1 = (String[]) protocol.getBody();
                sndData7.setCode(ManagementDAO.updateTheaterName(s1));
                return sndData7;

            case Protocol.T7_CD2_THEATHERLOCATION: //영화관 위치 수정
                String[] s2 = (String[]) protocol.getBody();
                sndData7.setCode(ManagementDAO.updateTheaterLocation(s2));
                return sndData7;

            case Protocol.T7_CD3_SCREENHALLCOUNT: //영화관 상영관 수 수정
                String[] s3 = (String[]) protocol.getBody();
                sndData7.setCode(ManagementDAO.updateTheaterScreenhallNum(s3));
                return sndData7;
        }
        return sndData7;
    }

    public static Protocol deleteReq(Protocol protocol) throws SQLException {
        Protocol sndData9 = new Protocol(Protocol.TYPE10_DELETE_RES);
        switch (protocol.getCode()) {
            case Protocol.T9_CD0_TICKETING:
                String[] s0 = (String[]) protocol.getBody();
                String userid = s0[0];
                String title = s0[1];
                int delTkResult = TicketingDAO.cancelTicket(userid, title);
                sndData9.setCode(delTkResult);
                return sndData9;

            case Protocol.T9_CD1_PAYMENT:
                String[] s1 = (String[]) protocol.getBody();
                int refundResult = PaymentsDAO.refund(s1);
                sndData9.setCode(refundResult);
                return sndData9;

            case Protocol.T9_CD2_TEATHER:
                String s2 = (String) protocol.getBody();
                sndData9.setCode(ManagementDAO.deleteTheater(s2)); //영화관 이름
                return sndData9;

            case Protocol.T9_CD3_SCREENHALL:
                String s3 = (String) protocol.getBody();
                sndData9.setCode(ManagementDAO.deleteScreenhall(s3)); //상영관 id
                return sndData9;

            case Protocol.T9_CD4_REVIEW:
                String[] s4 = (String[]) protocol.getBody();
                sndData9.setCode(ReviewsDAO.deleteReview(s4));
                return sndData9;

            case Protocol.T9_CD5_SCHEDULE:
                sndData9.setCode(ManagementDAO.deleteShowing());
                return sndData9;

            case Protocol.T9_CD6_MOVIE:
                String targetTitle = (String) protocol.getBody();
                sndData9.setCode(ManagementDAO.deleteMovie(targetTitle));
                return sndData9;
        }
        return sndData9;
    }

    public static Protocol checkReq(Protocol protocol) throws SQLException, ClassNotFoundException {
        Protocol sndData11 = new Protocol(Protocol.TYPE12_CHECK_RES);
        switch (protocol.getCode()) {
            case Protocol.T11_CD0_USER:
            case Protocol.T11_CD1_PASSWD:
                String[] s11 = (String[]) protocol.getBody();
                Class.forName("oracle.jdbc.driver.OracleDriver");
                String url = "jdbc:oracle:thin:@localhost:1521:xe";
                String user = "MRS_MANAGER";
                String pw = "7777";
                Connection conn = DriverManager.getConnection(url, user, pw);

                String SQL = "SELECT COUNT(*) FROM users where user_id = ?";
                PreparedStatement pstmt = conn.prepareStatement(SQL);
                pstmt.setString(1, s11[0]);
                ResultSet rs = pstmt.executeQuery();
                rs.next();
                int isUser = rs.getInt(1);

                if (protocol.getCode() == Protocol.T11_CD0_USER) {
                    if (isUser == 1) {
                        sndData11.setCode(Protocol.T12_CD1_SUCCESS);
                    } else {
                        sndData11.setCode(Protocol.T2_CD0_FAIL);
                    }
                } else if (protocol.getCode() == Protocol.T11_CD1_PASSWD) {
                    SQL = "SELECT COUNT(*) FROM USERS WHERE user_id = ? and user_pwd = ?";
                    pstmt = conn.prepareStatement(SQL);
                    pstmt.setString(1, s11[0]);
                    pstmt.setString(2, s11[1]);
                    rs = pstmt.executeQuery();
                    rs.next();
                    int isCorrect = rs.getInt(1);
                    if (isUser == 1 && isCorrect == 1) {
                        sndData11.setCode(Protocol.T12_CD1_SUCCESS);
                    } else {
                        sndData11.setCode(Protocol.T2_CD0_FAIL);
                    }
                }
                return sndData11;
            case Protocol.T11_CD2_BALANCE:
                String[] s2 = (String[]) protocol.getBody();
                int check2 = PaymentsDAO.checkAcc(s2);
                sndData11.setCode(check2);
                return sndData11;
        }
        return sndData11;

    }

    public static void logoutReq(Protocol protocol) throws IOException {
        int s2 = (int) protocol.getBody();
        Server.remove(s2);
    }

    public IO getIo() {
        return io;
    }

    public void setIo(IO io) {
        this.io = io;
    }

    public int getID() {
        return ID;
    }

    public void setID(int iD) {
        ID = iD;
    }

}