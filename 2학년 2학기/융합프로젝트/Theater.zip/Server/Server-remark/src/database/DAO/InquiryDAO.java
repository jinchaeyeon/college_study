package database.DAO;

import java.sql.*;
import java.util.ArrayList;

import database.DTO.*;
public class InquiryDAO
{
    public InquiryDAO() {
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
        } catch (ClassNotFoundException cnfe) {
            System.out.println("DB 드라이버 로딩 실패 :" + cnfe.toString());
        }
    }

    // 2.4.0 고객 정보 조회(예매한 영화 list)
    public static ArrayList<String> inquiryUsers(String ID)
    {
        ArrayList<String> userInfo = new ArrayList<>();


        Statement stmt = null;
        Connection conn = null;
        ResultSet rs = null;

        String SQL="SELECT user_name, phonenum, user_birthday FROM USERS WHERE user_id = '"+ID+"'";
        try {
            conn = DAOHandler.getConnection();
            stmt = conn.createStatement();
            rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                UsersDTO userDTO = new UsersDTO(rs.getString(1), rs.getString(2), rs.getDate(3));
                userInfo.add(userDTO.getName());
                userInfo.add(userDTO.getPhoneNum());
                userInfo.add(String.valueOf(userDTO.getBirthday()));
            }
            SQL = "SELECT DISTINCT TICKETING_MOVIE_NAME FROM TICKETING WHERE CUSTOMER_ID = '" + ID + "'";
            stmt = conn.createStatement();
            rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                String title = rs.getString(1);  userInfo.add(title);
            }

        } catch (SQLException sqle) {
            System.out.println("SELECT문에서 예외 발생");
            sqle.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
                throw new RuntimeException(e.getMessage());
            }
        }
        return userInfo;
    }

    // 2.1.1 영화관 이름 전체 조회
    public static ArrayList<String> theaterNameList()
    {
        ArrayList<String> thNames = new ArrayList<>();
        Statement stmt = null;
        Connection conn = null;
        ResultSet rs = null;
        String SQL = "SELECT THEATER_NAME FROM THEATERS";
        try {
            conn = DAOHandler.getConnection();
            stmt = conn.createStatement();
            rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                String thName = rs.getString(1);
                thNames.add(thName);
            }
        } catch (SQLException sqle) {
            System.out.println("SELECT문에서 예외 발생");
            sqle.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
                throw new RuntimeException(e.getMessage());
            }
        }
        return thNames;
    }

    // 2.1.2 영화관 정보 조회(총 상영관 수, 위치, 가격정보)
    public static ArrayList<String> theaterInfo(String theaterName)
    {
        ArrayList<String> thInfo = new ArrayList<>();

        Connection conn = null;
        Statement stmt = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String SQL = "SELECT screenhall_num, theater_location FROM THEATERS\n" +
                "WHERE theater_name = \'"+ theaterName +"\'";
        try {
            conn = DAOHandler.getConnection();
            stmt = conn.createStatement();
            rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                int scrNum = rs.getInt(1);          thInfo.add(String.valueOf(scrNum));
                String location = rs.getString(2);    thInfo.add(location);
            }

            SQL = "SELECT price FROM TICKET_PRICES WHERE THEATER_ID = (SELECT THEATER_ID FROM THEATERS WHERE THEATER_NAME = '" + theaterName + "') and ticket_section = ? and ticket_age_section = ?";
            pstmt = conn.prepareStatement(SQL);
            for(int time = 0; time < 3; time++)
            {
                for(int age = 0; age < 3; age++)
                {
                    pstmt.setInt(1, time);
                    pstmt.setInt(2, age);
                    rs = pstmt.executeQuery();
                    rs.next();  int price = rs.getInt(1);
                    System.out.println(price);
                    thInfo.add(String.valueOf(price));
                }
            }
        } catch (SQLException sqle) {
            System.out.println("SELECT문에서 예외 발생");
            sqle.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
                throw new RuntimeException(e.getMessage());
            }
        }
        return thInfo;
    }

    // 영화 상태(현재상영작, 상영예정작)에 따른 제목 조회
    public static ArrayList<String> MovTitle(int state)
    {
        ArrayList<String> titleList = new ArrayList<>();
        Statement stmt = null;
        Connection conn = null;
        ResultSet rs = null;
        String SQL = "SELECT TITLE FROM MOVIES WHERE MOVIE_STATE = " + state;
        try {
            conn = DAOHandler.getConnection();
            stmt = conn.createStatement();
            rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                String title = rs.getString(1);
                titleList.add(title);
            }
        } catch (SQLException sqle) {
            System.out.println("SELECT문에서 예외 발생");
            sqle.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
                throw new RuntimeException(e.getMessage());
            }
        }
        return titleList;
    }
    
    // 2.2 영화 조회
    public static ArrayList<String> selectMovieInfo(String title){
        ArrayList<String> movieInfo = new ArrayList<>();
        Statement stmt = null;
        Connection conn = null;
        ResultSet rs = null;
        String SQL = "SELECT * FROM MOVIES WHERE TITLE = \'" + title + "\'";
        try {
            conn = DAOHandler.getConnection();
            stmt = conn.createStatement();
            rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                movieInfo.add(title);
                int runningtime = rs.getInt(3); movieInfo.add(String.valueOf(runningtime));
                String director = rs.getString(4); movieInfo.add(director);
                String cast = rs.getString(5); movieInfo.add(cast);
                int grade = rs.getInt(6);   movieInfo.add(String.valueOf(grade));
                String synopsis = rs.getString(7);  movieInfo.add(synopsis);
                double star = rs.getDouble(8);  movieInfo.add(String.format("%.2f", star));
                String poster = rs.getString(12);   movieInfo.add(poster);
                String stealcut1 = rs.getString(13); movieInfo.add(stealcut1);
                String stealcut2 = rs.getString(17); movieInfo.add(stealcut2);
                String stealcut3 = rs.getString(18); movieInfo.add(stealcut3);
                String teaser = rs.getString(14);   movieInfo.add(teaser);
                double reservation = rs.getDouble(15); movieInfo.add(String.valueOf(reservation));
                double cancel = rs.getDouble(16); movieInfo.add(String.valueOf(cancel));
                int audience = rs.getInt(9);    movieInfo.add(String.valueOf(audience));
            }
        } catch (SQLException sqle) {
            System.out.println("SELECT문에서 예외 발생");
            sqle.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
                throw new RuntimeException(e.getMessage());
            }
        }
        return movieInfo;
    }

    // 2.3 상영시간표 조회하기
    public static ArrayList<String> showAllShowing(String[] s){
        ArrayList<String> showings = new ArrayList<>();
        Statement stmt = null;
        Connection conn = null;
        ResultSet rs = null;

        String SQL = "SELECT DISTINCT THEATERS.theater_name, MOVIES.poster, MOVIES.title, SCREENHALLS.screenhall_name, MOVIES.runningtime, SCREENHALLS.limit\n" +
                "FROM SHOWING\n" +
                "INNER JOIN THEATERS ON THEATERS.theater_id = SHOWING.showing_THEATER_id\n" +
                "INNER JOIN SCREENHALLS ON SCREENHALLS.screenhall_id = SHOWING.showing_screenhall_id\n" +
                "INNER JOIN MOVIES ON SHOWING.showing_movie_id = MOVIES.movie_id\n" +
                "WHERE THEATER_NAME = \'" + s[0] + "\' and showing_starttime > to_timestamp('" + s[1] + " 00:00:00" +
                "') and showing_starttime < to_timestamp('" + s[1] + " 23:59:59')";
        System.out.println(SQL);

        try {
            conn = DAOHandler.getConnection();
            stmt = conn.createStatement();
            rs = stmt.executeQuery(SQL);

            while (rs.next()) {
                String showingInfo = "";
                String theater_name = rs.getString(1);  showingInfo += theater_name + "@";
                String poster = rs.getString(2); showingInfo += poster + "@";
                String title = rs.getString(3); showingInfo += title + "@";
                String screenhall_name = rs.getString(4); showingInfo += screenhall_name + "@";
                int runningTime = rs.getInt(5); showingInfo += runningTime + "@";
                int limit = rs.getInt(6); showingInfo += limit + "@";

                String SQL2 = "SELECT showing_starttime FROM SHOWING INNER JOIN THEATERS ON THEATERS.THEATER_ID=SHOWING.SHOWING_THEATER_ID \n" +
                        "INNER JOIN SCREENHALLS ON SCREENHALLS.SCREENHALL_ID=SHOWING.SHOWING_SCREENHALL_ID WHERE THEATERS.THEATER_NAME = '" + s[0] + "'\n" +
                        "AND showing_starttime > to_timestamp('" + s[1]+ " 00:00:00') AND showing_starttime < to_timestamp('" + s[1] + " 23:59:59')\n" +
                        "AND SCREENHALLS.screenhall_name = '" + screenhall_name + "'";
                System.out.println(SQL2);
                Statement stmt2 = conn.createStatement();
                ResultSet rs2 = stmt2.executeQuery(SQL2);
                while (rs2.next())
                {
                    Timestamp ts = rs2.getTimestamp(1); //상영시간
                    showingInfo += ts + "@";
                    System.out.println(showingInfo);
                }
                showings.add(showingInfo);
            }
        } catch (SQLException sqle) {
            System.out.println("SELECT문에서 예외 발생");
            sqle.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
                throw new RuntimeException(e.getMessage());
            }
        }
        return showings;
    }

    // 좌석 조회하기 (이거 상영 시간 정보도 받아야할듯 ㅜ)
    public static ArrayList<String> showSeat(String[] s)
    {
        ArrayList<String> seat = new ArrayList<>();
        Statement stmt = null;
        Connection conn = null;
        ResultSet rs = null;

        String SQL = "SELECT seat_row, seat_col FROM SEATS WHERE seat_state = 1 and \n" +
                "seat_theater_id IN (SELECT theater_id FROM THEATERS WHERE theater_name = '" + s[1] + "') and \n" +
                "seat_screenhall_id IN (SELECT screenhall_id FROM SCREENHALLS WHERE screenhall_name = '" + s[0] + "') and\n" +
                "seat_time IN to_timestamp('" + s[2] + "')";
        System.out.println(SQL);
        try {
            conn = DAOHandler.getConnection();
            stmt = conn.createStatement();
            rs = stmt.executeQuery(SQL);

            while (rs.next()) {
                int row = rs.getInt(1);
                int col = rs.getInt(2);
                String seatInfo = row + " " + col;
                System.out.println(seatInfo);
                seat.add(seatInfo);
            }
        } catch (SQLException sqle) {
            System.out.println("SELECT문에서 예외 발생");
            sqle.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
                throw new RuntimeException(e.getMessage());
            }
        }
        return seat;
    }
}
