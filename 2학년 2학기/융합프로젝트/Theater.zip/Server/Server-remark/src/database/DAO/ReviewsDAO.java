package database.DAO;

import database.DTO.ReviewsDTO;
import network.Protocol;

import java.sql.*;
import java.util.ArrayList;

public class ReviewsDAO
{
    public ReviewsDAO() {
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
        } catch (ClassNotFoundException cnfe) {
            System.out.println("DB 드라이버 로딩 실패 :" + cnfe.toString());
        }
    }

    // 2.7.1 평점 및 리뷰 등록
    public static int insertReview(String[] s)
    {
        Connection conn = null;
        PreparedStatement pstmt = null;

        ReviewsDTO revDTO = new ReviewsDTO(s[0], s[1], s[2], Integer.parseInt(s[3]));
        String SQL = "INSERT INTO REVIEWS(REVIEW_USER_ID, REVIEW_MOVIE_NAME, REVIEW, STAR) VALUES(?, ?, ?, ?)";
        try {
            conn = DAOHandler.getConnection();
            pstmt = conn.prepareStatement(SQL);

            pstmt.setString(1, revDTO.getUser_id()); //작성자 id
            pstmt.setString(2, revDTO.getTitle());   //영화 제목
            pstmt.setString(3, revDTO.getContent());    //리뷰 내용
            pstmt.setInt(4, revDTO.getStar());   //별점

            //리뷰 등록
            pstmt.executeUpdate();
            // 리뷰 별점 업데이트
            ManagementDAO.updateStars(revDTO.getTitle());

            return  Protocol.T4_CD1_SUCCESS; //성공
        } catch (SQLException sqle) {
            sqle.printStackTrace();
            return Protocol.T4_CD0_FAIL;    //실패
        } finally {
            try {
                if (pstmt != null) {
                    pstmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
                throw new RuntimeException(e.getMessage());
            }
        }
    }

    // 2.7.2 영화별 리뷰 및 평점 조회
    public static ArrayList<String> showReview(String title){
        //리뷰 담을 ArrayList
        ArrayList<String> reviews = new ArrayList<>();

        Statement stmt = null;
        Connection conn = null;
        ResultSet rs = null;

        try {
            conn = DAOHandler.getConnection();
            stmt = conn.createStatement();

            //해당 영화를 리뷰를 작성한 유저의 id, 리뷰 내용 구하기
            String SQL = "SELECT review_user_id, review FROM REVIEWS WHERE REVIEW_MOVIE_NAME = '" + title + "'";
            rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                String id = rs.getString(1);    //작성자 id
                String content = rs.getString(2);   //리뷰 내용

                String info = id + "@" + content; //id와 리뷰 내용 합치기(@로 자르기)

                reviews.add(info);  //ArrayList에 담기
            }
        } catch (SQLException sqle) {
            System.out.println("SELECT문에서 예외 발생");
            sqle.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
                throw new RuntimeException(e.getMessage());
            }
        }
        return reviews; //리뷰내용 담은 ArrayList
    }

    // 2.7.3 평점 및 리뷰 삭제
    public static int deleteReview(String[] s)
    {
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;

        String id = s[0];
        String title = s[1];
        String content = s[2];

        try {
            conn = DAOHandler.getConnection();
            stmt = conn.createStatement();
            // 작성자와 내용으로 리뷰 조회
            String SQL = "SELECT review FROM REVIEWS WHERE review_user_id = '" + id + "' and review_movie_name = '" + title + "'";
            rs = stmt.executeQuery(SQL);
            while(rs.next())
            {
                // 내용이 같으면
                if(content.equals(rs.getString(1)))
                {
                    // 삭제하고,
                    SQL = "DELETE FROM REVIEWS WHERE review_user_id = '" + id + "' and review_movie_name = '" + title + "' and review = '" + content + "'";
                    stmt = conn.createStatement();
                    stmt.executeUpdate(SQL);
                    // 리뷰 별점 업데이트
                    ManagementDAO.updateStars(title);
                    return Protocol.T10_CD1_SUCCESS;
                }
            }
        } catch (SQLException sqle) {
            sqle.printStackTrace();
            return Protocol.T10_CD0_FAIL;
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
                throw new RuntimeException(e.getMessage());
            }
        }
        return Protocol.T10_CD0_FAIL;
    }

}