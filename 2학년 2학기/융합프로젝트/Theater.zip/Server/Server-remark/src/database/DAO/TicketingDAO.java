package database.DAO;

import network.Protocol;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Scanner;

public class TicketingDAO
{
    public static Scanner s = new Scanner(System.in);

    public TicketingDAO()
    {
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
        } catch (ClassNotFoundException cnfe) {
            System.out.println("DB 드라이버 로딩 실패 :" + cnfe.toString());
        }
    }

    // 2.5.1 영화 예매(트랜젝션을 써야겠군! 중단점 걸기!!)
    public static int insertTicketing(String[] s) {
        int ticketingSuccess = 5;
        Connection conn = null;
        Statement stmt = null;
        PreparedStatement pstmt = null;
        CallableStatement cstmt = null;
        ResultSet rs = null;
        int pub = Integer.parseInt(s[4]);
        int teen = Integer.parseInt(s[5]);
        int treat = Integer.parseInt(s[6]);

        System.out.println(pub + " " + teen + " " + treat);
        String SQL;
        try
        {
            conn = DAOHandler.getConnection();

            String id = s[0];
            String theater = s[1];

            conn.setAutoCommit(false);
            // 영화관 구하기
            SQL = "SELECT theater_id FROM THEATERS WHERE theater_name = '" + theater + "\'";
            pstmt = conn.prepareStatement(SQL);
            rs = pstmt.executeQuery();
            rs.next();
            String theaterid = rs.getString(1);
            System.out.println("영화관");
            rs.close();
            // 영화 구하기
            String movie = s[2];
            SQL = "SELECT movie_id FROM MOVIES WHERE title = '" + movie + "\'";
            pstmt = conn.prepareStatement(SQL);
            rs = pstmt.executeQuery();
            rs.next();
            int movieid = rs.getInt(1);

            rs.close();
            // 상영시간 받기
            String[] showingTimeStr = s[3].split(" ");
            String[] showingDate = showingTimeStr[0].split("-");
            String[] showingTimeArr = showingTimeStr[1].split(":");
            LocalDateTime showingTime = LocalDateTime.of(Integer.parseInt(showingDate[0]), Integer.parseInt(showingDate[1]),
                    Integer.parseInt(showingDate[2]), Integer.parseInt(showingTimeArr[0]), Integer.parseInt(showingTimeArr[1]));

            // 상영관 구하기
            SQL = "SELECT showing_screenhall_id FROM SHOWING \n" +
                    "WHERE showing_theater_id = ?\n" +
                    "and showing_movie_id = ?\n" +
                    "and showing_starttime = ?";
            pstmt = conn.prepareStatement(SQL);

            pstmt.setString(1, theaterid);
            pstmt.setInt(2, movieid);
            pstmt.setTimestamp(3, Timestamp.valueOf(showingTime));

            rs = pstmt.executeQuery();
            rs.next();
            String scrid = rs.getString(1);

            rs.close();
            for(int i = 0; i < pub; i++)
            {
                int price = 0;
                String seat = s[7+i];
                String[] seatRC = seat.split(" ");
                int row = Integer.parseInt(seatRC[0]);
                int col = Integer.parseInt(seatRC[1]);

                cstmt = conn.prepareCall("{? = call GET_PRICE(0, ?, ?)}");
                cstmt.registerOutParameter(1, Types.INTEGER);
                cstmt.setTimestamp(2, Timestamp.valueOf(showingTime));
                cstmt.setString(3, theater);
                cstmt.execute();
                price = cstmt.getInt(1);
                System.out.println(price);


                SQL = "SELECT seat_state FROM SEATS WHERE seat_theater_id = ? and seat_screenhall_id = ? and seat_time = ? and seat_row = ? and seat_col = ?";
                pstmt = conn.prepareStatement(SQL);
                pstmt.setString(1, theaterid);
                pstmt.setString(2, scrid);
                pstmt.setTimestamp(3, Timestamp.valueOf(showingTime));
                pstmt.setInt(4, row);
                pstmt.setInt(5, col);
                rs = pstmt.executeQuery();
                rs.next();
                int state = rs.getInt(1);
                rs.close();

                if (state == 0) {
                    SQL = "INSERT INTO TICKETING VALUES(?, ?, ?, ?, ?, ?, ?, ?)";
                    pstmt = conn.prepareStatement(SQL);
                    pstmt.setString(1, scrid);
                    pstmt.setString(2, id);
                    pstmt.setInt(3, row);
                    pstmt.setInt(4, col);
                    pstmt.setString(5, movie);
                    pstmt.setTimestamp(6, Timestamp.valueOf(showingTime));
                    pstmt.setString(7, theaterid);
                    pstmt.setInt(8, price);
                    pstmt.executeUpdate();

                    SQL = "UPDATE SEATS SET seat_state = 1 \n" +
                            "WHERE seat_theater_id = \'" + theaterid + "\' and seat_screenhall_id = \'" + scrid +
                            "\' and seat_time = to_timestamp(\'" + Timestamp.valueOf(showingTime) + "\') and seat_row = " + row + " and seat_col = " + col;
                    stmt = conn.prepareStatement(SQL);
                    stmt.executeUpdate(SQL);

                    ticketingSuccess = Protocol.T4_CD1_SUCCESS;
                } else
                    throw new SQLException("이선좌");
            }

            for(int i = 0; i < teen; i++)
            {
                int price = 0;
                String seat = s[7+ pub +i];
                String[] seatRC = seat.split(" ");
                int row = Integer.parseInt(seatRC[0]);
                int col = Integer.parseInt(seatRC[1]);
                System.out.println(row + " " + col);
                cstmt = conn.prepareCall("{? = call GET_PRICE(1, ?, ?)}");
                cstmt.registerOutParameter(1, Types.INTEGER);
                cstmt.setTimestamp(2, Timestamp.valueOf(showingTime));
                cstmt.setString(3, theater);
                cstmt.execute();
                price = cstmt.getInt(1);


                SQL = "SELECT seat_state FROM SEATS WHERE seat_theater_id = ? and seat_screenhall_id = ? and seat_time = ? and seat_row = ? and seat_col = ?";
                pstmt = conn.prepareStatement(SQL);
                pstmt.setString(1, theaterid);
                pstmt.setString(2, scrid);
                pstmt.setTimestamp(3, Timestamp.valueOf(showingTime));
                pstmt.setInt(4, row);
                pstmt.setInt(5, col);
                rs = pstmt.executeQuery();
                rs.next();
                int state = rs.getInt(1);
                rs.close();

                if (state == 0) {
                    SQL = "INSERT INTO TICKETING VALUES(?, ?, ?, ?, ?, ?, ?, ?)";
                    pstmt = conn.prepareStatement(SQL);
                    pstmt.setString(1, scrid);
                    pstmt.setString(2, id);
                    pstmt.setInt(3, row);
                    pstmt.setInt(4, col);
                    pstmt.setString(5, movie);
                    pstmt.setTimestamp(6, Timestamp.valueOf(showingTime));
                    pstmt.setString(7, theaterid);
                    pstmt.setInt(8, price);
                    pstmt.executeUpdate();

                    SQL = "UPDATE SEATS SET seat_state = 1 \n" +
                            "WHERE seat_theater_id = \'" + theaterid + "\' and seat_screenhall_id = \'" + scrid +
                            "\' and seat_time = to_timestamp(\'" + Timestamp.valueOf(showingTime) + "\') and seat_row = " + row + " and seat_col = " + col;
                    stmt = conn.prepareStatement(SQL);
                    stmt.executeUpdate(SQL);
                    ticketingSuccess = Protocol.T4_CD1_SUCCESS;

                } else
                    throw new SQLException("이선좌");
            }

            for(int i = 0; i < treat; i++)
            {
                int price = 0;
                String seat = s[7+ pub + teen + i];
                String[] seatRC = seat.split(" ");
                int row = Integer.parseInt(seatRC[0]);
                int col = Integer.parseInt(seatRC[1]);
                System.out.println(row + " " + col);
                cstmt = conn.prepareCall("{? = call GET_PRICE(2, ?, ?)}");
                cstmt.registerOutParameter(1, Types.INTEGER);
                cstmt.setTimestamp(2, Timestamp.valueOf(showingTime));
                cstmt.setString(3, theater);
                cstmt.execute();
                price = cstmt.getInt(1);


                SQL = "SELECT seat_state FROM SEATS WHERE seat_theater_id = ? and seat_screenhall_id = ? and seat_time = ? and seat_row = ? and seat_col = ?";
                pstmt = conn.prepareStatement(SQL);
                pstmt.setString(1, theaterid);
                pstmt.setString(2, scrid);
                pstmt.setTimestamp(3, Timestamp.valueOf(showingTime));
                pstmt.setInt(4, row);
                pstmt.setInt(5, col);
                rs = pstmt.executeQuery();
                rs.next();
                int state = rs.getInt(1);
                rs.close();

                if (state == 0) {
                    SQL = "INSERT INTO TICKETING VALUES(?, ?, ?, ?, ?, ?, ?, ?)";
                    pstmt = conn.prepareStatement(SQL);
                    pstmt.setString(1, scrid);
                    pstmt.setString(2, id);
                    pstmt.setInt(3, row);
                    pstmt.setInt(4, col);
                    pstmt.setString(5, movie);
                    pstmt.setTimestamp(6, Timestamp.valueOf(showingTime));
                    pstmt.setString(7, theaterid);
                    pstmt.setInt(8, price);
                    pstmt.executeUpdate();

                    SQL = "UPDATE SEATS SET seat_state = 1 \n" +
                            "WHERE seat_theater_id = \'" + theaterid + "\' and seat_screenhall_id = \'" + scrid +
                            "\' and seat_time = to_timestamp(\'" + Timestamp.valueOf(showingTime) + "\') and seat_row = " + row + " and seat_col = " + col;
                    stmt = conn.prepareStatement(SQL);
                    stmt.executeUpdate(SQL);

                    ticketingSuccess = Protocol.T4_CD1_SUCCESS;
                } else
                    throw new SQLException("이선좌");
            }
            System.out.println("성공적으로 예매되었습니다.");
            conn.commit();
        } catch (SQLException sqle) {
            ticketingSuccess = Protocol.T4_CD0_FAIL;
            sqle.printStackTrace();
            if(conn != null)
            {
                try {
                    conn.rollback();
                } catch(SQLException e){}
            }
        } finally {
            try {
                conn.setAutoCommit(true);
                if(rs!= null)
                {
                    rs.close();
                }
                if (pstmt != null) {
                    pstmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
                throw new RuntimeException(e.getMessage());
            }
        }
        return ticketingSuccess;
    }

    public static int totalPrice(String[] s)
    {
        Connection conn = null;
        CallableStatement cstmt = null;

        try
        {
            conn = DAOHandler.getConnection();
            int price;
            cstmt = conn.prepareCall("{? = call GET_TOTALPRICE(?, ?, ?, ?, ?)}");
            cstmt.registerOutParameter(1, Types.INTEGER);
            // 상영시간 받기
            String[] showingTimeStr = s[3].split(" ");
            String[] showingDate = showingTimeStr[0].split("-");
            String[] showingTimeArr = showingTimeStr[1].split(":");
            LocalDateTime showingTime = LocalDateTime.of(Integer.parseInt(showingDate[0]), Integer.parseInt(showingDate[1]),
                    Integer.parseInt(showingDate[2]), Integer.parseInt(showingTimeArr[0]), Integer.parseInt(showingTimeArr[1]));
            cstmt.setInt(2, Integer.parseInt(s[4]));
            cstmt.setInt(3, Integer.parseInt(s[5]));
            cstmt.setInt(4, Integer.parseInt(s[6]));
            cstmt.setTimestamp(5, Timestamp.valueOf(showingTime));
            cstmt.setString(6, s[1]);
            cstmt.execute();
            price = cstmt.getInt(1);
            return price;

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        } finally {
            try {
                conn.setAutoCommit(true);
                if (cstmt != null) {
                    cstmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
                throw new RuntimeException(e.getMessage());
            }
        }
        return 0;
    }
    // 2.5.2 영화 예매 취소(예매 테이블에서 데이터 삭제 후 좌석 풀어주기)
    public static int cancelTicket(String id, String title) throws SQLException {
        Connection conn = null;
        Statement stmt = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        String SQL;
        try {
            conn = DAOHandler.getConnection();
            conn.setAutoCommit(false);
            SQL = "SELECT seat_row, seat_col, seat_theater_id, seat_time FROM SEATS " +
                    "INNER JOIN TICKETING ON SEATS.seat_col = TICKETING.ticketing_seat_col and SEATS.seat_row = TICKETING.ticketing_seat_row " +
                    "WHERE SEATS.seat_state = 1 and TICKETING.customer_id = \'"+ id + "\' and TICKETING.ticketing_movie_name = \'" + title + "\'";
            stmt = conn.createStatement();
            rs = stmt.executeQuery(SQL);
            System.out.println(rs.toString());
            while(rs.next())
            {
                int row = rs.getInt(1);
                System.out.println(row);
                int col = rs.getInt(2);
                System.out.println(col);
                String thid = rs.getString(3);
                System.out.println(thid);
                Timestamp time = rs.getTimestamp(4);
                System.out.println(time);

                SQL = "UPDATE SEATS SET seat_state = 0 \n" +
                        "WHERE seat_theater_id = '" + thid +
                        "' and seat_time = to_timestamp('" + time +
                        "') and seat_row =" + row + " and seat_col = " + col;
                System.out.println(SQL);
                stmt = conn.createStatement();
                stmt.executeQuery(SQL);
            }

            SQL = "DELETE FROM TICKETING WHERE customer_id = ? and ticketing_movie_name = ?";
            pstmt = conn.prepareStatement(SQL);
            pstmt.setString(1, id);
            pstmt.setString(2, title);
            rs = pstmt.executeQuery();

            //conn.commit();
            System.out.println("성공적으로 취소되었습니다.");
            return Protocol.T10_CD1_SUCCESS;
        } catch (SQLException sqle) {
            conn.rollback();
            sqle.printStackTrace();
            return Protocol.T10_CD0_FAIL;
        } finally {
            try {
                conn.setAutoCommit(true);
                if (pstmt != null) {
                    pstmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
                throw new RuntimeException(e.getMessage());
            }
        }
    }

    // 예매 현황 조회하기
    public static ArrayList<String> selectMyTicket(String id, String title)
    {
        ArrayList<String> mytic = new ArrayList<>();
        Statement stmt = null;
        Connection conn = null;
        ResultSet rs = null;

        String SQL = "SELECT DISTINCT THEATERS.theater_name, SCREENHALLS.screenhall_name, TICKETING.ticketing_movie_starttime\n" +
                "FROM TICKETING INNER JOIN THEATERS ON THEATERS.theater_id = TICKETING.ticketing_theater_id\n" +
                "INNER JOIN SCREENHALLS ON SCREENHALLS.screenhall_id = TICKETING.ticketing_screenhall_id\n" +
                "WHERE customer_id = '" + id + "' and ticketing_movie_name ='" + title + "'";
        try {
            conn = DAOHandler.getConnection();
            stmt = conn.createStatement();
            rs = stmt.executeQuery(SQL);

            while(rs.next()) {
                String theater_name = rs.getString(1);
                mytic.add(theater_name);
                String screenhall_name = rs.getString(2);
                mytic.add(screenhall_name);
                Timestamp starttime = rs.getTimestamp(3);
                mytic.add(String.valueOf(starttime));
            }

            // 영화표 가격 총합
            SQL = "SELECT SUM(ticketing_price) FROM TICKETING WHERE customer_id = '" +id + "' and ticketing_movie_name ='" + title + "'";
            stmt = conn.createStatement();
            rs = stmt.executeQuery(SQL);
            rs.next();
            int total = rs.getInt(1);       mytic.add(String.valueOf(total));
            rs.close();

            SQL = "SELECT movie_id FROM MOVIES WHERE title = '" + title + "'";
            stmt = conn.createStatement();
            rs = stmt.executeQuery(SQL);
            rs.next();
            int movieID = rs.getInt(1);
            rs.close();

            String SQL1 = "SELECT COUNT(*) FROM PAYMENTS WHERE payment_state = 1 and customer_id = '" + id +"' and payment_movie_id = "+ movieID;
            String SQL2 = "SELECT COUNT(*) FROM PAYMENTS WHERE payment_state = 2 and customer_id = '" + id +"' and payment_movie_id = "+ movieID;
            stmt = conn.createStatement();
            rs = stmt.executeQuery(SQL1);
            rs.next();
            int ResCount = rs.getInt(1);
            rs.close();

            stmt = conn.createStatement();
            rs = stmt.executeQuery(SQL2);
            rs.next();
            int celCount = rs.getInt(1);
            rs.close();

            mytic.add(String.valueOf(ResCount-celCount));


            // 선정한 자리 표시
            SQL = "SELECT ticketing_seat_row, ticketing_seat_col FROM TICKETING WHERE customer_id = \'"+ id + "\' and ticketing_movie_name =\'" + title + "\'";
            stmt = conn.createStatement();
            rs = stmt.executeQuery(SQL);

            while(rs.next())
            {
                int row = rs.getInt(1);
                int col = rs.getInt(2);
                String seatstr = row + "행" + col + "열";
                mytic.add(seatstr);
            }
        } catch (SQLException sqle) {
            System.out.println("SELECT문에서 예외 발생");
            sqle.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
                throw new RuntimeException(e.getMessage());
            }
        }
        return mytic;
    }
}