package database.DAO;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class StatsDAO //통계정보 조회
{
    public StatsDAO() {
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
        } catch (ClassNotFoundException cnfe) {
            System.out.println("DB 드라이버 로딩 실패 :" + cnfe.toString());
        }
    }

    //영화별 통계정보 조회
    public static ArrayList<String> movieStat(String title) {
        //영화별 통계정보를 담을 ArrayList
        ArrayList<String> mvstat = new ArrayList<>();

        mvstat.add(String.format("%.2f", bookRate(title))); //영화별 예매율
        mvstat.add(String.format("%.2f", cancelRate(title)));   //영화별 취소율
        mvstat.add(String.format("%.2f", star(title))); //영화별 별점
        mvstat.add(String.valueOf(audienceNum(title))); //영화별 누적관객수
        return mvstat;
    }

    //영화 예매율
    public static double bookRate(String movieName) {
        double movieBookRate = 0; //영화별 예매율
        double totalBook = 0; //예매한 사람 전체 수
        double movieBook = 0; //한 영화를 예매한 사람 수
        int movieID = 0;  //영화 id

        Statement stmt = null;
        Connection conn = null;
        ResultSet rs = null;

        try {
            conn = DAOHandler.getConnection();
            stmt = conn.createStatement();

            //예매한 전체 인원 구하기
            String SQL = "SELECT COUNT(*) FROM PAYMENTS WHERE PAYMENT_STATE=1"; //1이면 결제 완료
            rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                totalBook = rs.getDouble(1);
            }

            //영화ID 구하기
            String SQL2 = "SELECT MOVIE_ID FROM MOVIES WHERE TITLE='" + movieName + "'"; //영화ID 구하기
            rs = stmt.executeQuery(SQL2);
            while (rs.next()) {
                movieID = rs.getInt(1);
            }

            //해당 영화 예매한 인원 구하기
            String SQL3 = "SELECT COUNT(*) FROM USERS, BANKS, PAYMENTS WHERE USERS.USER_NAME=BANKS.ACCOUNT_OWNER " +
                    "AND BANKS.ACCOUNT_NUM=PAYMENTS.CUSTOMER_ACCOUNT AND PAYMENTS.PAYMENT_STATE=1 " +
                    "AND PAYMENTS.PAYMENT_MOVIE_ID=" + movieID;
            rs = stmt.executeQuery(SQL3);
            while (rs.next()) {
                movieBook = rs.getDouble(1);
            }

            //예매율 구하기
            movieBookRate = (movieBook / totalBook) * 100;

        } catch (SQLException sqle) {
            System.out.println("SELECT문에서 예외 발생");
            sqle.printStackTrace();

        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
                throw new RuntimeException(e.getMessage());

            }
        }
        return movieBookRate; //예매율
    }

    //영화 취소율
    public static double cancelRate(String movieName) {
        double movieCancelRate = 0; //영화 취소율
        double totalCancel = 0; //취소한 사람 전체 수
        double movieCancel = 0; //한 영화를 취소한 사람 수
        String movieID = null;  //영화 id

        Statement stmt = null;
        Connection conn = null;
        ResultSet rs = null;

        try {
            conn = DAOHandler.getConnection();
            stmt = conn.createStatement();

            //취소한 전체 인원 구하기
            String SQL = "SELECT COUNT(*)FROM PAYMENTS WHERE PAYMENT_STATE=2";  //상태 2면 환불
            rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                totalCancel = rs.getDouble(1);
            }

            //영화ID 구하기
            String SQL2 = "SELECT MOVIE_ID FROM MOVIES WHERE TITLE='" + movieName + "'";
            rs = stmt.executeQuery(SQL2);
            while (rs.next()) {
                movieID = rs.getString(1);
            }

            //해당 영화 취소한 인원 구하기
            String SQL3 = "SELECT COUNT(*) FROM PAYMENTS WHERE PAYMENT_STATE=2 AND PAYMENT_MOVIE_ID=" + movieID;
            rs = stmt.executeQuery(SQL3);
            while (rs.next()) {
                movieCancel = rs.getInt(1);
            }

            //영화 취소율 구하기
            movieCancelRate = (movieCancel / totalCancel) * 100;

        } catch (SQLException sqle) {
            System.out.println("SELECT문에서 예외 발생");
            sqle.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
                throw new RuntimeException(e.getMessage());
            }
        }
        return movieCancelRate;    //영화 취소율
    }

    //영화별 별점 조회
    public static double star(String movieName) {
        double totalStar= 0;  //영화 총별점

        Statement stmt = null;
        Connection conn = null;
        ResultSet rs = null;

        try {
            conn = DAOHandler.getConnection();
            stmt = conn.createStatement();

            //영화 이름으로 리뷰에서 별점 평균 구하기
            String SQL = "SELECT AVG(STAR) FROM REVIEWS WHERE REVIEW_MOVIE_NAME='" + movieName + "'";
            rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                totalStar = rs.getDouble(1);
            }

        } catch (SQLException sqle) {
            System.out.println("SELECT문에서 예외 발생");
            sqle.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
                throw new RuntimeException(e.getMessage());
            }
        }
        return totalStar;   //영화 총별점
    }

    //영화별 누적관객수 조회
    public static int audienceNum(String movieName) {
        int audience = 0;   //누적관객수
        int movie_id = 0;   //영화 id

        Statement stmt = null;
        Connection conn = null;
        ResultSet rs = null;

        try {
            conn = DAOHandler.getConnection();
            stmt = conn.createStatement();

            //영화 이름으로 영화 id 구하기
            String SQL = "SELECT MOVIE_ID FROM MOVIES WHERE TITLE='" + movieName + "'";
            rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                movie_id = rs.getInt(1);
            }

            //영화 id로 결제내역에서 누적관객수 구하기
            String SQL2 = "SELECT SUM(PAYMENT_PERSONNUM) FROM PAYMENTS WHERE PAYMENT_MOVIE_ID = " + movie_id;
            rs = stmt.executeQuery(SQL2);
            while (rs.next()) {
                audience = rs.getInt(1);
            }

        } catch (SQLException sqle) {
            System.out.println("SELECT문에서 예외 발생");
            sqle.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
                throw new RuntimeException(e.getMessage());
            }
        }
        return audience;    //누적관객수
    }

    //영화관별 통계정보 조회
    public static ArrayList<String> theaterStats(String theaterName) {
        //영화관별 통계정보를 담을 ArrayList
        ArrayList<String> theaterStatsList = new ArrayList<>();

        theaterStatsList.add(String.format("%.2f", theaterBookRate(theaterName))); //예매율
        theaterStatsList.add(String.format("%.2f", theaterCancelRate(theaterName))); //취소율
        theaterStatsList.add(Integer.toString(theaterProfit(theaterName))); //영화관 별 수익
        theaterStatsList.add(Integer.toString(totalProfit())); //총 수익

        return theaterStatsList;
    }

    //영화관별 예매율
    public static double theaterBookRate(String theaterName) {
        double theaterBookRate = 0;  //영화관별 예매율
        double totalBook = 0; //예매한 사람 전체 수
        double theaterBook = 0; //해당 영화관에서 예매한 사람 수
        String theaterAccountNum = null;    //영화관 계좌번호

        Statement stmt = null;
        Connection conn = null;
        ResultSet rs = null;

        try {
            conn = DAOHandler.getConnection();
            stmt = conn.createStatement();

            //영화관 계좌번호 구하기
            String SQL = "SELECT ACCOUNT_NUM FROM BANKS WHERE ACCOUNT_OWNER='" + theaterName + "'";
            rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                theaterAccountNum = rs.getString(1);
            }

            //예매한 전체 인원 구하기
            String SQL2 = "SELECT COUNT(*) FROM PAYMENTS WHERE PAYMENT_STATE=1";    //상태 1이면 결제완료
            rs = stmt.executeQuery(SQL2);
            while (rs.next()) {
                totalBook = rs.getDouble(1);
            }

            //해당 영화관에 예매한 인원 구하기
            String SQL3 = "SELECT COUNT(*) FROM USERS, BANKS, PAYMENTS WHERE USERS.USER_NAME=banks.account_owner " +
                    "AND BANKS.ACCOUNT_NUM=PAYMENTS.CUSTOMER_ACCOUNT AND PAYMENTS.PAYMENT_STATE=1 " +
                    "AND PAYMENTS.THEATER_ACCOUNT='" + theaterAccountNum + "'";
            rs = stmt.executeQuery(SQL3);
            while (rs.next()) {
                theaterBook = rs.getDouble(1);
            }

            //영화관별 예매율 구하기
            theaterBookRate = (theaterBook / totalBook) * 100;

        } catch (SQLException sqle) {
            System.out.println("SELECT문에서 예외 발생");
            sqle.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
                throw new RuntimeException(e.getMessage());
            }
        }
        return theaterBookRate; //영화관별 예매율
    }

    //영화관별 취소율
    public static double theaterCancelRate(String theaterName) {
        double theaterCancelRate = 0;  //영화관별 취소율
        double totalCancel = 0; //예매한 사람 전체 수
        double theaterCancel = 0; //해당 영화관에서 예매한 사람 수
        String theaterAccountNum = null;    //영화관 계좌번호

        Statement stmt = null;
        Connection conn = null;
        ResultSet rs = null;

        try {
            conn = DAOHandler.getConnection();
            stmt = conn.createStatement();

            //영화관 계좌번호 구하기
            String SQL = "SELECT ACCOUNT_NUM FROM BANKS WHERE ACCOUNT_OWNER='" + theaterName + "'";
            rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                theaterAccountNum = rs.getString(1);
            }

            // 취소한 전체 인원 구하기
            String SQL2 = "SELECT COUNT(*) FROM PAYMENTS WHERE PAYMENT_STATE=2";    //상태 2면 환불
            rs = stmt.executeQuery(SQL2);
            while (rs.next()) {
                totalCancel = rs.getDouble(1);
            }

            //해당 영화관에서 취소한 인원 구하기
            String SQL3 = "SELECT COUNT(*) FROM PAYMENTS WHERE PAYMENT_STATE=2 AND PAYMENTS.THEATER_ACCOUNT='" + theaterAccountNum + "'";
            rs = stmt.executeQuery(SQL3);
            while (rs.next()) {
                theaterCancel = rs.getDouble(1);
            }

            //영화관별 취소율 구하기
            theaterCancelRate = (theaterCancel / totalCancel) * 100;

        } catch (SQLException sqle) {
            System.out.println("SELECT문에서 예외 발생");
            sqle.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
                throw new RuntimeException(e.getMessage());
            }
        }
        return theaterCancelRate;   //영화관별 취소율
    }

    //영화관 별 수익
    public static int theaterProfit(String theaterName) {
        int theaterProfit = 0; //수익

        Statement stmt = null;
        Connection conn = null;
        ResultSet rs = null;

        try {
            conn = DAOHandler.getConnection();
            stmt = conn.createStatement();

            //해당 영화관이 주인인 계좌에서 잔액 구하기
            String SQL = "SELECT BALANCE FROM BANKS WHERE ACCOUNT_OWNER='" + theaterName + "'";
            rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                theaterProfit= rs.getInt(1);
            }

        } catch (SQLException sqle) {
            System.out.println("SELECT문에서 예외 발생");
            sqle.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
                throw new RuntimeException(e.getMessage());
            }
        }
        return theaterProfit;  //영화관 수익
    }

    //총수익
    public static int totalProfit() {
        int profit = 0; //수익

        Statement stmt = null;
        Connection conn = null;
        ResultSet rs = null;

        try {
            conn = DAOHandler.getConnection();
            stmt = conn.createStatement();

            //영화관 전체 수익 구하기
            String SQL = "SELECT SUM(BALANCE) FROM BANKS WHERE ACCOUNT_SECTION='0'"; //0이면 영화관 계좌
            rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                profit = rs.getInt(1);
            }

        } catch (SQLException sqle) {
            System.out.println("SELECT문에서 예외 발생");
            sqle.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
                throw new RuntimeException(e.getMessage());
            }
        }
        return profit;  //영화관 전체 수익
    }
}