package database.DAO;

import network.Protocol;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.Scanner;

public class PaymentsDAO {
    public static Scanner s = new Scanner(System.in);

    public PaymentsDAO() {
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
        } catch (ClassNotFoundException cnfe) {
            System.out.println("DB 드라이버 로딩 실패 :" + cnfe.toString());
        }
    }

    // 2.6.1 결제(트랜젝션 걸기)
    public static int doPay(String[] s) {
        Connection conn = DAOHandler.getConnection();
        Statement stmt = null;
        PreparedStatement pstmt = null;
        CallableStatement cstmt = null;
        ResultSet rs = null;

        try {
            String custAccNum = null;
            String thAccNum = null;
            int personNum = 0;
            int movieId = 0;
            String username=null;

            conn.setAutoCommit(false);

            //고객 계좌번호 찾기
            String SQL = "SELECT account_num FROM BANKS WHERE account_owner = (SELECT USER_NAME FROM USERS WHERE user_id = '" + s[0] + "')";
            stmt = conn.prepareStatement(SQL);
            rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                custAccNum = rs.getString(1);   //고객 계좌번호
                System.out.println("결제 " + custAccNum);
            }

            //고객 id로 잔액 조회
            SQL = "SELECT balance FROM BANKS WHERE account_owner = (SELECT USER_NAME FROM USERS WHERE user_id = '" + s[0] + "')";
            stmt = conn.prepareStatement(SQL);
            rs = stmt.executeQuery(SQL);
            int balance = 0;
            while (rs.next()) {
                balance = rs.getInt(1); //잔액
                System.out.println("결제 " + balance);
            }

            //영화관 계좌 번호 찾기
            SQL = "SELECT account_num FROM BANKS WHERE account_owner = '" + s[1] + "'";
            stmt = conn.prepareStatement(SQL);
            rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                thAccNum = rs.getString(1); //영화관 계좌번호
                System.out.println("결제 " + thAccNum);
            }

            //고객 id로 예매된 영화 찾기
            SQL = "SELECT MOVIE_ID FROM MOVIES WHERE title = '"+s[5]+"'";
            stmt = conn.prepareStatement(SQL);
            rs = stmt.executeQuery(SQL);
            while (rs.next())
            {
                movieId = rs.getInt(1); //영화 id
            }

            //고객이 예매한 티켓 수 찾기기
            SQL = "SELECT COUNT(*) FROM TICKETING WHERE customer_id = '" + s[0] + "' and ticketing_movie_name = (SELECT title FROM MOVIES WHERE movie_id = " + movieId + ")";
            stmt = conn.prepareStatement(SQL);
            rs= stmt.executeQuery(SQL);
            while (rs.next())
            {
                personNum = rs.getInt(1); //구매한 티켓 수
                System.out.println("결제 " + personNum);
            }

            //결제
            if (balance >= Integer.parseInt(s[4])) {
                //PAYMENTS에 등록
                SQL = "INSERT INTO PAYMENTS VALUES(?, ?, ?, ?, ?, ?, 1, ?)";
                java.util.Date date = new Date();
                Timestamp sysdate = new Timestamp(date.getTime());
                System.out.println(custAccNum);
                pstmt = conn.prepareStatement(SQL);
                pstmt.setString(1, custAccNum);
                pstmt.setInt(2, personNum);
                pstmt.setString(3, thAccNum);
                pstmt.setInt(4, movieId);
                pstmt.setTimestamp(5, Timestamp.valueOf(String.valueOf(sysdate)));
                pstmt.setInt(6, Integer.parseInt(s[4]));
                pstmt.setString(7, s[0]);
                pstmt.executeUpdate();

                //결제
                cstmt = conn.prepareCall("{call Payment(?, ?, ?, ?)}"); //프로시저
                SQL = "SELECT user_name FROM USERS WHERE user_id = ?";  //고객 이름 구하기
                pstmt = conn.prepareStatement(SQL);
                pstmt.setString(1, s[0]);
                rs = pstmt.executeQuery();
                while (rs.next()) {
                    username = rs.getString(1);
                }
                cstmt.setString(1, username);
                cstmt.setString(2, custAccNum);
                cstmt.setInt(3, Integer.parseInt(s[4]));
                cstmt.setString(4, thAccNum);
                cstmt.execute();
            }

            System.out.println("결제 " + movieId);
            System.out.println("성공적으로 결제되었습니다");
            conn.commit();

            ManagementDAO.updateAudienceNum(String.valueOf(movieId));

            //예매율 업데이트
            double bookRate=StatsDAO.bookRate(s[5]);
            SQL="UPDATE MOVIES SET RESERVATION_RATE="+bookRate+" WHERE MOVIE_ID="+movieId;
            pstmt = conn.prepareStatement(SQL);
            pstmt.executeUpdate(SQL);

            return Protocol.T4_CD1_SUCCESS;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        } finally {
            try {
                conn.setAutoCommit(true);
                if (cstmt != null) cstmt.close();
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
        return Protocol.T4_CD0_FAIL;
    }

    public static int checkAcc(String[] s) {
        Connection conn = DAOHandler.getConnection();
        Statement stmt = null;
        PreparedStatement pstmt = null;
        CallableStatement cstmt = null;
        ResultSet rs = null;

        String SQL = "SELECT account_num FROM BANKS WHERE account_owner = (SELECT USER_NAME FROM USERS WHERE user_id = '" + s[0] + "')";
        try {
            stmt = conn.prepareStatement(SQL);
            rs = stmt.executeQuery(SQL);
            System.out.println("실행되라뿅");
            String compareid = null;
            while (rs.next()) {
                compareid = rs.getString(1);
            }
            rs.close();

            SQL = "SELECT account_passwd FROM BANKS WHERE account_owner = (SELECT USER_NAME FROM USERS WHERE user_id = \'" + s[0] + "\')";
            stmt = conn.prepareStatement(SQL);
            rs = stmt.executeQuery(SQL);
            String comparepwd = null;
            while (rs.next()) {
                comparepwd = rs.getString(1);
                System.out.println(comparepwd);
            }
            System.out.println(comparepwd);
            rs.close();

            if (compareid.equals(s[1])) {
                System.out.println("id가 맞다.");
                if (comparepwd.equals(s[2])) {
                    System.out.println("비번도 맞다.");
                    return Protocol.T12_CD1_SUCCESS;
                }
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        } finally {
            try {
                conn.setAutoCommit(true);
                if (cstmt != null) cstmt.close();
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
        return Protocol.T12_CD0_FAIL;
    }

    // 2.6.2 환불
    public static int refund(String[] s) throws SQLException {
        Connection conn = DAOHandler.getConnection();
        Statement stmt = null;
        PreparedStatement pstmt = null;
        CallableStatement cstmt = null;
        ResultSet rs = null;

        int success=0;
        conn.setAutoCommit(false);
        try {
            String custAccNum = null;
            String thAccNum = null;
            String title = null;
            int personNum = 0;
            int movieId = 0;
            conn.setAutoCommit(false);
            String SQL = "SELECT account_num FROM BANKS WHERE account_owner = (SELECT USER_NAME FROM USERS WHERE user_id = '" + s[0] + "')";
            stmt = conn.prepareStatement(SQL);
            rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                custAccNum = rs.getString(1);
                System.out.println("환불 " + custAccNum);
            }
            rs.close();

            SQL = "SELECT account_num FROM BANKS WHERE account_owner = '" + s[1] + "'";
            stmt = conn.prepareStatement(SQL);
            rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                thAccNum = rs.getString(1);
                System.out.println("환불 " + thAccNum);
            }
            rs.close();

            SQL = "SELECT MOVIE_ID FROM MOVIES WHERE title IN (SELECT ticketing_movie_name FROM TICKETING WHERE customer_id = '" + s[0] + "')";
            stmt = conn.prepareStatement(SQL);
            rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                movieId = rs.getInt(1);
                System.out.println("환불 " + movieId);
            }
            rs.close();

            //누적관객수에 써먹을것
            SQL = "SELECT COUNT(*) FROM TICKETING WHERE customer_id = '" + s[0] + "' and ticketing_movie_name = (SELECT title FROM MOVIES WHERE movie_id = '" + movieId + "')";
            stmt = conn.prepareStatement(SQL);
            rs = stmt.executeQuery(SQL);

            while (rs.next()) {
                personNum = rs.getInt(1);
                System.out.println("환불 " + personNum);
            }
            rs.close();


            SQL = "SELECT title FROM MOVIES WHERE movie_id = " + movieId;
            stmt = conn.prepareStatement(SQL);
            rs = stmt.executeQuery(SQL);
            while (rs.next()) {
                title = rs.getString(1);
                System.out.println("환불 " + title);
            }
            rs.close();

            cstmt = conn.prepareCall("{call Payment(?, ?, ?, ?)}");
            SQL = "SELECT user_name FROM USERS WHERE user_id = ?";
            pstmt = conn.prepareStatement(SQL);
            pstmt.setString(1, s[0]);
            rs = pstmt.executeQuery();
            rs.next();
            String username = rs.getString(1);
            rs.close();

            cstmt.setString(1, username);
            cstmt.setString(2, thAccNum);
            cstmt.setInt(3, Integer.parseInt(s[4]));
            cstmt.setString(4, custAccNum);
            cstmt.execute();
            System.out.println("성공적으로 환불되었습니다");

            SQL = "INSERT INTO PAYMENTS VALUES(?, ?, ?, ?, ?, ?, 2, ?)";
            java.util.Date date = new Date();
            Timestamp sysdate = new Timestamp(date.getTime());
            System.out.println(custAccNum);
            pstmt = conn.prepareStatement(SQL);
            pstmt.setString(1, custAccNum);
            pstmt.setInt(2, personNum * -1);
            pstmt.setString(3, thAccNum);
            pstmt.setInt(4, movieId);
            pstmt.setTimestamp(5, Timestamp.valueOf(String.valueOf(sysdate)));
            pstmt.setInt(6, Integer.parseInt(s[4]) * -1);
            pstmt.setString(7, s[0]);
            pstmt.executeUpdate();

            TicketingDAO.cancelTicket(s[0], title);  //예매 취소
            conn.commit();
            int updateANSuccess=ManagementDAO.updateAudienceNum(String.valueOf(movieId)); //누적관객수 업뎃

            //예매율 업데이트
            double bookRate=StatsDAO.bookRate(title);
            SQL="UPDATE MOVIES SET CANCELLATION_RATE="+bookRate+" WHERE MOVIE_ID="+movieId;
            pstmt = conn.prepareStatement(SQL);
            pstmt.executeUpdate(SQL);

            return Protocol.T10_CD1_SUCCESS; //성공
        } catch (SQLException throwables) {
            conn.setAutoCommit(true);
            throwables.printStackTrace();
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        } finally {
            try {
                conn.setAutoCommit(true);
                if (cstmt != null) cstmt.close();
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (SQLException throwables) {
                throwables.printStackTrace();
            }
        }
        return Protocol.T12_CD0_FAIL;
    }
}