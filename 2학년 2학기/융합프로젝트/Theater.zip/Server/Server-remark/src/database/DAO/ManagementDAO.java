package database.DAO;

import database.DTO.*;
import network.Protocol;

import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Scanner;

public class ManagementDAO
{
    public ManagementDAO()
    {
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
        } catch (ClassNotFoundException cnfe) {
            System.out.println("DB 드라이버 로딩 실패 :" + cnfe.toString());
        }
    }

    // 0. 회원가입
    public static int insertUser(String[] s)
    {
        Connection conn = null;
        PreparedStatement pstmt = null;

        int classification = Integer.parseInt(s[0]);
        String name = s[1];
        String id = s[2];
        String pwd = s[3];
        String phone = s[4];
        String [] bdStr = s[5].split("/");
        LocalDate birthday = LocalDate.of(Integer.parseInt(bdStr[0]), Integer.parseInt(bdStr[1]), Integer.parseInt(bdStr[2]));
        String SQL = "INSERT INTO USERS(USER_NAME, USER_ID, USER_PWD, PHONENUM, USER_SECTION, USER_BIRTHDAY) VALUES(?, ?, ?, ?, ?, ?)";
        try {
            conn = DAOHandler.getConnection();
            pstmt = conn.prepareStatement(SQL);

            pstmt.setString(1, name);
            pstmt.setString(2, id);
            pstmt.setString(3, pwd);
            pstmt.setString(4, phone);
            pstmt.setInt(5, classification);
            pstmt.setDate(6, Date.valueOf(birthday));
            pstmt.executeUpdate();
            return Protocol.T4_CD1_SUCCESS;

        } catch (SQLException sqle) {
            sqle.printStackTrace();
            return Protocol.T4_CD0_FAIL;
        } finally {
            try {
                if (pstmt != null) {
                    pstmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
                throw new RuntimeException(e.getMessage());
            }
        }
    }

    // 1.1.1 영화관 등록
    public static int insertTheater(String s[])
    {
        int insertSuccess;
        Connection conn = null;
        PreparedStatement pstmt = null;

        String theater_id = s[0];
        String theater_name = s[1];
        String location = s[2];
        int screenhall_num = Integer.parseInt(s[3]);

        String SQL = "INSERT INTO THEATERS(THEATER_ID, THEATER_NAME, THEATER_LOCATION, SCREENHALL_NUM) VALUES(?, ?, ?, ?)";
        try {
            conn = DAOHandler.getConnection();
            pstmt = conn.prepareStatement(SQL);

            pstmt.setString(1, theater_id);
            pstmt.setString(2, theater_name);
            pstmt.setString(3, location);
            pstmt.setInt(4, screenhall_num);
            pstmt.executeUpdate();
            return Protocol.T4_CD1_SUCCESS;

        } catch (SQLException sqle) {
            sqle.printStackTrace();
            return Protocol.T4_CD0_FAIL;
        } finally {
            try {
                if (pstmt != null) {
                    pstmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
                throw new RuntimeException(e.getMessage());
            }
        }
    }

    // 1.1.2-1 영화관 수정(영화관 이름)
    public static int updateTheaterName(String[] s) {
        Connection conn = null;
        PreparedStatement stmt = null;
        int updateTheaterNameSuccess=0;

        String originTheaterName = s[0];
        String updateTheaterName = s[1];

        String SQL = "UPDATE THEATERS SET THEATER_NAME='" + updateTheaterName + "' WHERE THEATER_ID=(SELECT THEATER_ID FROM THEATERS WHERE THEATER_NAME='" + originTheaterName + "')"; //영화이름 업데이트
        try {
            conn = DAOHandler.getConnection();
            stmt = conn.prepareStatement(SQL);
            stmt.executeUpdate();
            System.out.println("정상적으로 변경되었습니다.");
            //sc.nextLine();
            updateTheaterNameSuccess=1;
        } catch (SQLException sqle) {
            sqle.printStackTrace();
            updateTheaterNameSuccess= 0;
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
                throw new RuntimeException(e.getMessage());
            }
        }
        System.out.println(updateTheaterNameSuccess);
        return updateTheaterNameSuccess;
    }

    // 1.1.2-2 영화관 수정(영화관 위치)
    public static int updateTheaterLocation(String[] s)
    {
        Connection conn = null;
        Statement stmt = null;
        int updateLocationSuccess=0;

        String theaterName=s[0];
        String updateLocation=s[1];

        String SQL="UPDATE THEATERS SET THEATER_LOCATION='"+updateLocation+"' WHERE THEATER_ID=(SELECT THEATER_ID FROM THEATERS WHERE THEATER_NAME='"+theaterName+"')"; //영화관 위치 update

        try {
            conn = DAOHandler.getConnection();
            stmt = conn.prepareStatement(SQL);
            stmt.executeUpdate(SQL);
            System.out.println("정상적으로 변경되었습니다.");
            updateLocationSuccess= 1;
        } catch (SQLException sqle) {
            sqle.printStackTrace();
            updateLocationSuccess= 0;
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
                throw new RuntimeException(e.getMessage());
            }
        }
        return updateLocationSuccess;
    }

    // 1.1.2-3 영화관 수정(상영관 수)
    public static int updateTheaterScreenhallNum(String[] s)
    {
        Scanner sc=new Scanner(System.in);

        Connection conn = null;
        Statement stmt = null;
        int updateSCHNSuccess=0;

        String theaterName=s[0];
        int newScreenhallNum=Integer.parseInt(s[1]);

        String SQL="UPDATE THEATERS SET SCREENHALL_NUM="+newScreenhallNum+" WHERE THEATER_ID=(SELECT THEATER_ID FROM THEATERS WHERE THEATER_NAME='"+theaterName+"')"; //상영관 수 update

        try {
            conn = DAOHandler.getConnection();
            stmt = conn.prepareStatement(SQL);
            stmt.executeUpdate(SQL);
            System.out.println("정상적으로 변경되었습니다.");
            updateSCHNSuccess=1;
        } catch (SQLException sqle) {
            sqle.printStackTrace();
            updateSCHNSuccess= 0;
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
                throw new RuntimeException(e.getMessage());
            }
        }
        return updateSCHNSuccess;
    }

    //1.1.3 영화관 삭제
    public static int deleteTheater(String theaterName) throws SQLException //인자 영화관 이름
    {
        Connection conn = null;
        Statement stmt = null;

        String SQL1 = "DELETE FROM SEATS WHERE SEAT_SCREENHALL_ID IN (SELECT SCREENHALL_ID FROM SCREENHALLS WHERE SCREENHALL_THEATER_ID IN (SELECT THEATER_ID FROM THEATERS WHERE THEATER_NAME IN '"+theaterName+"'))"; //좌석 삭제
        String SQL6 = "DELETE FROM SHOWING WHERE SHOWING_THEATER_ID IN (SELECT THEATER_ID FROM THEATERS WHERE THEATER_NAME = '" + theaterName + "')";
        String SQL2 = "DELETE FROM TICKET_PRICES WHERE THEATER_ID = (SELECT THEATER_ID FROM THEATERS WHERE THEATER_NAME = '" + theaterName + "')";
        String SQL3 = "DELETE FROM TICKETING WHERE TICKETING_THEATER_ID IN (SELECT THEATER_ID FROM THEATERS WHERE THEATER_NAME = '" + theaterName + "')";
        String SQL4 = "DELETE FROM SCREENHALLS WHERE SCREENHALL_THEATER_ID=(SELECT THEATER_ID FROM THEATERS WHERE THEATER_NAME=\'"+theaterName+"\')"; //상영관 삭제
        String SQL5 = "DELETE FROM THEATERS WHERE THEATER_ID=(SELECT THEATER_ID FROM THEATERS WHERE THEATER_NAME=\'" +theaterName+"\')"; //영화관 삭제

        try {

            conn = DAOHandler.getConnection();
            stmt = conn.createStatement();
            stmt.executeUpdate(SQL1);
            System.out.println("정상적으로 좌석이 삭제되었습니다.");

            stmt = conn.createStatement();
            stmt.executeUpdate(SQL6);
            System.out.println("정상적으로 상영시간표가 삭제되었습니다.");

            stmt = conn.createStatement();
            stmt.executeUpdate(SQL3);
            System.out.println("정상적으로 기록이 삭제되었습니다.");

            stmt = conn.createStatement();
            stmt.executeUpdate(SQL2);
            System.out.println("정상적으로 가격이 삭제되었습니다.");

            stmt = conn.createStatement();
            stmt.executeUpdate(SQL4);
            System.out.println("정상적으로 상영관이 삭제되었습니다.");

            stmt = conn.createStatement();
            stmt.executeUpdate(SQL5);
            System.out.println("정상적으로 영화관이 삭제되었습니다.");

            return Protocol.T10_CD1_SUCCESS;

        } catch (SQLException sqle) {
            sqle.printStackTrace();
            return Protocol.T10_CD0_FAIL;

        } finally {
            try {
                conn.setAutoCommit(true);
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
                throw new RuntimeException(e.getMessage());
            }
        }
    }

    // 1.2.1 영화 등록
    public static int insertMovie(String []s)
    {
        Connection conn = null;
        PreparedStatement pstmt = null;

        String title = s[0];
        int runningtime = Integer.parseInt(s[1]);
        String director = s[2];
        String cast = s[3];
        int grade = Integer.parseInt(s[4]);
        String synopsis = s[5];
        int audience = Integer.parseInt(s[6]);
        String[] str = s[7].split("/");
        LocalDate startday = LocalDate.of(Integer.parseInt(str[0]), Integer.parseInt(str[1]), Integer.parseInt(str[2]));
        int state = Integer.parseInt(s[8]);
        String poster = s[9];
        String stealCut1 = s[10];
        String stealCut2 = s[11];
        String stealCut3 = s[12];
        String teaser = s[13];

        String SQL = "INSERT INTO MOVIES(TITLE, RUNNINGTIME, DIRECTOR, CAST, GRADE, SYNOPSIS, AUDIENCE_NUM, PLAYDATE, MOVIE_STATE, POSTER, STEALCUT1, STEALCUT2, STEALCUT3, TEASER) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try {
            conn = DAOHandler.getConnection();
            pstmt = conn.prepareStatement(SQL);

            pstmt.setString(1, title);
            pstmt.setInt(2, runningtime);
            pstmt.setString(3, director);
            pstmt.setString(4, cast);
            pstmt.setInt(5, grade);
            pstmt.setString(6, synopsis);
            pstmt.setInt(7, audience);
            pstmt.setDate(8, Date.valueOf(startday));
            pstmt.setInt(9, state);
            pstmt.setString(10, poster);
            pstmt.setString(11, stealCut1);
            pstmt.setString(12, stealCut2);
            pstmt.setString(13, stealCut3);
            pstmt.setString(14, teaser);
            pstmt.executeUpdate();
            System.out.println("정상적으로 추가되었습니다.");
            return Protocol.T4_CD1_SUCCESS;

        } catch (SQLException sqle) {
            sqle.printStackTrace();
            return Protocol.T4_CD0_FAIL;
        } finally {
            try {
                if (pstmt != null) {
                    pstmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
                throw new RuntimeException(e.getMessage());
            }
        }
    }

    // 1.2.2 영화 수정-상태
    public static int updateMovieState() //영화상태 변경
    {
        Connection conn = null;
        Statement stmt = null;
        int updateSuccess=0;

        String SQL1="UPDATE MOVIES SET MOVIE_STATE = 1 where PLAYDATE < SYSDATE"; //상영예정작(0)->현재상영작(1)
        String SQL2="UPDATE MOVIES SET MOVIE_STATE = 2 where ADD_MONTHS(PLAYDATE,1) < SYSDATE"; //현재상영작(1)->상영종료작(2)
        try {
            conn = DAOHandler.getConnection();
            stmt = conn.prepareStatement(SQL1);
            stmt.executeUpdate(SQL1);
            System.out.println("현재상영작으로 변경되었습니다.");
            stmt = conn.prepareStatement(SQL2);
            stmt.executeUpdate(SQL2);
            System.out.println("상영종료작으로 변경되었습니다.");

            updateSuccess=1;

        } catch (SQLException sqle) {
            sqle.printStackTrace();

            updateSuccess= 0;

        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
                throw new RuntimeException(e.getMessage());
            }
        }
        return updateSuccess;
    }

    //2.2.2 영화 수정- 별점
    public static int updateStars(String name)
    {
        Connection conn = null;
        Statement stmt = null;

        int starUpdateSuccess=0;

        String SQL="UPDATE MOVIES SET TOTAL_STAR=(SELECT AVG( STAR ) FROM REVIEWS WHERE REVIEW_MOVIE_NAME='"+name+
                "') WHERE MOVIE_ID=(SELECT MOVIE_ID FROM MOVIES WHERE TITLE='"+name+"')";
        try {
            conn = DAOHandler.getConnection();
            stmt = conn.prepareStatement(SQL);
            stmt.executeUpdate(SQL); //?? 되는거임?
            System.out.println("정상적으로 변경되었습니다.");

            starUpdateSuccess= 1;

        } catch (SQLException sqle) {
            sqle.printStackTrace();
            starUpdateSuccess= 0;

        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
                throw new RuntimeException(e.getMessage());
            }
        }
        return starUpdateSuccess;
    }

    //2.2.3 영화 수정- 누적관객수
    public static int updateAudienceNum(String movieID)
    {
        Connection conn = null;
        Statement stmt = null;

        String SQL="UPDATE MOVIES\n" +
                "SET AUDIENCE_NUM = \n" +
                "(SELECT SUM(PAYMENT_PERSONNUM) FROM PAYMENTS WHERE PAYMENT_MOVIE_ID = " + Integer.parseInt(movieID) + ") "+
                "WHERE MOVIE_ID = " + Integer.parseInt(movieID); //결제상태 2면 인원 수 음수로 만들어서 더하기

        try {
            conn = DAOHandler.getConnection();
            stmt = conn.createStatement();
            stmt.executeUpdate(SQL);
            System.out.println("정상적으로 변경되었습니다.");

            return Protocol.T8_CD1_SUCCESS;
        } catch (SQLException sqle) {
            sqle.printStackTrace();
            return Protocol.T8_CD0_FAIL;
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
                throw new RuntimeException(e.getMessage());
            }
        }
    }

    public static int deleteMovie(String title)
    {
        Connection conn = null;
        Statement stmt = null;

        String SQL = "DELETE FROM MOVIES WHERE title = '" + title + "'";
        try {
            conn = DAOHandler.getConnection();
            stmt = conn.createStatement();
            stmt.executeUpdate(SQL);
            System.out.println("정상적으로 추가되었습니다.");
            return Protocol.T10_CD1_SUCCESS;

        } catch (SQLException sqle) {
            sqle.printStackTrace();
            return Protocol.T10_CD0_FAIL;
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
                throw new RuntimeException(e.getMessage());
            }
        }
    }

    // 1.3.1 상영관 등록
    public static int insertScreenHall(String[] s)
    {
        Connection conn = null;
        PreparedStatement pstmt = null;

        String screenhall_id = s[0];
        String screenhall_name = s[1];
        int limit = Integer.parseInt(s[2]);
        String theater_id = s[3];

        String SQL = "INSERT INTO SCREENHALLS VALUES(?, ?, ?, ?)";
        try {
            conn = DAOHandler.getConnection();
            pstmt = conn.prepareStatement(SQL);

            pstmt.setString(1, screenhall_id);
            pstmt.setString(2, screenhall_name);
            pstmt.setInt(3, limit);
            pstmt.setString(4, theater_id);

            pstmt.executeUpdate();
            System.out.println("정상적으로 추가되었습니다.");
            return Protocol.T4_CD1_SUCCESS;

        } catch (SQLException sqle) {
            sqle.printStackTrace();
            return Protocol.T4_CD0_FAIL;
        } finally {
            try {
                if (pstmt != null) {
                    pstmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
                throw new RuntimeException(e.getMessage());
            }
        }
    }

    public static int deleteScreenhall(String s) //인자 상영관 id
    {
        Connection conn = null;
        Statement stmt = null;

        int deleteSCHSuccess=0;

        String screenhallID=s;

        String SQL="DELETE FROM SCREENHALLS WHERE SCREENHALL_ID=\'"+screenhallID+"\'";
        String SQL2="DELETE FROM SEATS WHERE SEAT_SCREENHALL_ID=\'"+screenhallID+"\'";
        try {
            conn = DAOHandler.getConnection();
            stmt = conn.createStatement();
            stmt.executeUpdate(SQL);
            System.out.println("정상적으로 상영관이 삭제되었습니다.");

            stmt = conn.createStatement();
            stmt.executeUpdate(SQL2);
            System.out.println("정상적으로 상영관 좌석이 삭제되었습니다.");

            deleteSCHSuccess=1;

        } catch (SQLException sqle) {
            sqle.printStackTrace();

            deleteSCHSuccess= 0;
        } finally {
            try {
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
                throw new RuntimeException(e.getMessage());
            }
        }
        return deleteSCHSuccess;
    }

    //1.3.2 영화관 가격 정보 등록
    public static int insertTicketPrice(String[] s)
    {
        int priceSuccess;
        Connection conn = null;
        PreparedStatement pstmt = null;

        String thID = s[0];
        int time = Integer.parseInt(s[1]);
        int customer = Integer.parseInt(s[2]);
        int price = Integer.parseInt(s[3]);
        String SQL = "INSERT INTO TICKET_PRICES(THEATER_ID, TICKET_SECTION, TICKET_AGE_SECTION, PRICE) VALUES(?, ?, ?, ?)";
        try {
            conn = DAOHandler.getConnection();
            pstmt = conn.prepareStatement(SQL);

            pstmt.setString(1, thID);
            pstmt.setInt(2, time);
            pstmt.setInt(3, customer);
            pstmt.setInt(4, price);
            pstmt.executeUpdate();

            System.out.println("정상적으로 추가되었습니다.");
            return Protocol.T4_CD1_SUCCESS;

        } catch (SQLException sqle) {
            sqle.printStackTrace();
            return Protocol.T4_CD0_FAIL;
        } finally {
            try {
                if (pstmt != null) {
                    pstmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
                throw new RuntimeException(e.getMessage());
            }
        }
    }

    // 1.4 상영시간표 등록(영화관 코드 있는 버전으로)
    public static int insertShowing(String[] s)
    {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        CallableStatement cs = null;

        String thname = s[0];
        String scrname = s[1];
        String movie = s[2];
        String [] startdayArr = s[3].split("/");
        LocalDateTime startday = LocalDateTime.of(Integer.parseInt(startdayArr[0]), Integer.parseInt(startdayArr[1]),
                Integer.parseInt(startdayArr[2]),Integer.parseInt(startdayArr[3]), Integer.parseInt(startdayArr[4]), 0, 0);

        try {
            // 영화관 id 구하기
            String SQL = "SELECT theater_id FROM THEATERS WHERE theater_name = '"+ thname + "\'";
            conn = DAOHandler.getConnection();
            pstmt = conn.prepareStatement(SQL);
            rs = pstmt.executeQuery();
            rs.next();  String theaterid = rs.getString(1);


            // 영화 id 구하기
            SQL = "SELECT movie_id FROM MOVIES WHERE title = '"+ movie + "\'";
            pstmt = conn.prepareStatement(SQL);
            rs = pstmt.executeQuery();
            rs.next(); int movieid = rs.getInt(1);

            // 상영관 id 구하기
            SQL = "SELECT screenhall_id FROM SCREENHALLS WHERE screenhall_name= '"+ scrname + "\' and screenhall_theater_id = '"+ theaterid + "\'";
            pstmt = conn.prepareStatement(SQL);
            rs = pstmt.executeQuery();
            rs.next(); String scrid = rs.getString(1);

            SQL = "INSERT INTO SHOWING VALUES(?, ?, ?, ?)";
            pstmt = conn.prepareStatement(SQL);
            pstmt.setString(1, scrid);
            pstmt.setInt(2, movieid);
            pstmt.setTimestamp(3, Timestamp.valueOf(startday));
            pstmt.setString(4, theaterid);
            pstmt.executeUpdate();
            System.out.println("정상적으로 추가되었습니다.");

            cs = conn.prepareCall("{call MAKE_SEATS(?, ?, ?)}");
            cs.setTimestamp(1, Timestamp.valueOf(startday));
            cs.setString(2, theaterid);
            cs.setString(3, scrid);
            cs.execute();
            return Protocol.T4_CD1_SUCCESS;

        } catch (SQLException sqle) {
            sqle.printStackTrace();
            return Protocol.T4_CD0_FAIL;
        } finally {
            try {
                if (pstmt != null) {
                    pstmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
                throw new RuntimeException(e.getMessage());
            }
        }
    }

    // 1.4.2 상영시간표 삭제
    public static int deleteShowing()
    {
        Connection conn = null;
        Statement stmt = null;

        String SQL1 = "DELETE FROM SHOWING WHERE SHOWING_STARTTIME < sysdate";
        String SQL2 = "DELETE FROM SEATS WHERE SEAT_TIME < sysdate";
        try
        {
            conn = DAOHandler.getConnection();
            stmt = conn.createStatement();
            stmt.executeQuery(SQL1);
            //stmt = conn.createStatement();
            stmt.executeQuery(SQL2);
            return Protocol.T10_CD1_SUCCESS;
        }
        catch (SQLException sqle)
        {
            sqle.printStackTrace();
            return Protocol.T10_CD0_FAIL;
        }
        finally
        {
            try
            {
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception e) {
                throw new RuntimeException(e.getMessage());
            }
        }
    }

}