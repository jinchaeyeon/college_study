package database.DTO;

import java.sql.Date;

public class UsersDTO
{
    private String name;
    private String id;
    private String pwd;
    private String phoneNum;
    private int classification;
    private Date birthday;

    public UsersDTO(String name, String phoneNum, Date birthday) {
        this.name = name;
        this.phoneNum = phoneNum;
        this.birthday = birthday;
    }

    public UsersDTO(String name, String id, String pwd, String phoneNum, int classification, Date birthday) {
        this.name = name;
        this.id = id;
        this.pwd = pwd;
        this.phoneNum = phoneNum;
        this.classification = classification;
        this.birthday = birthday;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public String getPhoneNum() {
        return phoneNum;
    }

    public void setPhoneNum(String phoneNum) {
        this.phoneNum = phoneNum;
    }

    public int getClassification() {
        return classification;
    }

    public void setClassification(int classification) {
        this.classification = classification;
    }

    public Date getBirthday() {
        return birthday;
    }

    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }
}
