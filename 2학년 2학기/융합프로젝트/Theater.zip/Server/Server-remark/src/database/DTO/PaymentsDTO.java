package database.DTO;

import java.sql.Timestamp;

public class PaymentsDTO
{
    private String userAcc;
    private String thAcc;
    private int personNum;
    private int movieID;
    private int totalPrice;
    private String custID;

    public PaymentsDTO(String userAcc, String thAcc, int personNum, int movieID, int totalPrice, String custID) {
        this.userAcc = userAcc;
        this.thAcc = thAcc;
        this.personNum = personNum;
        this.movieID = movieID;
        this.totalPrice = totalPrice;
        this.custID = custID;
    }

    public String getUserAcc() {
        return userAcc;
    }

    public void setUserAcc(String userAcc) {
        this.userAcc = userAcc;
    }

    public String getThAcc() {
        return thAcc;
    }

    public void setThAcc(String thAcc) {
        this.thAcc = thAcc;
    }

    public int getPersonNum() {
        return personNum;
    }

    public void setPersonNum(int personNum) {
        this.personNum = personNum;
    }

    public int getMovieID() {
        return movieID;
    }

    public void setMovieID(int movieID) {
        this.movieID = movieID;
    }

    public int getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(int totalPrice) {
        this.totalPrice = totalPrice;
    }

    public String getCustID() {
        return custID;
    }

    public void setCustID(String custID) {
        this.custID = custID;
    }
}