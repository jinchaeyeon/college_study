package database.DTO;

public class ReviewsDTO
{
    private String user_id;
    private String title;
    private String content;
    private int star;

    public ReviewsDTO(String user_id, String title, String content, int star) {
        this.user_id = user_id;
        this.title = title;
        this.content = content;
        this.star = star;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public int getStar() {
        return star;
    }

    public void setStar(int star) {
        this.star = star;
    }
}
