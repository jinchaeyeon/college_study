package database.DTO;

import java.sql.Timestamp;
import java.util.Date;

public class TicketingDTO
{
    private String custID;
    private String thID;
    private String scrID;
    private String mvName;
    private Timestamp starttime;
    private int seatRow;
    private int seatCol;
    private int price;

    public TicketingDTO(String thID, String scrID, String mvName, Timestamp starttime) {
        this.thID = thID;
        this.scrID = scrID;
        this.mvName = mvName;
        this.starttime = starttime;
    }

    public TicketingDTO(String custID, String thID, String mvName, Timestamp starttime, int seatRow, int seatCol) {
        this.custID = custID;
        this.thID = thID;
        this.mvName = mvName;
        this.starttime = starttime;
        this.seatRow = seatRow;
        this.seatCol = seatCol;
    }

    public String getCustID() {
        return custID;
    }

    public void setCustID(String custID) {
        this.custID = custID;
    }

    public String getThID() {
        return thID;
    }

    public void setThID(String thID) {
        this.thID = thID;
    }

    public String getScrID() {
        return scrID;
    }

    public void setScrID(String scrID) {
        this.scrID = scrID;
    }

    public String getMvName() {
        return mvName;
    }

    public void setMvName(String mvName) {
        this.mvName = mvName;
    }

    public Timestamp getStarttime() {
        return starttime;
    }

    public void setStarttime(Timestamp starttime) {
        this.starttime = starttime;
    }

    public int getSeatRow() {
        return seatRow;
    }

    public void setSeatRow(int seatRow) {
        this.seatRow = seatRow;
    }

    public int getSeatCol() {
        return seatCol;
    }

    public void setSeatCol(int seatCol) {
        this.seatCol = seatCol;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
}
