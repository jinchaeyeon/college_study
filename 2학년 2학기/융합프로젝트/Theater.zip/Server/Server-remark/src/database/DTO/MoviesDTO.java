package database.DTO;

import java.sql.Date;

public class MoviesDTO {
    private String title;
    private int runningTime;
    private String director;
    private String cast;
    private int grade;
    private String synopsis;
    private double star;
    private int audience_num;
    private Date playdate;
    private int movie_state;
    private String poster;
    private String stealcut1;
    private String stealcut2;
    private String stealcut3;
    private String teaser;

    public MoviesDTO(String title, int runningTime, String director, String cast, int grade, String synopsis,
                     int audience_num, Date playdate, int movie_state, String poster, String stealcut1,
                     String stealcut2, String stealcut3, String teaser) {
        this.title = title;
        this.runningTime = runningTime;
        this.director = director;
        this.cast = cast;
        this.grade = grade;
        this.synopsis = synopsis;
        this.audience_num = audience_num;
        this.playdate = playdate;
        this.movie_state = movie_state;
        this.poster = poster;
        this.stealcut1 = stealcut1;
        this.stealcut2 = stealcut2;
        this.stealcut3 = stealcut3;
        this.teaser = teaser;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getRunningTime() {
        return runningTime;
    }

    public void setRunningTime(int runningTime) {
        this.runningTime = runningTime;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public String getCast() {
        return cast;
    }

    public void setCast(String cast) {
        this.cast = cast;
    }

    public int getGrade() {
        return grade;
    }

    public void setGrade(int grade) {
        this.grade = grade;
    }

    public String getSynopsis() {
        return synopsis;
    }

    public void setSynopsis(String synopsis) {
        this.synopsis = synopsis;
    }

    public double getStar() {
        return star;
    }

    public void setStar(double star) {
        this.star = star;
    }

    public int getAudience_num() {
        return audience_num;
    }

    public void setAudience_num(int audience_num) {
        this.audience_num = audience_num;
    }

    public Date getPlaydate() {
        return playdate;
    }

    public void setPlaydate(Date playdate) {
        this.playdate = playdate;
    }

    public int getMovie_state() {
        return movie_state;
    }

    public void setMovie_state(int movie_state) {
        this.movie_state = movie_state;
    }

    public String getPoster() {
        return poster;
    }

    public void setPoster(String poster) {
        this.poster = poster;
    }

    public String getStealcut1() {
        return stealcut1;
    }

    public void setStealcut1(String stealcut1) {
        this.stealcut1 = stealcut1;
    }

    public String getStealcut2() {
        return stealcut2;
    }

    public void setStealcut2(String stealcut2) {
        this.stealcut2 = stealcut2;
    }

    public String getStealcut3() {
        return stealcut3;
    }

    public void setStealcut3(String stealcut3) {
        this.stealcut3 = stealcut3;
    }

    public String getTeaser() {
        return teaser;
    }

    public void setTeaser(String teaser) {
        this.teaser = teaser;
    }
}
