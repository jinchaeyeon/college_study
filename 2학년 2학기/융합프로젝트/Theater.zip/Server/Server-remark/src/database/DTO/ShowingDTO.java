package database.DTO;

import java.sql.Timestamp;

public class ShowingDTO
{
    private String scrID;
    private int movieID;
    private Timestamp startday;
    private String thID;

    public ShowingDTO(String scrID, int movieID, Timestamp startday, String thID) {
        this.scrID = scrID;
        this.movieID = movieID;
        this.startday = startday;
        this.thID = thID;
    }

    public String getScrID() {
        return scrID;
    }

    public void setScrID(String scrID) {
        this.scrID = scrID;
    }

    public int getMovieID() {
        return movieID;
    }

    public void setMovieID(int movieID) {
        this.movieID = movieID;
    }

    public Timestamp getStartday() {
        return startday;
    }

    public void setStartday(Timestamp startday) {
        this.startday = startday;
    }

    public String getThID() {
        return thID;
    }

    public void setThID(String thID) {
        this.thID = thID;
    }
}
