package database.DTO;

public class TheatersDTO
{
    private String thID;
    private String thName;
    private String location;
    private int screenHall_num;

    public TheatersDTO(String thName, String location, int screenHall_num) {
        this.thName = thName;
        this.location = location;
        this.screenHall_num = screenHall_num;
    }

    public TheatersDTO(String thID, String thName, String location, int screenHall_num) {
        this.thID = thID;
        this.thName = thName;
        this.location = location;
        this.screenHall_num = screenHall_num;
    }

    public String getThID() {
        return thID;
    }

    public void setThID(String thID) {
        this.thID = thID;
    }

    public String getThName() {
        return thName;
    }

    public void setThName(String thName) {
        this.thName = thName;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public int getScreenHall_num() {
        return screenHall_num;
    }

    public void setScreenHall_num(int screenHall_num) {
        this.screenHall_num = screenHall_num;
    }
}
