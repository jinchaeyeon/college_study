package database.DTO;

public class ScreenHallsDTO
{
    private String scrId;
    private String scrName;
    private int limit;
    private String thID;

    public ScreenHallsDTO(String scrId, String scrName, int limit, String thID) {
        this.scrId = scrId;
        this.scrName = scrName;
        this.limit = limit;
        this.thID = thID;
    }

    public String getScrId() {
        return scrId;
    }

    public void setScrId(String scrId) {
        this.scrId = scrId;
    }

    public String getScrName() {
        return scrName;
    }

    public void setScrName(String scrName) {
        this.scrName = scrName;
    }

    public int getLimit() {
        return limit;
    }

    public void setLimit(int limit) {
        this.limit = limit;
    }

    public String getThID() {
        return thID;
    }

    public void setThID(String thID) {
        this.thID = thID;
    }
}
