package database.DTO;

public class TicketPricesDTO
{
    private String thID;
    private int timeSection;
    private int ageSection;
    private int price;

    public TicketPricesDTO(String thID, int timeSection, int ageSection, int price) {
        this.thID = thID;
        this.timeSection = timeSection;
        this.ageSection = ageSection;
        this.price = price;
    }

    public String getThID() {
        return thID;
    }

    public void setThID(String thID) {
        this.thID = thID;
    }

    public int getTimeSection() {
        return timeSection;
    }

    public void setTimeSection(int timeSection) {
        this.timeSection = timeSection;
    }

    public int getAgeSection() {
        return ageSection;
    }

    public void setAgeSection(int ageSection) {
        this.ageSection = ageSection;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
}
