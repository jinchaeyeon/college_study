package database.DTO;

public class BanksDTO
{
    private String account_num;
    private String account_pwd;
    private String account_owner;
    private int balance;
    private int account_state;

    public BanksDTO(String account_num, String account_pwd, String account_owner, int balance, int account_state) {
        this.account_num = account_num;
        this.account_pwd = account_pwd;
        this.account_owner = account_owner;
        this.balance = balance;
        this.account_state = account_state;
    }

    public String getAccount_num() {
        return account_num;
    }

    public void setAccount_num(String account_num) {
        this.account_num = account_num;
    }

    public String getAccount_pwd() {
        return account_pwd;
    }

    public void setAccount_pwd(String account_pwd) {
        this.account_pwd = account_pwd;
    }

    public String getAccount_owner() {
        return account_owner;
    }

    public void setAccount_owner(String account_owner) {
        this.account_owner = account_owner;
    }

    public int getBalance() {
        return balance;
    }

    public void setBalance(int balance) {
        this.balance = balance;
    }

    public int getAccount_state() {
        return account_state;
    }

    public void setAccount_state(int account_state) {
        this.account_state = account_state;
    }
}
