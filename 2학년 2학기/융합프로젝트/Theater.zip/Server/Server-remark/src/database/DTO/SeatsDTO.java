package database.DTO;

import java.sql.Timestamp;

public class SeatsDTO
{
    private String seat_theater_id;
    private String seat_screenhall_id;
    private int row;
    private int col;
    private Timestamp seat_time;
    private int seat_state;

    public SeatsDTO(String seat_theater_id, String seat_screenhall_id, int row, int col, Timestamp seat_time, int seat_state) {
        this.seat_theater_id = seat_theater_id;
        this.seat_screenhall_id = seat_screenhall_id;
        this.row = row;
        this.col = col;
        this.seat_time = seat_time;
        this.seat_state = seat_state;
    }

    public String getSeat_theater_id() {
        return seat_theater_id;
    }

    public void setSeat_theater_id(String seat_theater_id) {
        this.seat_theater_id = seat_theater_id;
    }

    public String getSeat_screenhall_id() {
        return seat_screenhall_id;
    }

    public void setSeat_screenhall_id(String seat_screenhall_id) {
        this.seat_screenhall_id = seat_screenhall_id;
    }

    public int getRow() {
        return row;
    }

    public void setRow(int row) {
        this.row = row;
    }

    public int getCol() {
        return col;
    }

    public void setCol(int col) {
        this.col = col;
    }

    public Timestamp getSeat_time() {
        return seat_time;
    }

    public void setSeat_time(Timestamp seat_time) {
        this.seat_time = seat_time;
    }

    public int getSeat_state() {
        return seat_state;
    }

    public void setSeat_state(int seat_state) {
        this.seat_state = seat_state;
    }
}
