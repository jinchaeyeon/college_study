package database.DTO;

import java.sql.Timestamp;

public class ShowingJoinDTO
{
    private String screenhall_name;
    private Timestamp showing_starttime;
    private String movie_title;

    public ShowingJoinDTO(String screenhall_name, Timestamp showing_starttime, String movie_title) {
        this.screenhall_name = screenhall_name;
        this.showing_starttime = showing_starttime;
        this.movie_title = movie_title;
    }

    public String getScreenhall_name() {
        return screenhall_name;
    }

    public void setScreenhall_name(String screenhall_name) {
        this.screenhall_name = screenhall_name;
    }

    public Timestamp getShowing_starttime() {
        return showing_starttime;
    }

    public void setShowing_starttime(Timestamp showing_starttime) {
        this.showing_starttime = showing_starttime;
    }

    public String getMovie_title() {
        return movie_title;
    }

    public void setMovie_title(String movie_title) {
        this.movie_title = movie_title;
    }

    @Override
    public String toString() {
        return movie_title + " | " + screenhall_name + " | " + showing_starttime;
    }
}
