package application.network;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

public class Network {

   private static Socket socket;
   private static InputStream is;
   private static OutputStream os;

   // ��Ʈ��ũ ������
   public Network() {
      try {
         socket = new Socket("192.168.227.195", 3000);
         is = socket.getInputStream();
         os = socket.getOutputStream();
         System.out.println("���� ���� ��");
      } catch (IOException e) {
         System.err.println(e);
      }
   }
   public static int getLocalPort()
   {
      return socket.getLocalPort();
   }
   // �������� �۽�
   private static void send(Protocol protocol) throws Exception {
      try {
         os.write(protocol.getPacket());
         System.out.println("��������" + " ����");
      } catch (Exception e) {
         System.err.println(e);
      }
   }

   // �������� ����
   private static Protocol recv(int type) throws Exception {
      byte[] header = new byte[Protocol.LEN_HEADER];
      Protocol protocol = new Protocol();
      try {
         int totalReceived, readSize;
         do {
            totalReceived = 0;
            readSize = 0;
            is.read(header, 0, Protocol.LEN_HEADER);
            protocol.setPacketHeader(header);
            byte[] buf = new byte[protocol.getBodyLength()];
            while (totalReceived < protocol.getBodyLength()) {
               readSize = is.read(buf, totalReceived, protocol.getBodyLength() - totalReceived);
               totalReceived += readSize;
               if (readSize == -1) {
                  throw new Exception("��ſ���: ���� ������");
               }
            }
            protocol.setPacketBody(buf);
            if (protocol.getType() == Protocol.UNDEFINED)
               throw new Exception("��ſ���: �������� ���� �߻���");
            else if (protocol.getType() == type)
               return protocol;
         } while (true); // ���� �ʿ��� ������ �ƴҰ�� �����ϰ� ���� ������ ���
      } catch (IOException e) {
         throw new Exception("��ſ���: ������ ���� ������");
      }
   }

   // �α���
   public static int[] login(String id, String pw) throws Exception {
      Protocol protocol = new Protocol();
      int[] res = new int[2];
      if (checkuser(id) == 1) { // id�� �ִ��������� üũ
         if (checkpwd(id, pw) == 1) { // id�� pw�� �´��� üũ
            String[] body = { id, pw };

            protocol.setType(Protocol.TYPE1_LOGIN_REQ);
            protocol.setBody(body);
            send(protocol);

            protocol = recv(Protocol.TYPE2_LOGIN_RES);

            res[0] = (int) protocol.getBody();
            res[1] = (int) protocol.getCode();
         } else {
            res[1] = Protocol.T2_CD3_NOTPWD;
         }
      } else {
         res[1] = Protocol.T2_CD2_NOTUSER;
      }

      return res;
   }

   // �α׾ƿ�
   public static boolean logout(int id) throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE13_LOGOUT_REQ);
      protocol.setCode(Protocol.T13_CD0_LOGOUT);
      protocol.setBody(id);
      send(protocol);
     
      return (protocol.getCode() == 0);
   }

   // user üũ
   public static int checkuser(String id) throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE11_CHECK_REQ);
      protocol.setCode(Protocol.T11_CD0_USER);
      String[] str = { id };
      protocol.setBody(str);
         send(protocol);

         protocol = recv(Protocol.TYPE12_CHECK_RES);
        return protocol.getCode();
   }

   // pwd üũ
   public static int checkpwd(String id, String pwd) throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE11_CHECK_REQ);
      protocol.setCode(Protocol.T11_CD1_PASSWD);
      String[] str = { id, pwd };
      protocol.setBody(str);
      send(protocol);

      protocol = recv(Protocol.TYPE12_CHECK_RES);
      return protocol.getCode();
   }

   // �ܰ� üũ
   public static int checkbalance(String id, String account, String pwd) throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE11_CHECK_REQ);
      protocol.setCode(Protocol.T11_CD2_BALANCE);
      String[] str = { id, account, pwd };
      protocol.setBody(str);
      send(protocol);

      protocol = recv(Protocol.TYPE12_CHECK_RES);
      return protocol.getCode();
   }

   // ȸ������(���)
   public static int signUp(String state, String name, String id, String pwd, String phone, String birthday) throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE3_REGISTER_REQ);
      protocol.setCode(Protocol.T3_CD0_USER);
      String[] str = { state, name, id, pwd, phone, birthday };
      protocol.setBody(str);
      send(protocol);
      
      protocol = recv(Protocol.TYPE4_REGISTER_RES);
      return protocol.getCode();
     }

   // ��ȭ�� ���
   public static int Theather_req(String[] str) throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE3_REGISTER_REQ);
      protocol.setCode(Protocol.T3_CD1_THEATER);
      protocol.setBody(str);
      send(protocol);

      protocol = recv(Protocol.TYPE4_REGISTER_RES);
      return protocol.getCode();
   }
   
   // �󿵰� ���
   public static int Screenhall_req(String[] screenHall) throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE3_REGISTER_REQ);
      protocol.setCode(Protocol.T3_CD2_SCREENHALL);
      protocol.setBody(screenHall);
      send(protocol);

      protocol = recv(Protocol.TYPE4_REGISTER_RES);
      return protocol.getCode();
   }   
   
   // �¼� ���
   public static int Showing_req(String[] showing) throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE3_REGISTER_REQ);
      protocol.setCode(Protocol.T3_CD3_SHOWING);
      protocol.setBody(showing);
      send(protocol);

      protocol = recv(Protocol.TYPE4_REGISTER_RES);
      return protocol.getCode();
   }


   // Ƽ�ϰ��ݵ��
   public static int Ticketprice_req(String[] price) throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE3_REGISTER_REQ);
      protocol.setCode(Protocol.T3_CD4_TICKETPRICES);
      protocol.setBody(price);
      send(protocol);

      protocol = recv(Protocol.TYPE4_REGISTER_RES);
      return protocol.getCode();
   }
   
   // ��ȭ���
   public static int Movie_req(String[] movieImformation) throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE3_REGISTER_REQ);
      protocol.setCode(Protocol.T3_CD5_MOVIE);
      protocol.setBody(movieImformation);
      send(protocol);

      protocol = recv(Protocol.TYPE4_REGISTER_RES);
      return protocol.getCode();
   }

   // ������
   public static int Ticketing_req(String[] reservation) throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE3_REGISTER_REQ);
      protocol.setCode(Protocol.T3_CD6_TICKETING);
      protocol.setBody(reservation);
      send(protocol);
      
      protocol = recv(Protocol.TYPE4_REGISTER_RES);
      return protocol.getCode();
   }   

   // ���� ���
   public static int Payment_req(String id, String cinema, String accountNum, String pwd, String price, String movie) throws Exception {
      Protocol protocol = new Protocol();
      int result = checkbalance(id, accountNum, pwd);
      if (result == 0) { // �ܾ��� �ݾ׺��� ���� �����ִ��� üũ
         protocol.setCode(Protocol.T4_CD2_NOTBALANCE);
      } else {
         protocol.setType(Protocol.TYPE3_REGISTER_REQ);
         protocol.setCode(Protocol.T3_CD7_PAYMENT);
         String[] str = { id, cinema, accountNum, pwd, price, movie};
         protocol.setBody(str);
         send(protocol);
         protocol = recv(Protocol.TYPE4_REGISTER_RES);
      }
      return protocol.getCode();
   }

   // ���� ���
   public static int Review_req(String id, String movie, String review, String rateNum) throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE3_REGISTER_REQ);
      protocol.setCode(Protocol.T3_CD8_REVIEW);
      String[] str = { id, movie, review, rateNum };
      protocol.setBody(str);
      send(protocol);

      protocol = recv(Protocol.TYPE4_REGISTER_RES);
      return protocol.getCode();
   }   

   // ���� ��ȸ
   public static String[] ViewUser(String userid) throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE5_VIEW_REQ);
      protocol.setCode(Protocol.T5_CD0_USER);
      protocol.setBody(userid);
      send(protocol);

      protocol = recv(Protocol.TYPE6_VIEW_RES);
         return (String[]) protocol.getBody();
     }

   // ��ȭ����ȸ
   public static String[] ViewTheather() throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE5_VIEW_REQ);
      protocol.setCode(Protocol.T5_CD1_THEATER);
      send(protocol);

      protocol = recv(Protocol.TYPE6_VIEW_RES);
      return (String[]) protocol.getBody();
   }

   // �󿵰� ��ȸ
   public static String[] ViewTheatherInfo(String theaterName) throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE5_VIEW_REQ);
      protocol.setCode(Protocol.T5_CD2_THEATERINFO);
      protocol.setBody(theaterName);
      send(protocol);
         
      protocol = recv(Protocol.TYPE6_VIEW_RES);
        return (String[]) protocol.getBody();
   }

   // �󿵰���ȸ
   public static String[] ViewScreenhall(String screencode, String localDate) throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE5_VIEW_REQ);
      protocol.setCode(Protocol.T5_CD3_SCHEDULE);
      String[] str = { screencode, localDate };
      protocol.setBody(str);
      send(protocol);

      protocol = recv(Protocol.TYPE6_VIEW_RES);
      return (String[]) protocol.getBody();
   }
   
   // �¼���ȸ
   public static String[] ViewSeat(String selectTheater, String cinema, String selectTime) throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE5_VIEW_REQ);
      protocol.setCode(Protocol.T5_CD4_SEAT);
      String[] str = { cinema, selectTheater, selectTime};
      protocol.setBody(str);
      send(protocol);

      protocol = recv(Protocol.TYPE6_VIEW_RES);
      return (String[]) protocol.getBody();
   }

   // ��ȭ����Ʈ ��ȸ
   public static String[] ViewMovieList(int state) throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE5_VIEW_REQ);
      protocol.setCode(Protocol.T5_CD5_MOVIELIST);
      protocol.setBody(state);
      send(protocol);

      protocol = recv(Protocol.TYPE6_VIEW_RES);
      return (String[]) protocol.getBody();
   }

   // ��ȭ������ȸ
   public static String[] ViewMovieinformation(String movieid) throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE5_VIEW_REQ);
        protocol.setCode(Protocol.T5_CD6_MOVIEINFOMATION);
        protocol.setBody(movieid);
         send(protocol);

         protocol = recv(Protocol.TYPE6_VIEW_RES);
         return (String[]) protocol.getBody();
   }

   // ������ȸ
   public static String[] ViewTicketing(String userId, String movieName) throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE5_VIEW_REQ);
      protocol.setCode(Protocol.T5_CD7_TICKETING);
      String[] info = { userId, movieName };
      protocol.setBody(info);
      send(protocol);

      protocol = recv(Protocol.TYPE6_VIEW_RES);
        return (String[]) protocol.getBody();
   }

   // ������ȸ
   public String ViewPayment(String userid) throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE5_VIEW_REQ);
      protocol.setCode(Protocol.T5_CD8_PAYMENT);
      protocol.setBody(userid);
      send(protocol);

      protocol = recv(Protocol.TYPE6_VIEW_RES);
      return (String) protocol.getBody();
   }

   // ������ȸ
   public static String[] ViewReview(String movieName) throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE5_VIEW_REQ);
      protocol.setCode(Protocol.T5_CD9_REVIEW);
      protocol.setBody(movieName);
      send(protocol);

      protocol = recv(Protocol.TYPE6_VIEW_RES);
      return (String[]) protocol.getBody();
   }   

   // ��ȭ ��� ��ȸ
   public static String[] ViewMovieStatistical(String movieName) throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE5_VIEW_REQ);
      protocol.setCode(Protocol.T5_CD10_MOVIES_STAT);
      protocol.setBody(movieName);
      send(protocol);

      protocol = recv(Protocol.TYPE6_VIEW_RES);
      return (String[]) protocol.getBody();
   }
   
   // ��ȭ�� ��� ��ȸ
   public static String[] ViewCinemaStatistical(String cinemaName) throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE5_VIEW_REQ);
      protocol.setCode(Protocol.T5_CD11_THEATERS_STAT);;
      protocol.setBody(cinemaName);
      send(protocol);

      protocol = recv(Protocol.TYPE6_VIEW_RES);
      return (String[]) protocol.getBody();
   }

   // ���� �� �� ��ȸ
   public static String totalPrice(String[] reservationInfo) throws Exception {
        Protocol protocol = new Protocol(Protocol.TYPE5_VIEW_REQ);
        protocol.setCode(Protocol.T5_CD12_TOTALPRICE);
        protocol.setBody(reservationInfo);
        send(protocol);

        protocol = recv(Protocol.TYPE6_VIEW_RES);
        return (String) protocol.getBody();
   }
   
   // �� ���� ��ȸ
   public static String ViewStar(String movieName) throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE5_VIEW_REQ);
      protocol.setCode(Protocol.T5_CD13_TOTALSTAR);
      protocol.setBody(movieName);
      send(protocol);

      protocol = recv(Protocol.TYPE6_VIEW_RES);
      return (String) protocol.getBody();
   }

   // ������ۺ���
   public static int updateCurrentMovie() throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE7_UPDATE_REQ);
      protocol.setCode(Protocol.T7_CD0_CURRENTMOVIE);
      send(protocol);
      
      protocol = recv(Protocol.TYPE8_UPDATE_RES);
      return protocol.getCode();
   }


   // ��ȭ�� �̸� ����
   public static int updatetheathername(String curName, String changedName) throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE7_UPDATE_REQ);
      protocol.setCode(Protocol.T7_CD1_THEATHERNAME);
      String[] str = { curName, changedName };
      protocol.setBody(str);
      send(protocol);

      protocol = recv(Protocol.TYPE8_UPDATE_RES);
      return protocol.getCode();
     }

     // ��ȭ�� ��� ����
   public static int updatetheatherlocation(String cinemaName, String changeLocation) throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE7_UPDATE_REQ);
      protocol.setCode(Protocol.T7_CD2_THEATHERLOCATION);
      String[] str = { cinemaName, changeLocation };
      protocol.setBody(str);
      send(protocol);

       protocol = recv(Protocol.TYPE8_UPDATE_RES);
       return protocol.getCode();
   }

   // �󿵰� �� ����
   public static int updatescreenhall(String cinema, String screenHall) throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE7_UPDATE_REQ);
      protocol.setCode(Protocol.T7_CD3_SCREENHALLCOUNT);
      String[] str = { cinema, screenHall };
      protocol.setBody(str);
      send(protocol);

      protocol = recv(Protocol.TYPE8_UPDATE_RES);
      return protocol.getCode();
   }

   // ���� ����
   public static int deleteTicketing(String userid, String movieName) throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE9_DELETE_REQ);
      protocol.setCode(Protocol.T9_CD0_TICKETING);
      String[] info = { userid, movieName };
      protocol.setBody(info);
      send(protocol);

      protocol = recv(Protocol.TYPE10_DELETE_RES);
      return protocol.getCode();
   }

   // ���� ����
   public static int deletePayment(String userid, String cinema, String movie, String accountNum, String price) throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE9_DELETE_REQ);
      protocol.setCode(Protocol.T9_CD1_PAYMENT);
      String[] refundInfo = { userid, cinema, movie, accountNum, price };
      protocol.setBody(refundInfo);
      send(protocol);

      protocol = recv(Protocol.TYPE10_DELETE_RES);
      return protocol.getCode();
   }

   // ��ȭ�� ����
   public static int deleteTheather(String theathercode) throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE9_DELETE_REQ);
      protocol.setCode(Protocol.T9_CD2_TEATHER);
      protocol.setBody(theathercode);
      send(protocol);

      protocol = recv(Protocol.TYPE10_DELETE_RES);
      return protocol.getCode();
   }

   // �󿵰�����
   public static int deleteScreenhall(String screencode) throws Exception {
      Protocol protocol = new Protocol(Protocol.TYPE9_DELETE_REQ);
      protocol.setCode(Protocol.T9_CD3_SCREENHALL);
      protocol.setBody(screencode);
      send(protocol);

      protocol = recv(Protocol.TYPE10_DELETE_RES);
      return protocol.getCode();
   }


   // �������
   public static int deleteReview(String userid, String movieid, String selectedReview) throws Exception {
      Protocol protocol = new Protocol();
      protocol.setType(Protocol.TYPE9_DELETE_REQ);
      protocol.setCode(Protocol.T9_CD4_REVIEW);
      String[] str = { userid, movieid, selectedReview };
      protocol.setBody(str);
      send(protocol);

      protocol = recv(Protocol.TYPE10_DELETE_RES);
      return protocol.getCode();
   }
   public static int deleteShowing() throws Exception {
	      Protocol protocol = new Protocol();
	      protocol.setType(Protocol.TYPE9_DELETE_REQ);
	      protocol.setCode(Protocol.T9_CD5_SCHEDULE);
	      send(protocol);

	      protocol = recv(Protocol.TYPE10_DELETE_RES);
	      return protocol.getCode();
	   }
   
   public static int deleteMovie(String movieName) throws Exception {
	      Protocol protocol = new Protocol();
	      protocol.setType(Protocol.TYPE9_DELETE_REQ);
	      protocol.setCode(Protocol.T9_CD6_MOVIE);
	      protocol.setBody(movieName);
	      send(protocol);

	      protocol = recv(Protocol.TYPE10_DELETE_RES);
	      return protocol.getCode();
	   }
}