package application.network;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.nio.ByteBuffer;

public class Protocol {
   
   final static public int UNDEFINED            = 0;
      final static public int TYPE1_LOGIN_REQ          = 1;
      final static public int TYPE2_LOGIN_RES          = 2;
      final static public int TYPE3_REGISTER_REQ      = 3;
      final static public int TYPE4_REGISTER_RES      = 4;
      final static public int TYPE5_VIEW_REQ          = 5;
      final static public int TYPE6_VIEW_RES          = 6;
      final static public int TYPE7_UPDATE_REQ         = 7;
      final static public int TYPE8_UPDATE_RES          = 8;
      final static public int TYPE9_DELETE_REQ          = 9;
      final static public int TYPE10_DELETE_RES       = 10;
      final static public int TYPE11_CHECK_REQ          = 11;
      final static public int TYPE12_CHECK_RES          = 12;
      final static public int TYPE13_LOGOUT_REQ       = 13;
      final static public int TYPE14_LOGOUT_RES       = 14;
      final static public int EXIT                   = 15;
   
      final static public int T2_CD0_FAIL            = 0;
      final static public int T2_CD1_SUCCESS          = 1;
      final static public int T2_CD2_NOTUSER            = 2;
      final static public int T2_CD3_NOTPWD            = 3;
   
      final static public int T3_CD0_USER             = 0;
      final static public int T3_CD1_THEATER          = 1;
      final static public int T3_CD2_SCREENHALL       = 2;
      final static public int T3_CD3_SHOWING          = 3;
      final static public int T3_CD4_TICKETPRICES     = 4;
      final static public int T3_CD5_MOVIE             = 5;
      final static public int T3_CD6_TICKETING          = 6;
      final static public int T3_CD7_PAYMENT          = 7;
      final static public int T3_CD8_REVIEW            = 8;
   
      final static public int T4_CD0_FAIL             = 0;
      final static public int T4_CD1_SUCCESS          = 1;
      final static public int T4_CD2_NOTBALANCE       = 2;
   
      final static public int T5_CD0_USER            = 0;
      final static public int T5_CD1_THEATER          = 1;
      final static public int T5_CD2_THEATERINFO      = 2;
      final static public int T5_CD3_SCHEDULE          = 3;
      final static public int T5_CD4_SEAT             = 4;
      final static public int T5_CD5_MOVIELIST          = 5;
      final static public int T5_CD6_MOVIEINFOMATION  = 6;
      final static public int T5_CD7_TICKETING          = 7;
      final static public int T5_CD8_PAYMENT          = 8;
      final static public int T5_CD9_REVIEW            = 9;
      final static public int T5_CD10_MOVIES_STAT     = 10;
      final static public int T5_CD11_THEATERS_STAT   = 11;
      final static public int T5_CD12_TOTALPRICE      = 12;
      final static public int T5_CD13_TOTALSTAR       = 13;
   
      final static public int T6_CD0_USER             = 0;
      final static public int T6_CD1_THEATER          = 1;
      final static public int T6_CD2_THEATERINFO      = 2;
      final static public int T6_CD3_SCHEDULE          = 3;
      final static public int T6_CD4_SEAT             = 4;
      final static public int T6_CD5_MOVIELIST          = 5;
      final static public int T6_CD6_MOVIEINFOMATION  = 6;
      final static public int T6_CD7_TICKETING          = 7;
      final static public int T6_CD8_PAYMENT          = 8;
      final static public int T6_CD9_REVIEW            = 9;
      final static public int T6_CD10_MOVIES_STAT     = 10;
      final static public int T6_CD11_THEATERS_STAT   = 11;
      final static public int T6_CD12_TOTALPRICE      = 12;
      final static public int T6_CD13_TOTALSTAR       = 13;
      final static public int T6_FAIL                = 14;
   
      final static public int T7_CD0_CURRENTMOVIE       = 0;
      final static public int T7_CD1_THEATHERNAME     = 1;
      final static public int T7_CD2_THEATHERLOCATION = 2;
      final static public int T7_CD3_SCREENHALLCOUNT  = 3;
   
      final static public int T8_CD0_FAIL             = 0;
      final static public int T8_CD1_SUCCESS          = 1;
   
      final static public int T9_CD0_TICKETING         = 0;
      final static public int T9_CD1_PAYMENT          = 1;
      final static public int T9_CD2_TEATHER           = 2;
      final static public int T9_CD3_SCREENHALL       = 3;
      final static public int T9_CD4_REVIEW             = 4;
      final static public int T9_CD5_SCHEDULE			= 5;
      final static public int T9_CD6_MOVIE				= 6;

      final static public int T10_CD0_FAIL             = 0;
      final static public int T10_CD1_SUCCESS          = 1;
      final static public int T10_CD2_NOTUSER         = 2;
   
      final static public int T11_CD0_USER            = 0;
      final static public int T11_CD1_PASSWD            = 1;
      final static public int T11_CD2_BALANCE         = 2;
   
      final static public int T12_CD0_FAIL             = 0;
      final static public int T12_CD1_SUCCESS          = 1;
   
      final static public int T13_CD0_LOGOUT          = 0;
  
      final static public int T14_CD1_SUCCESS       = 1;
   
   
      // ����
      public static final int LEN_TYPE             = 1;
      public static final int LEN_CODE             = 1;
      public static final int LEN_BODYLENGTH          = 4;
      public static final int LEN_HEADER             = 6;

      private byte type;
      private byte code;
      private byte subcode;
      private int bodyLength;
      private byte[] body;
   
   //������
   public Protocol() {
      this(UNDEFINED, 0);
   }
   
   public Protocol(int type) {
            this(type, 0);
    }
   
   public Protocol(int type, int code) {
    setType(type);
    setCode(code);
    setBodyLength(0);
   }

    public byte getType() {
       return type;
     }
    
    public void setType(int type) {
       this.type = (byte) type;
     }

    public byte getCode() {
        return code;
   
    }
    
   public void setCode(int code) {
       this.code = (byte) code;
   }

   public int getBodyLength() {
        return bodyLength;
   }
   
   // Body Length�� ���� ������ �� ����
   private void setBodyLength(int bodyLength) { 
       this.bodyLength = bodyLength;
   }
         
   public Object getBody() {
        return deserialize(body);
   }
         
   public void setBody(Object body) {
       byte[] serializedObject = serialize(body);
         this.body = serializedObject;
         setBodyLength(serializedObject.length);
    }

   // ���� header�� body�� ��Ŷ�� �����Ͽ� ����
   public byte[] getPacket() { 
        byte[] packet = new byte[LEN_HEADER + getBodyLength()];
          packet[0] = getType();
          packet[LEN_TYPE] = getCode();
        System.arraycopy(intToByte(getBodyLength()), 0, packet, LEN_TYPE + LEN_CODE, LEN_BODYLENGTH);
         if (getBodyLength() > 0) {
           System.arraycopy(body, 0, packet, LEN_HEADER, getBodyLength());
        }
      return packet;
   }
         
   // �Ű� ���� packet�� ���� header�� ����
   public void setPacketHeader(byte[] packet) { 
        byte[] data;

        setType(packet[0]);
        setCode(packet[LEN_TYPE]);

        data = new byte[LEN_BODYLENGTH];
        System.arraycopy(packet, LEN_TYPE + LEN_CODE, data, 0, LEN_BODYLENGTH);
         setBodyLength(byteToInt(data));
   }
         
   // �Ű� ���� packet�� ���� body�� ����
   public void setPacketBody(byte[] packet) { 
         byte[] data;

         if (getBodyLength() > 0) {
             data = new byte[getBodyLength()];
            System.arraycopy(packet, 0, data, 0, getBodyLength());
            setBody(deserialize(data));
        }
   }

   // ����ȭ
   private byte[] serialize(Object b) {
      try {
         ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ObjectOutputStream oos = new ObjectOutputStream(baos);
           oos.writeObject(b);
           return baos.toByteArray();
        } catch (Exception e) {
             e.printStackTrace();
            return null;
        }
   }

   // ������ȭ
    private Object deserialize(byte[] b) {
         try {
            ByteArrayInputStream bais = new ByteArrayInputStream(b);
            ObjectInputStream ois = new ObjectInputStream(bais);
            Object ob = ois.readObject();
           return ob;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
         }
   }

   private byte[] intToByte(int i) {
        return ByteBuffer.allocate(Integer.SIZE / 8).putInt(i).array();
      }

     private int byteToInt(byte[] b) {
         return ByteBuffer.wrap(b).getInt();
   }
}