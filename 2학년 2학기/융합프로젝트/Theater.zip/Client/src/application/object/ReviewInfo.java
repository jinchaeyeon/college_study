package application.object;

public class ReviewInfo {
	private String userID;
	private String reviews;
	
	public ReviewInfo(String userID, String reviews)
	{
		this.userID = userID;
		this.reviews = reviews;
	}
	
	public void setUserID(String userID)
	{
		this.userID = userID;
	}
	public void setReviews(String userID)
	{
		this.reviews = reviews;
	}
	public String getReviews()
	{
		return reviews;
	}
	public String getUserID()
	{
		return userID;
	}
}
