package application.object;

public class User 
{
	  private static User user = null;
	  private String ID;
	  
	  private User() {}
	  
	  public static User getInstance() {
		 if(user == null)
		 {
			 user = new User();
		 }
		 return user;
	  }
	  public String getID()
	  {
		  return ID;
	  }
	  public void setID(String ID)
	  {
		  this.ID = ID;
	  }
}
