package application.object;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.embed.swing.JFXPanel;
import javafx.scene.control.ListView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class Cinema
{
	private ObservableList<String> list = FXCollections.observableArrayList();
	private String cinemaName;
	private String name;
	private String theater;
	private int runtime;
	private int seat;
	private ImageView posterIMG;
	private ListView<String> movieSchedule;
	public Cinema(String cinema, String moviePoster, String name, String theater, String[] movieSchedule, int runtime, int seat) 
	{
		cinemaName = cinema;
		posterIMG = new ImageView();
		posterIMG.setImage(new Image(moviePoster));
		posterIMG.setFitHeight(100);
		posterIMG.setFitWidth(100);
		
		this.movieSchedule = new ListView<String>();
		list.addAll(movieSchedule);
		this.movieSchedule.getItems().addAll(list);
		
		this.name = name;
		this.theater = theater;
		this.runtime = runtime;
		this.seat = seat;
	}
	public String getCinemaName() 
	{
		return cinemaName;
	}
	public void setCinemaName(String cinemaName) 
	{
		this.cinemaName = cinemaName;
	}
	public String getName() {
		return name;
	}
	public void setName(String name)
	{
		this.name = name;
	}
	public String getTheater() {
		return theater;
	}
	public void setTheater(String theater) 
	{
		this.theater = theater;
	}
	public int getRuntime() {
		return runtime;
	}
	public void setRuntime(int runtime) 
	{
		this.runtime = runtime;
	}
	public int getSeat() {
		return seat;
	}
	public void setSeat(int seat) 
	{
		this.seat = seat;
	}
	public ImageView getPosterIMG() 
	{
		return posterIMG;
	}
	public void setPosterIMG(ImageView poster)
	{
		this.posterIMG = poster;
	}
	public ListView getMovieSchedule() 
	{
		return movieSchedule;
	}
	public void setmovieSchedule(ListView movieSchedule)
	{
		this.movieSchedule = movieSchedule;
	}
}
