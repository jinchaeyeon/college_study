package application.controller;

import application.network.Network;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

public class ShowingRegisterController {
	@FXML
	private TextField screenHall; //�󿵰�
	@FXML
	private TextField movie; //��ȭ ����
	@FXML
	private TextField startTime; //���� �ð�
	@FXML
	private TextField cinema; //��ȭ��

	@FXML
	public void Register(MouseEvent event) throws Exception { 

		String[] showingImformation = new String[4];
		showingImformation[0] = cinema.getText();
		showingImformation[1] = screenHall.getText();
		showingImformation[2] = movie.getText();
		showingImformation[3] = startTime.getText();
		int screnHallResult = Network.Showing_req(showingImformation); //�� �ð�ǥ ���

		Alert alert = new Alert(AlertType.CONFIRMATION);
		alert.setTitle("Confirmation Dialog");
		alert.setHeaderText("�޼����� Ȯ���Ͻʽÿ�");
		if (screnHallResult == 1) {
			alert.setContentText("�� �ð�ǥ ��� ����");
			alert.showAndWait();

		} else {
			alert.setContentText("�� �ð�ǥ ��� ����");
			alert.showAndWait();
		}
		Stage stage = (Stage) screenHall.getScene().getWindow();
		stage.close();
	}
}
