package application.controller;

import java.net.URL;
import java.util.ResourceBundle;

import application.network.Network;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ListView;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;

public class StatisticalChartController implements Initializable {
	private ObservableList<String> list = FXCollections.observableArrayList();
	@FXML
	private Text reservationRate; //��ȭ�� ������
	@FXML
	private Text movieCancledRate; //��ȭ �����
	@FXML
	private Text movieStarRate; //����
	@FXML
	private Text totalAudience; //���� ������
	@FXML
	private Text movieReservationRate; //��ȭ ������
	@FXML
	private Text earningsRate; //����
	@FXML
	private Text cancledRate; //��ȭ�� ����� 
	@FXML
	private Text totalEarningsRate; //�� ����

	@FXML
	private ListView<String> cinemaList; //��ȭ�� ���
	@FXML
	private ListView<String> movieList; //��ȭ ���

	@Override
	public void initialize(URL url, ResourceBundle rb) {

		try {
			list.removeAll(list);
			list.addAll(Network.ViewTheather());
			cinemaList.getItems().addAll(list);
			list.removeAll(list);
			list.addAll(Network.ViewMovieList(0));
			list.addAll(Network.ViewMovieList(1));
			movieList.getItems().addAll(list);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void EnterCinema(MouseEvent event) throws Exception {
		String[] cinemaInfo = Network.ViewCinemaStatistical(cinemaList.getSelectionModel().getSelectedItem());
		reservationRate.setText(cinemaInfo[0]);
		cancledRate.setText(cinemaInfo[1]);
		earningsRate.setText(cinemaInfo[2]);
		totalEarningsRate.setText(cinemaInfo[3]);
	}

	public void EnterMovie(MouseEvent event) throws Exception {
		String[] movieInfo = Network.ViewMovieStatistical(movieList.getSelectionModel().getSelectedItem());
		movieReservationRate.setText(movieInfo[0]);
		movieCancledRate.setText(movieInfo[1]);
		movieStarRate.setText(movieInfo[2]);
		totalAudience.setText(movieInfo[3]);
	}
}