package application.controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

import application.network.Network;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class ManagerSideController implements Initializable {
	@FXML
	private BorderPane bp;
	@FXML
	private AnchorPane ap;

	public void initialize(URL url, ResourceBundle rb) {
		loadPage("AboutMovie");
	}

	@FXML
	private void AboutMovie(MouseEvent event) // ��ȭ ���� ����
	{
		loadPage("AboutMovie");
	}

	@FXML
	private void AboutTheater(MouseEvent event) // ��ȭ�� ���� ����
	{
		loadPage("AboutTheater");
	}

	@FXML
	private void StatisticalChart(MouseEvent event) // ��ȭ����, ��ȭ�� ���
	{
		loadPage("StatisticalChart");
	}

	@FXML
	private void Logout(MouseEvent event) throws IOException {
		try {
			Network.logout(Network.getLocalPort()); //�α׾ƿ��� ���� �������� ��û
		} catch (Exception e) {
			e.printStackTrace();
		}
		Stage stage = (Stage) bp.getScene().getWindow();
		stage.close();
	}

	private void loadPage(String page) // ������ ��û
	{
		Parent root = null;
		try {
			root = FXMLLoader.load(getClass().getResource("/application/view/" + page + ".fxml"));
		} catch (IOException ex) {
			Logger.getLogger(ManagerSideController.class.getName()).log(Level.SEVERE, null, ex);
		}

		bp.setCenter(root);
	}
}
