package application.controller;

import application.network.Network;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

public class DeleteScreenHallController {

	@FXML
	private TextField id; // �󿵰� ID

	@FXML
	public void Delete(MouseEvent evnet) throws Exception {
		int result = Network.deleteScreenhall(id.getText()); // �󿵰� ID�� ��� �󿵰� ���� ��û

		Alert alert = new Alert(AlertType.CONFIRMATION);
		alert.setTitle("Confirm Dialog");
		alert.setHeaderText("�޼����� Ȯ���Ͻʽÿ�.");

		if (result == 1) {
			alert.setContentText("���� ����");
			alert.showAndWait();
		} else {
			alert.setContentText("���� ����");
			alert.showAndWait();
		}
		Stage stage = (Stage) id.getScene().getWindow();
		stage.close();
	}
}
