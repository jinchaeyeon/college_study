package application.controller;

import application.network.Network;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

public class ScreenHallController {

	@FXML
	private TextField name;//�󿵰� �̸�
	@FXML
	private TextField id; //�󿵰� ID
	@FXML
	private TextField cinema; //��ȭ��
	@FXML
	private TextField seats; //�ִ� �¼� ��

	@FXML
	void Register(MouseEvent event) throws Exception {

		String[] screenHallImformation = new String[4];
		screenHallImformation[0] = id.getText();
		screenHallImformation[1] = name.getText();
		screenHallImformation[2] = seats.getText();
		screenHallImformation[3] = cinema.getText();
		int screnHallResult = Network.Screenhall_req(screenHallImformation); //�󿵰� ��� ��û

		Alert alert = new Alert(AlertType.CONFIRMATION);
		alert.setTitle("Confirmation Dialog");
		alert.setHeaderText("�޼����� Ȯ���Ͻʽÿ�");
		if (screnHallResult == 1) {
			alert.setContentText("�󿵰� ��� ����");
			alert.showAndWait();

		} else {
			alert.setContentText("�󿵰� ��� ����");
			alert.showAndWait();
		}
		Stage stage = (Stage) name.getScene().getWindow();
		stage.close();
	}

}
