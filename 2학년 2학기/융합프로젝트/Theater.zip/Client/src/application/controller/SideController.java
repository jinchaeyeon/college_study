package application.controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

import application.network.Network;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class SideController implements Initializable {
	@FXML
	private BorderPane bp;
	@FXML
	private AnchorPane ap;
	@FXML
	private Button logout;

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) { //���� ȭ�� ����
		loadPage("Home");
	}

	@FXML
	private void Home(MouseEvent event) { //���� ������ ��û
		loadPage("Home");
	}

	@FXML
	private void SelectCinema(MouseEvent event) { //��ȭ ���� ������ ��û
		loadPage("SelectCinema");
	}

	@FXML
	private void MyPage(MouseEvent event) { //���� ������ ��û
		loadPage("MyPage");
	}

	@FXML
	private void Logout(MouseEvent event) throws IOException {
		try {
			Network.logout(Network.getLocalPort()); //�α׾ƿ��� ���� �������� ��û
		} catch (Exception e) {
			e.printStackTrace();
		}
		Stage stage = (Stage) logout.getScene().getWindow();
		stage.close();
	}

	@FXML
	private void loadPage(String page) {
		Parent root = null;
		try {
			root = FXMLLoader.load(getClass().getResource("/application/view/" + page + ".fxml"));
			bp.setCenter(root);

		} catch (IOException ex) {
			Logger.getLogger(SideController.class.getName()).log(Level.SEVERE, null, ex);
		}
	}
}
