package application.controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import application.network.Network;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ListView;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

public class AboutTheaterController implements Initializable {
	private ObservableList<String> list = FXCollections.observableArrayList();
	@FXML
	ListView<String> cinemaList;

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		try {
			list.addAll(Network.ViewTheather()); // ��ȭ�� ��� ��û
		} catch (Exception e) {
			e.printStackTrace();
		}
		cinemaList.setItems(list);
	}

	@FXML
	public void Register(MouseEvent evnet) throws IOException // ��ȭ�� ���
	{
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/view/CinemaRegister.fxml"));
		Parent root = loader.load();
		Stage stage = new Stage();
		stage.setScene(new Scene(root));
		stage.show();
	}

	@FXML
	public void DeleteCinema(MouseEvent evnet) throws Exception // ��ȭ�� ����
	{
		int result = Network.deleteTheather(cinemaList.getSelectionModel().getSelectedItem()); // ���õ� ��ȭ�� ���� ��û

		Alert alert = new Alert(AlertType.CONFIRMATION);
		alert.setTitle("Confirm Dialog");
		alert.setHeaderText("�޼����� Ȯ���Ͻʽÿ�.");

		if (result == 1) {
			alert.setContentText("���� ����");
			alert.showAndWait();
		} else {
			alert.setContentText("���� ����");
			alert.showAndWait();
		}
	}

	@FXML
	public void DeleteScreenHall(MouseEvent evnet) throws Exception // �󿵰� ����
	{
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/view/DeleteScreenHall.fxml"));
		Parent root = loader.load();
		Stage stage = new Stage();
		stage.setScene(new Scene(root));
		stage.show();
	}

	@FXML
	public void RegisterScreenHall(MouseEvent event) throws IOException // �󿵰� ���
	{
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/view/ScreenHall.fxml"));
		Parent root = loader.load();
		Stage stage = new Stage();
		stage.setScene(new Scene(root));
		stage.show();
	}

	@FXML
	public void ShowingRegister(MouseEvent event) throws IOException // �󿵽ð�ǥ ���
	{
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/view/ShowingRegister.fxml"));
		Parent root = loader.load();
		Stage stage = new Stage();
		stage.setScene(new Scene(root));
		stage.show();
	}

	@FXML
	public void RegisterPrice(MouseEvent event) throws IOException // ���� ���
	{
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/view/RegisterPrice.fxml"));
		Parent root = loader.load();
		Stage stage = new Stage();
		stage.setScene(new Scene(root));
		stage.show();
	}

	@FXML
	public void Rename(MouseEvent event) throws IOException // ��ȭ�� �̸� �缳��
	{
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/view/Rename.fxml"));
		Parent root = loader.load();
		Stage stage = new Stage();
		stage.setScene(new Scene(root));
		stage.show();
	}

	@FXML
	public void ChangeLocation(MouseEvent event) throws IOException // ��ȭ�� �ּ� ����
	{
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/view/ChangeLocation.fxml"));
		Parent root = loader.load();
		Stage stage = new Stage();
		stage.setScene(new Scene(root));
		stage.show();
	}

	@FXML
	public void ChangeScreenHallNum(MouseEvent event) throws IOException // ��ȭ���� �󿵰� �� ����
	{
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/view/ChangeScreenHallNum.fxml"));
		Parent root = loader.load();
		Stage stage = new Stage();
		stage.setScene(new Scene(root));
		stage.show();
	}
	@FXML
	public void DeleteShowing(MouseEvent event) throws Exception //�� �ð�ǥ ���� -> �ð��� ������ ���
	{
		int result = Network.deleteShowing();

		Alert alert = new Alert(AlertType.CONFIRMATION);
		alert.setTitle("Confirm Dialog");
		alert.setHeaderText("�޼����� Ȯ���Ͻʽÿ�.");

		if (result == 1) {
			alert.setContentText("���� ����");
			alert.showAndWait();
		} else {
			alert.setContentText("���� ����");
			alert.showAndWait();
		}
	}
	@FXML
	private void CinemaInfo(MouseEvent event) throws Exception { //��ȭ�� ����
		String[] cinemaInfo = Network.ViewTheatherInfo(cinemaList.getSelectionModel().getSelectedItem()); //���õ� ��ȭ���� ���� ��û
		FXMLLoader loader = new FXMLLoader(getClass().getResource("/application/view/CinemaInfo.fxml"));
		Parent root = loader.load();
		CinemaInfoController ci = loader.<CinemaInfoController>getController();
		ci.setInfo(cinemaList.getSelectionModel().getSelectedItem(), cinemaInfo);

		Stage stage = new Stage();
		stage.setScene(new Scene(root));
		stage.show();
	}
}
