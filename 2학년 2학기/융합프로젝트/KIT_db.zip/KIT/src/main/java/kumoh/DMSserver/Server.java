package kumoh.DMSserver;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Vector;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.imageio.ImageIO;

import kumoh.core.Protocol;
import kumoh.core.model.*;
import kumoh.DMSserver.DAO.*;

public class Server {
	private final static int PORT = 9999;
	private final static int MAX_USER = 50;
	public static boolean isAdminLogin = false;
	public static HashMap<String,Boolean> logined = new HashMap<String, Boolean>();
	public static void start() {
		try {
			ExecutorService pool = Executors.newFixedThreadPool(MAX_USER);
			ServerSocket theServer = new ServerSocket(PORT);
			System.out.println("Client Wait...");

			while (true) {
				Socket connection = theServer.accept();
				Callable<Void> task = new Task(connection); // 클라이언트마다 쓰레드 하나와 연결한다
				pool.submit(task);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private static class Task implements Callable<Void> {
		private Socket socket;
		private OutputStream os;
		private InputStream is;
		private String userID = "";
		private Boolean isAdmin = false;
		private RecruitDate rcd = null;

		Task(Socket connection) throws IOException {
			this.socket = connection;
			os = socket.getOutputStream();
			is = socket.getInputStream();
		}

		public Void call() {
			byte[] header = new byte[Protocol.LEN_HEADER];
			Protocol protocol = new Protocol();
			System.out.println("Client Connected");
			try {
				int totalReceived, readSize;
				while (true) {
					totalReceived = 0;
					readSize = 0;
					is.read(header, 0, Protocol.LEN_HEADER);
					protocol.setPacketHeader(header);
					byte[] buf = new byte[protocol.getBodyLength()];
					while (totalReceived < protocol.getBodyLength()) {
						readSize = is.read(buf, totalReceived, protocol.getBodyLength() - totalReceived);
						totalReceived += readSize;
						System.out.println(userID + " : Data Received (" + totalReceived + "/" + protocol.getBodyLength() + ")");
						if (readSize == -1) {
							print(userID + " 클라이언트가 종료됨");
							return null;
						}
					}
					protocol.setPacketBody(buf);
					
					switch (protocol.getType()) {
					case Protocol.TYPE_UNDEFINED:
						ping();
						break;
					case Protocol.TYPE_EXIT:
						exit();
						return null;
					case Protocol.TYPE_LOGIN_REQ:
						login(protocol);
						break;
					case Protocol.TYPE_LOGOUT_REQ:
						//this.testApplies(); // ** 테스트용 코드 삭제요망
						logout(protocol);
						break;
					case Protocol.TYPE_STUDENT_INFO_REQ:
						getStudent(protocol);
						break;
					case Protocol.TYPE_QUERY_SERVERTIME_REQ:
						queryServerTime(protocol);
						break;
					case Protocol.TYPE_DATAPACKAGE_INFO_REQ:
						getDataPackage(protocol);
						break;
					case Protocol.TYPE_DATAPACKAGE_CREATE_REQ:
						createDataPackage(protocol);
						break;
					case Protocol.TYPE_DATAPACKAGE_UPDATE_REQ:
						updateDataPackage(protocol);
						break;
					case Protocol.TYPE_RECRUITDATES_INFO_REQ:
						getRecruitDates(protocol);
						break;
					case Protocol.TYPE_RECRUITDATE_SELECT_REQ:
						selectRecruitDate(protocol);
						break;
					case Protocol.TYPE_SCHEDULES_INFO_REQ:
						getSchedules(protocol);
						break;
					case Protocol.TYPE_SCHEDULE_CHECK_REQ:
						checkSchedule(protocol);
						break;
					case Protocol.TYPE_SCHEDULE_CHECK2_REQ:
						checkSchedule2(protocol);
						break;
					case Protocol.TYPE_RECRUITS_INFO_REQ:
						getRecruits(protocol);
						break;
					case Protocol.TYPE_SUBRECRUITS_INFO_REQ:
						getSubRecruits(protocol);
						break;
					case Protocol.TYPE_SUBRECRUIT_INFO_REQ:
						getSubRecruit(protocol);
						break;
					case Protocol.TYPE_SUBRECRUIT_CREATE_REQ:
						createSubRecruit(protocol);
						break;
					case Protocol.TYPE_SUBRECRUIT_UPDATE_REQ:
						updateSubRecruit(protocol);
						break;
					case Protocol.TYPE_APPLIES_INFO_REQ:
						getApplies(protocol);
						break;
					case Protocol.TYPE_APPLY_INFO_REQ:
						getApply(protocol);
						break;
					case Protocol.TYPE_APPLY_CREATE_REQ:
						createApply(protocol);
						break;
					case Protocol.TYPE_APPLY_UPDATE_REQ:
						updateApply(protocol);
						break;
					case Protocol.TYPE_SELECTIONS_INFO_REQ:
						getSelections(protocol);
						break;
					case Protocol.TYPE_SELECTION_INFO_REQ:
						getSelection(protocol);
						break;
					case Protocol.TYPE_SELECTION_VALID_REQ:
						validSelection(protocol);
						break;
					case Protocol.TYPE_SELECTION_VALID2_REQ:
						validSelection2(protocol);
						break;
					case Protocol.TYPE_SELECTION_WAITNUM_REQ:
						getWaitNum(protocol);
						break;
					case Protocol.TYPE_ACCEPT_FILE_REQ:
						acceptFile(protocol);
						break;
					case Protocol.TYPE_ACCEPT_INVOICE_REQ:
						acceptInvoice(protocol);
						break;
					case Protocol.TYPE_FILE_UPLOAD_REQ:
						uploadFile(protocol);
						break;
					case Protocol.TYPE_FILE_DOWNLOAD_REQ:
						downloadFile(protocol);
						break;
					case Protocol.TYPE_SELECTION_ENROLL_REQ:
						enrollSelection(protocol);
						break;
					case Protocol.TYPE_BED_ENROLL_REQ:
						enrollBed(protocol);
						break;
					case Protocol.TYPE_BED_FREE_REQ:
						freeBeds(protocol);
						break;
					}
				}
			} catch (IOException e) { // 연결 오류 발생시
				try {
					System.out.println(userID + " Client : Connection Error Occured");
					Mysql mysql = Mysql.getConnection();
					mysql.rollback();
					mysql.setAutoCommit(true);
					logging(e);
					is.close();
					os.close();
					socket.close();
				} catch (Exception ex) {
					System.out.println(userID + " Client : Connection Error Process Failed");
					e.printStackTrace();
				}
				return null;
			} catch (SQLException e) { // DB 접속 오류 발생시
				try {
					System.out.println(userID + " Client : DB Error Occured");
					Mysql mysql = Mysql.getConnection();
					mysql.rollback();
					mysql.setAutoCommit(true);
					logging(e);
					Protocol sndData = new Protocol();
					sndData.setType(Protocol.TYPE_ERROR);
					os.write(sndData.getPacket());
					is.close();
					os.close();
					socket.close();
				} catch (Exception ex) {
					System.out.println(userID + " Client : DB Error Process Failed");
					e.printStackTrace();
				}
				return null;
			} catch (Exception e) { // 일반 오류 발생시
				try {
					System.out.println(userID + " Client : General Error Occured");
					Mysql mysql = Mysql.getConnection();
					mysql.rollback();
					mysql.setAutoCommit(true);
					logging(e);
					Protocol sndData = new Protocol();
					sndData.setType(Protocol.TYPE_ERROR);
					os.write(sndData.getPacket());
					is.close();
					os.close();
					socket.close();
				} catch (Exception ex) {
					System.out.println(userID + " Client : General Error Process Failed");
					e.printStackTrace();
				}
			}
			finally {
				if (this.isAdmin == true) Server.isAdminLogin = false;
				else if (this.isAdmin == false && Server.logined.containsKey(userID) == true) Server.logined.remove(userID);
			}
			return null;
		}
		// ## 오류 발생시 DB에 서버 오류를 저장하는 메소드
		// 테스트 이후는 코드를 제외하는것이 맞을듯??
		private void logging(Exception e) throws IOException, SQLException, Exception{
			print(userID + " 클라이언트 : 발생 오류 기록");
			if (true) {
			StringWriter errors = new StringWriter();
			e.printStackTrace(new PrintWriter(errors));

			Mysql mysql = Mysql.getConnection();	
			mysql.sql("INSERT INTO `log` (`logID`, `logType`, `logText`, `logDate`, `logIP`) VALUES (NULL, ?, ?, ?, ?)");
			mysql.set(1, "Error");
			mysql.set(2, errors.toString().replaceAll("at ", "<br> "));
			mysql.set(3, LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
			mysql.set(4, socket.getRemoteSocketAddress().toString());
			mysql.insert();
			}
			else {
				e.printStackTrace();
			}
		}
		
		// ## 로그 한글 출력이 안되서 db에 저장
		// 일반 사용시엔 그냥 print
		private static String logId = null;
		private void print(String str) throws IOException, SQLException, Exception {
			Mysql mysql = Mysql.getConnection();	
			if (true) {
				if (logId == null) {
					mysql.sql(
							"INSERT INTO `log` (`logID`, `logType`, `logText`, `logDate`, `logIP`) VALUES (NULL, ?, ?, ?, ?)");
					mysql.set(1, "Log");
					mysql.set(2, "Server Start<br>");
					mysql.set(3, LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
					mysql.set(4, "Server");
					mysql.insert();

					mysql.sql("SELECT * FROM `log` WHERE `logType`='Log' ORDER BY `logDate` DESC LIMIT 1");
					ResultSet rs = mysql.select();
					if (rs.next()) {
						logId = rs.getString("logId");
					}
				} else {
					mysql.sql("UPDATE `log` SET `logText` = CONCAT(`logText`, ?) WHERE `logId` = ?");
					mysql.set(1, str + "<br>");
					mysql.set(2, logId);
					mysql.update();
				}
			} else {
				System.out.println(str);
			}

		}
		
		// ----- 통신코드 시작!!

		// ## 통신확인
		private void ping() throws IOException, SQLException, Exception {
			print(userID + " 클라이언트 : PING 메시지");

			Protocol sndData = new Protocol();
			sndData.setType(Protocol.TYPE_UNDEFINED);
			os.write(sndData.getPacket());
		}

		// ## 프로그램 종료
		private void exit() throws IOException, SQLException, Exception {
			print(userID + " 클라이언트 : 종료 메시지");
			if (this.isAdmin == true) Server.isAdminLogin = false;
			else if (this.isAdmin == false && Server.logined.containsKey(userID) == true) Server.logined.remove(userID);
			
			is.close();
			os.close();
			socket.close();
			System.out.println(userID + " Client : Closed");
		}

		// ## 로그인
		private void login(Protocol rcvData) throws IOException, SQLException, Exception { // 로그인
			print(userID + " 클라이언트 : 로그인 요청");
			String[] str = (String[]) rcvData.getBody();
			Mysql mysql = Mysql.getConnection();

			mysql.sql("SELECT `아이디`, `성명`, `패스워드`, '관리자' AS 권한 FROM `관리자` WHERE `아이디` = ? UNION SELECT `학번` as 아이디, `성명`, `패스워드`, '학생' AS 권한 FROM `학생` WHERE `학번`= ? LIMIT 1");
			mysql.set(1, str[0]);
			mysql.set(2, str[0]);
			ResultSet rs = mysql.select();

			Protocol sndData = new Protocol(Protocol.TYPE_LOGIN_RES);
			if (rs.next() && rs.getString("패스워드").equals(str[1])) { // 아이디 일치 + 패스워드 일치
				
				if (rs.getString("권한").equals("관리자") == true && Server.isAdminLogin == true) {
					sndData.setCode(2);
					os.write(sndData.getPacket());
					return;
				}
				else if (rs.getString("권한").equals("학생") == true && logined.containsKey(rs.getString("아이디")) == true) {
					sndData.setCode(2);
					os.write(sndData.getPacket());
					return;
				}
				this.userID = rs.getString("아이디");
				this.isAdmin = rs.getString("권한").equals("관리자");
				if (this.isAdmin == true) Server.isAdminLogin = true; 
				else if (this.isAdmin == false) Server.logined.put(rs.getString("아이디"), true);
				str[0] = rs.getString("권한");
				sndData.setCode(1);
				sndData.setBody(str[0]);
			} else {
				sndData.setCode(0);
				sndData.setBody(null);
			}
		
			os.write(sndData.getPacket());
		}
		
		// ## 로그아웃
		private void logout(Protocol rcvData) throws IOException, SQLException, Exception {
			print(userID + " 클라이언트 : 로그아웃 요청");
			
			if (this.isAdmin == true) Server.isAdminLogin = false;
			else if (this.isAdmin == false && Server.logined.containsKey(userID) == true) Server.logined.remove(userID);
			
			this.userID = "";
			this.isAdmin = false;
			this.rcd = null;
			
			Protocol sndData = new Protocol(Protocol.TYPE_LOGOUT_RES, 1);
			os.write(sndData.getPacket());	
		}
		
		// ## 학생정보 조회 (자기자신)
		private void getStudent(Protocol rcvData) throws IOException, SQLException, Exception { // 학생정보
			print(userID + " 클라이언트 : 학생정보 요청");

			StudentDAO studentDAO = StudentDAO.getInstance();
			Student student = studentDAO.getStudent(userID);

			Protocol sndData = new Protocol(Protocol.TYPE_STUDENT_INFO_RES, 1);
			if (student == null) {
				sndData.setCode(0);
			} else {
				sndData.setCode(1);
				sndData.setBody(student);
			}
			os.write(sndData.getPacket());
		}
		
		// ## 서버시간 조회 ㅠ
		private void queryServerTime(Protocol rcvData) throws IOException, SQLException, Exception {
			Protocol sndData = new Protocol(Protocol.TYPE_QUERY_SERVERTIME_RES, 1);

			sndData.setBody(LocalDateTime.now());
			os.write(sndData.getPacket());
		}

		// ## 관리 데이터 집합 조회 요청 (단일 년도/학기)
		private void getDataPackage(Protocol rcvData) throws IOException, SQLException, Exception {
			print(userID + " 클라이언트 : 관리 데이터 집합 조회 요청");
			
			DataPackage pkg = new DataPackage();
			
			// 1. 년도학기
			RecruitDateDAO recruitDateDAO = RecruitDateDAO.getInstance();
			pkg.setRecruitDate(recruitDateDAO.getRecruitDate(rcd.getYear(), rcd.getTerm()));
			
			// 2. 일정
			ScheduleDAO scheduleDAO = ScheduleDAO.getInstance();
			pkg.setSchedules(scheduleDAO.getSchedules(rcd.getYear(), rcd.getTerm()));
			
			// 3. 모집 
			RecruitDAO recruitDAO = RecruitDAO.getInstance();
			pkg.setRecruits(recruitDAO.getRecruits(rcd.getYear(), rcd.getTerm()));
			
			// 4. 모집의 모집관계 + 모집의 식사정보
			RecruitRelationDAO recruitRelationDAO = RecruitRelationDAO.getInstance();
			MealDAO mealDAO = MealDAO.getInstance();
			for (Recruit recruit : pkg.getRecruits()) {
				recruit.setSubRecruit(recruitRelationDAO.getRecruitRelations(recruit.getYear(), recruit.getTerm(), recruit.getName()));
				recruit.setMeal(mealDAO.getMeals(recruit.getYear(), recruit.getTerm(), recruit.getName()));
			}
			
			Protocol sndData = new Protocol(Protocol.TYPE_DATAPACKAGE_INFO_RES, 1);
			sndData.setBody(pkg);
			os.write(sndData.getPacket());
		}
		
		// ## 관리 데이터 집합 등록 요청 (단일 년도/학기)
		private void createDataPackage(Protocol rcvData) throws IOException, SQLException, Exception {
			print(userID + " 클라이언트 : 관리 데이터 집합 등록 요청");
			
			DataPackage pkg = (DataPackage) rcvData.getBody();
			
			Mysql mysql = Mysql.getConnection();
			mysql.setAutoCommit(false);

			// 0. 년도학기 정보 확인
			RecruitDate recruitDate = pkg.getRecruitDate();
			RecruitDateDAO recruitDateDAO = RecruitDateDAO.getInstance();
			if (recruitDateDAO.getRecruitDate(recruitDate.getYear(), recruitDate.getTerm()) != null) { // 해당 년도학기가 존재 
				mysql.setAutoCommit(true);
				Protocol sndData = new Protocol(Protocol.TYPE_DATAPACKAGE_CREATE_RES, 0);
				os.write(sndData.getPacket());
				return;
			}
			
			// 1. 년도학기
			recruitDateDAO.insertRecruitDate(pkg.getRecruitDate());
			
			// 2. 일정
			if (pkg.getSchedules() != null) {
				ScheduleDAO scheduleDAO = ScheduleDAO.getInstance();
				for (Schedule schedule : pkg.getSchedules()) {
					scheduleDAO.insertSchedule(schedule);
				}
			}
			
			// 3. 모집
			if (pkg.getRecruits() != null) {
				RecruitDAO recruitDAO = RecruitDAO.getInstance();
				for (Recruit recruit : pkg.getRecruits()) {
					recruitDAO.insertRecruit(recruit);

					// 4. 모집의 모집관계
					RecruitRelationDAO recruitRelationDAO = RecruitRelationDAO.getInstance();
					for (String subRecruit : recruit.getSubRecruit()) {
						recruitRelationDAO.insertRecruitRelation(recruit.getYear(), recruit.getTerm(),
								recruit.getName(), subRecruit);
					}

					// 5. 모집의 식사정보
					MealDAO mealDAO = MealDAO.getInstance();
					for (Meal meal : recruit.getMeal()) {
						mealDAO.insertMeal(meal);
					}
				}
			}
			
			mysql.commit();
			mysql.setAutoCommit(true);
			
			Protocol sndData = new Protocol(Protocol.TYPE_DATAPACKAGE_CREATE_RES, 1);
			os.write(sndData.getPacket());
		}
		
		// ## 관리 데이터 집합 갱신 요청 (단일 년도/학기)
		private void updateDataPackage(Protocol rcvData) throws IOException, SQLException, Exception {
			print(userID + " 클라이언트 : 관리 데이터 집합 갱신 요청");
			
			if (!isAdmin) {
				Protocol sndData = new Protocol(Protocol.TYPE_DATAPACKAGE_UPDATE_RES, 0);
				os.write(sndData.getPacket());
				return;
			}
			
			DataPackage pkg = (DataPackage) rcvData.getBody();
			
			Mysql mysql = Mysql.getConnection();
			mysql.setAutoCommit(false);
			
			// 0. 년도학기 정보 확인
			RecruitDate recruitDate = pkg.getRecruitDate();
			RecruitDateDAO recruitDateDAO = RecruitDateDAO.getInstance();
			if (recruitDateDAO.getRecruitDate(recruitDate.getYear(), recruitDate.getTerm()) == null) { // 해당 년도학기가 존재하지 않음
				mysql.setAutoCommit(true);
				Protocol sndData = new Protocol(Protocol.TYPE_DATAPACKAGE_UPDATE_RES, 0);
				os.write(sndData.getPacket());
				return;
			}
			
			// 1. 년도학기
			recruitDateDAO.updateRecruitDate(pkg.getRecruitDate());
			
			// 2. 일정
			ScheduleDAO scheduleDAO = ScheduleDAO.getInstance();
			// 일정 전체 삭제후
			scheduleDAO.deleteSchedules(recruitDate.getYear(), recruitDate.getTerm());
			if (pkg.getSchedules() != null) {
				// 일정 재생성
				for (Schedule schedule : pkg.getSchedules()) {
					scheduleDAO.insertSchedule(schedule);
				}
			}
			
			// 3. 모집
			RecruitDAO recruitDAO = RecruitDAO.getInstance();
			RecruitRelationDAO recruitRelationDAO = RecruitRelationDAO.getInstance();
			MealDAO mealDAO = MealDAO.getInstance();
			// 모집 관련 전체 삭제
			for (Recruit recruit : pkg.getRecruits()) {
				recruitRelationDAO.deleteRecruitRelations(recruit.getYear(), recruit.getTerm(), recruit.getName());
				mealDAO.deleteMeals(recruit.getYear(), recruit.getTerm(), recruit.getName());
			}
			recruitDAO.deleteRecruits(recruitDate.getYear(), recruitDate.getTerm());
			
			if (pkg.getRecruits() != null) {
				for (Recruit recruit : pkg.getRecruits()) {
					if (recruit.getFee() == null) print("NULL");
					else print(recruit.getName() + " " + recruit.getFee());
				}
				// 모집 재생성
				for (Recruit recruit : pkg.getRecruits()) {
					recruitDAO.insertRecruit(recruit);

					// 4. 모집의 모집관계
					for (String subRecruit : recruit.getSubRecruit()) {
						recruitRelationDAO.insertRecruitRelation(recruit.getYear(), recruit.getTerm(),
								recruit.getName(), subRecruit);
					}

					// 5. 모집의 식사정보
					for (Meal meal : recruit.getMeal()) {
						mealDAO.insertMeal(meal);
					}
				}
			}
			
			mysql.commit();
			mysql.setAutoCommit(true);
			
			Protocol sndData = new Protocol(Protocol.TYPE_DATAPACKAGE_UPDATE_RES, 1);
			os.write(sndData.getPacket());
		}
		
		// ## 년도학기 조회 (전체)
		private void getRecruitDates(Protocol rcvData) throws IOException, SQLException, Exception {
			print(userID + " 클라이언트 : 년도학기 조회");

			RecruitDateDAO DAO = RecruitDateDAO.getInstance();

			Protocol sndData = new Protocol(Protocol.TYPE_RECRUITDATES_INFO_RES, 1);
			sndData.setBody(DAO.getRecruitDates());
			os.write(sndData.getPacket());
		}

		// ## 년도학기 선택 (단일)
		private void selectRecruitDate(Protocol rcvData) throws IOException, SQLException, Exception {
			print(userID + " 클라이언트 : 년도학기 선택");
			RecruitDate rcd = (RecruitDate) rcvData.getBody();
			
			this.rcd = rcd;
			Protocol sndData = new Protocol(Protocol.TYPE_RECRUITDATE_SELECT_RES, 1);
			os.write(sndData.getPacket());
		}

		// ## 일정 조회 (전체)
		private void getSchedules(Protocol rcvData) throws IOException, SQLException, Exception { // 일정확인
			print(userID + " 클라이언트 : 일정조회 요청");

			ScheduleDAO DAO = ScheduleDAO.getInstance();
			Schedule[] schedules = DAO.getSchedules(rcd.getYear(), rcd.getTerm());
			
			Protocol sndData = new Protocol(Protocol.TYPE_SCHEDULES_INFO_RES, 1);
			sndData.setBody(schedules);
			os.write(sndData.getPacket());
		}
		
		// ## 일정 조회 (단일)
		private void checkSchedule(Protocol rcvData) throws IOException, SQLException, Exception { // 일정확인
			print(userID + " 클라이언트 : 일정확인 요청");
			String name = (String) rcvData.getBody();
			
			ScheduleDAO DAO = ScheduleDAO.getInstance();
			Schedule schedule = DAO.getSchedule(rcd.getYear(), rcd.getTerm(), name);
			
			Protocol sndData = new Protocol(Protocol.TYPE_SCHEDULE_CHECK_RES);
			if (schedule == null) { // 비정상 일정
				sndData.setCode(0);
				os.write(sndData.getPacket());
				return;
			}

			if (schedule.getStartDate() == null) schedule.setStartDate(LocalDateTime.of(2000, 1, 1, 0, 0, 0));
			if (schedule.getStartDate() == null) schedule.setEndDate(LocalDateTime.of(2099, 12, 31, 23, 59, 59));
			
			LocalDateTime nowDate = LocalDateTime.now();
			if (nowDate.isAfter(schedule.getStartDate()) && nowDate.isBefore(schedule.getEndDate())) { // 시간 내
				sndData.setCode(1);
			} else { // 시간 외
				sndData.setCode(0);
			}
			os.write(sndData.getPacket());
		}
		
		// ## 일정 조회 (단일)
		private void checkSchedule2(Protocol rcvData) throws IOException, SQLException, Exception { // 일정확인
			print(userID + " 클라이언트 : 일정확인 요청");
			String name = (String) rcvData.getBody();
			
			ScheduleDAO DAO = ScheduleDAO.getInstance();
			Schedule schedule = DAO.getSchedule(rcd.getYear(), rcd.getTerm(), name);
			
			Protocol sndData = new Protocol(Protocol.TYPE_SCHEDULE_CHECK2_RES);
			if (schedule == null) { // 비정상 일정
				sndData.setCode(0);
				os.write(sndData.getPacket());
				return;
			}
			
			if (schedule.getStartDate() == null) schedule.setStartDate(LocalDateTime.of(2000, 1, 1, 0, 0, 0));
			if (schedule.getStartDate() == null) schedule.setEndDate(LocalDateTime.of(2099, 12, 31, 23, 59, 59));
			
			LocalDateTime nowDate = LocalDateTime.now();
			if (nowDate.isAfter(schedule.getStartDate()) && nowDate.isBefore(schedule.getEndDate())) { // 시간 내
				sndData.setCode(2);
			} else if (nowDate.isBefore(schedule.getStartDate())) { // 시작일보다 이전
				sndData.setCode(1);
			} else if (nowDate.isAfter(schedule.getEndDate())) { // 시작일보다 이후
				sndData.setCode(3);
			} else { // 둘다 아님 (오류)
				sndData.setCode(0);
			}
			os.write(sndData.getPacket());
		}


		// ## 모집 조회 (전체)
		private void getRecruits(Protocol rcvData) throws IOException, SQLException, Exception {
			print(userID + " 클라이언트 : 모집 조회 요청");
			
			// 모집 추가 시작!
			RecruitDAO DAO = RecruitDAO.getInstance();
			RecruitRelationDAO recruitRelationDAO = RecruitRelationDAO.getInstance();
			MealDAO mealDAO = MealDAO.getInstance();
			
			Recruit[] recruits = DAO.getRecruits(rcd.getYear(), rcd.getTerm());
			for (Recruit recruit : recruits) {
				recruit.setSubRecruit(recruitRelationDAO.getRecruitRelations(recruit.getYear(), recruit.getTerm(), recruit.getName()));
				recruit.setMeal(mealDAO.getMeals(recruit.getYear(), recruit.getTerm(), recruit.getName()));
			}

			Protocol sndData = new Protocol(Protocol.TYPE_RECRUITS_INFO_RES, 1);
			sndData.setBody(recruits);
			os.write(sndData.getPacket());
		}

		// ## 세부모집 조회 (전체, 세부정보 제외)
		private void getSubRecruits(Protocol rcvData) throws IOException, SQLException, Exception {
			print(userID + " 클라이언트 : 세무모집 정보 요청 (전체)");
			
			SubRecruitDAO DAO = SubRecruitDAO.getInstance();
			SubRecruit[] subRecruits = DAO.getSubRecruits();
			
			Protocol sndData = new Protocol(Protocol.TYPE_SUBRECRUITS_INFO_RES, 1);
			sndData.setBody(subRecruits);
			os.write(sndData.getPacket());
		}
		
		// ## 세부모집 조회 (단일, 세부정보 포함)
		private void getSubRecruit(Protocol rcvData) throws IOException, SQLException, Exception {
			print(userID + " 클라이언트 : 세무모집 정보 요청 (단일)");
			String name = (String) rcvData.getBody();

			SubRecruitDAO DAO = SubRecruitDAO.getInstance();
			BedDAO bedDAO = BedDAO.getInstance();
			
			SubRecruit subRecruit = DAO.getSubRecruit(name);
			Bed[] beds = bedDAO.getBeds(name);
			subRecruit.setBeds(beds);
			
			Protocol sndData = new Protocol(Protocol.TYPE_SUBRECRUIT_INFO_RES, 1);
			sndData.setBody(subRecruit);
			os.write(sndData.getPacket());
		}
		
		// ## 세부모집 등록 (단일)
		private void createSubRecruit(Protocol rcvData) throws IOException, SQLException, Exception {
			print(userID + " 클라이언트 : 세부모집 등록 요청");
			
			if (!isAdmin) {
				Protocol sndData = new Protocol(Protocol.TYPE_SUBRECRUIT_CREATE_RES, 0);
				os.write(sndData.getPacket());
				return;
			}
			
			SubRecruit sre = new SubRecruit();
			sre = (SubRecruit) rcvData.getBody();

			Mysql mysql = Mysql.getConnection();
			mysql.setAutoCommit(false);
			
			// 1. 세부모집 정보 확인
			SubRecruitDAO DAO = SubRecruitDAO.getInstance();
			SubRecruit subRecruit = DAO.getSubRecruit(sre.getName());
			if (subRecruit != null) { // 이미 존재하는 세부모집명이면 실패
				mysql.setAutoCommit(true);
				Protocol sndData = new Protocol(Protocol.TYPE_SUBRECRUIT_CREATE_RES, 0);
				os.write(sndData.getPacket());
				return;
			}
			
			// 2. 세부모집 삽입
			DAO.insertSubRecruit(sre);

			// 3. 입실단위 생성 시작
			BedDAO bedDAO = BedDAO.getInstance();
			Bed[] beds = sre.getBeds();
			for (Bed bed : beds) {
				bedDAO.insertBed(bed);
			}
			
			mysql.commit();
			mysql.setAutoCommit(true);

			Protocol sndData = new Protocol(Protocol.TYPE_SUBRECRUIT_CREATE_RES, 1);
			os.write(sndData.getPacket());
		}
		
		// ## 세부모집 갱신 (단일)
		private void updateSubRecruit(Protocol rcvData) throws IOException, SQLException, Exception {
			print(userID + " 클라이언트 : 세부모집 갱신 요청");
			SubRecruit sre = new SubRecruit();
			sre = (SubRecruit) rcvData.getBody();

			Mysql mysql = Mysql.getConnection();
			mysql.setAutoCommit(false);
			
			// 1. 세부모집 정보 확인
			SubRecruitDAO DAO = SubRecruitDAO.getInstance();
			SubRecruit subRecruit = DAO.getSubRecruit(sre.getName());
			if (subRecruit == null) { // 세부모집명이 존재하지 않으면 실패
				mysql.setAutoCommit(true);
				Protocol sndData = new Protocol(Protocol.TYPE_SUBRECRUIT_UPDATE_RES, 0);
				os.write(sndData.getPacket());
				return;
			}
			
			// 2. 세부모집 갱신 시작
			DAO.updateSubRecruit(sre);
			
			// 3. 세부모집 아래의 입실단위 정보 갱신
			// 입실단위 전체 삭제 후
			BedDAO bedDAO = BedDAO.getInstance();
			bedDAO.deleteBeds(sre.getName());

			// 입실단위 새로 삽입
			Bed[] beds = sre.getBeds();
			for (Bed bed : beds) {
				bedDAO.insertBed(bed);
			}
			
			mysql.commit();
			mysql.setAutoCommit(true);

			Protocol sndData = new Protocol(Protocol.TYPE_SUBRECRUIT_UPDATE_RES, 1);
			os.write(sndData.getPacket());
		}
		
		// # 신청정보 조회 (전체, 관리자)
		private void getApplies(Protocol rcvData) throws IOException, SQLException, Exception {
			print(userID + " 클라이언트 : 신청 리스트 조회 요청");
			
			if (!isAdmin) {
				Protocol sndData = new Protocol(Protocol.TYPE_APPLIES_INFO_RES, 0);
				os.write(sndData.getPacket());
				return;
			}
			
			ApplyDAO DAO = ApplyDAO.getInstance();
			
			Apply[] applies = DAO.getApplies(rcd.getYear(), rcd.getTerm());
			
			Protocol sndData = new Protocol(Protocol.TYPE_APPLIES_INFO_RES, 1);
			sndData.setBody(applies);
			os.write(sndData.getPacket());
		}

		// # 신청정보 조회 (단일, 학생)
		private void getApply(Protocol rcvData) throws IOException, SQLException, Exception {
			print(userID + " 클라이언트 : 신청 정보 조회 요청");
			ApplyDAO DAO = ApplyDAO.getInstance();
			
			Apply apply = DAO.getApply(rcd.getYear(), rcd.getTerm(), this.userID);
			
			Protocol sndData = new Protocol(Protocol.TYPE_APPLY_INFO_RES, 1);
			sndData.setBody(apply);
			os.write(sndData.getPacket());
		}
		
		// # 신청정보 생성 (단일)
	      private void createApply(Protocol rcvData) throws IOException, SQLException, Exception {
			print(userID + " 클라이언트 : 입사 신청 요청");
			Apply apply = (Apply) rcvData.getBody();

	         Mysql mysql = Mysql.getConnection();
	         mysql.setAutoCommit(false);
	         
	         // 1. 신청정보 확인
	         ApplyDAO DAO = ApplyDAO.getInstance();
	         Apply data = DAO.getApply(apply.getYear(), apply.getTerm(), apply.getId());
	         if (data != null) { // 이미 존재하면 기존에 존재하던 신청정보를 삭제한다.
	        	DAO.deleteApply(data);
	         }
	         
	         // 서약정보 데이터 검증
	         if (!apply.getPledge().getPrivacyAgree().equals("Y") && !apply.getPledge().getPrivacyAgree().equals("N")) {
	             Protocol sndData = new Protocol(Protocol.TYPE_APPLY_CREATE_RES,0);
	              os.write(sndData.getPacket());
	              return;
	         }
	         if (!apply.getPledge().getPledgeAgree().equals("Y") && !apply.getPledge().getPledgeAgree().equals("N")) {
	             Protocol sndData = new Protocol(Protocol.TYPE_APPLY_CREATE_RES,0);
	              os.write(sndData.getPacket());
	              return;
	         }
	         
	         // 2. 서약정보 생성
	         mysql.sql("INSERT INTO `서약정보` (`년도`, `학기`, `학번`, `개인정보동의여부`, `입사서약여부`) VALUES (?, ?, ?, ?, ?)");
	         mysql.set(1, apply.getYear());
	         mysql.set(2, apply.getTerm());
	         mysql.set(3, apply.getId());
	         mysql.set(4, apply.getPledge().getPrivacyAgree());
	         mysql.set(5, apply.getPledge().getPledgeAgree());
	         mysql.insert();
	         
	         // 3. 신청정보에 GPA와 Point 채우기
	         StudentDAO studentDAO = StudentDAO.getInstance();
	         float GPA = studentDAO.getGPA(apply.getYear(), apply.getTerm(), apply.getId());
	         apply.setGPA(Float.toString(GPA));
	         String RAP = studentDAO.getRAP(apply.getId());
	         apply.setPoint(RAP);
	         
	         // + apply 신청일시 서버기준
	         apply.setApplyDate(LocalDateTime.now());
	         
	         
	         // 4. 신청정보 생성
	         DAO.insertApply(apply);
	 
	         mysql.commit();
	         mysql.setAutoCommit(true);
	         
	         Protocol sndData = new Protocol(Protocol.TYPE_APPLY_CREATE_RES, 1);
	         os.write(sndData.getPacket());
	      }
		
		// # 신청정보 갱신 (단일)
		private void updateApply(Protocol rcvData) throws IOException, SQLException, Exception {
			Apply apply = (Apply) rcvData.getBody();
			
			Mysql mysql = Mysql.getConnection();
			mysql.setAutoCommit(false);
			
			// 1. 신청정보 확인
			ApplyDAO DAO = ApplyDAO.getInstance();
			Apply data = DAO.getApply(apply.getYear(), apply.getTerm(), apply.getId());
			if (data == null) { // 존재하지 않으면 실패
				mysql.setAutoCommit(true);
				Protocol sndData = new Protocol(Protocol.TYPE_APPLY_UPDATE_RES, 0);
				os.write(sndData.getPacket());
				return;
			}	
			// 2. 신청정보 갱신
			DAO.updateApply(apply);
			
			mysql.commit();
			mysql.setAutoCommit(true);
			
			Protocol sndData = new Protocol(Protocol.TYPE_APPLY_UPDATE_RES, 1);
			os.write(sndData.getPacket());
		}
		
		// # 선발정보 조회 (전체, 관리자)
		private void getSelections(Protocol rcvData) throws IOException, SQLException, Exception {
			print(userID + " 클라이언트 : 선발 리스트 조회 요청");
			
			if (!isAdmin) {
				Protocol sndData = new Protocol(Protocol.TYPE_SELECTIONS_INFO_RES, 0);
				os.write(sndData.getPacket());
				return;
			}
			
			SelectionDAO DAO = SelectionDAO.getInstance();
			
			Selection[] selections = DAO.getSelections(rcd.getYear(), rcd.getTerm());
			
			Protocol sndData = new Protocol(Protocol.TYPE_SELECTIONS_INFO_RES, 1);
			sndData.setBody(selections);
			os.write(sndData.getPacket());
		}

		// # 선발정보 조회 (단일, 학생)
		private void getSelection(Protocol rcvData) throws IOException, SQLException, Exception {
			print(userID + " 클라이언트 : 선발 정보 조회 요청");
			SelectionDAO DAO = SelectionDAO.getInstance();
			
			Selection selection = DAO.getSelection(rcd.getYear(), rcd.getTerm(), this.userID);
			
			Protocol sndData = new Protocol(Protocol.TYPE_SELECTION_INFO_RES, 1);
			sndData.setBody(selection);
			os.write(sndData.getPacket());
		}
		
		// # 선발유효 변경 (단일)
		private void validSelection(Protocol rcvData) throws IOException, SQLException, Exception 
        {
           print(userID + " 클라이언트 : 선발유효 갱신 요청");
           if (!isAdmin)
           {
              Protocol sndData = new Protocol(Protocol.TYPE_SELECTION_VALID_RES,0);
              os.write(sndData.getPacket());
              return;
           }
           
           String vl[] = (String[]) rcvData.getBody(); //받는 데이터는 스트링 배열, 바꾸고자 하는 학생의 학번과 선발유효 값.
           Mysql mysql = Mysql.getConnection();
           
           if (!vl[1].equals("Y") && !vl[1].equals("N")) { // 선발 유효의 값이 정상인지 검증
               Protocol sndData = new Protocol(Protocol.TYPE_SELECTION_VALID_RES,0);
               os.write(sndData.getPacket());
               return;
           }
           
           mysql.sql("UPDATE `선발` SET `선발유효` = ? WHERE `학번` = ?");
           mysql.set(1, vl[1]);
           mysql.set(2, vl[0]);
           mysql.update();
           
           Protocol sndData = new Protocol(Protocol.TYPE_SELECTION_VALID_RES,1);
           os.write(sndData.getPacket());
        }
		
		// # 선발 유효 변경 (선발자중 유효하지 않은 모든 인원의 선발유효를 N으로 변경)
		private void validSelection2(Protocol rcvData) throws IOException, SQLException, Exception {
			print(userID + " 클라이언트 : 선발유효 갱신2 요청");
			if (!isAdmin) {
				Protocol sndData = new Protocol(Protocol.TYPE_SELECTION_VALID2_RES, 0);
				os.write(sndData.getPacket());
				return;
			}
			
			Mysql mysql = Mysql.getConnection();
			mysql.sql("UPDATE 선발 SET `선발유효`='N' WHERE `년도`=? AND `학기`=? AND `납부일시` IS NULL OR (`제출확인` IS NULL OR `제출확인`='N')");
			mysql.set(1, rcd.getYear());
			mysql.set(2, rcd.getTerm());
			mysql.update();
			
			Protocol sndData = new Protocol(Protocol.TYPE_SELECTION_VALID2_RES, 1);
			os.write(sndData.getPacket());
		}
		
		private void getWaitNum(Protocol rcvData) throws IOException, SQLException, Exception {
			print(userID + " 클라이언트 : 해당 학생 대기 순번 요청");

			Mysql mysql = Mysql.getConnection();
			mysql.sql("SELECT `평점평균`,`지역가산점` FROM `신청`  WHERE `학번` = ? AND `년도` = ? AND `학기` = ?");
			mysql.set(1, userID);
			mysql.set(2, rcd.getYear());
			mysql.set(3, rcd.getTerm());
			ResultSet rs = mysql.select();
			
			float std_grade = 0;
			if (rs.next()) {
				std_grade = Float.parseFloat(rs.getString("평점평균")) + Float.parseFloat(rs.getString("지역가산점"));
				if (Float.isNaN(std_grade))
					std_grade = 0;
			}
			
			int waitnumber;
			mysql.sql("SELECT COUNT(*) AS 인원 FROM `신청` LEFT OUTER JOIN 선발 ON 신청.년도 = 선발.년도 AND 신청.학기 = 선발.학기 AND 신청.학번 = 선발.학번 WHERE (신청.`평점평균` + 신청.`지역가산점`) > ? AND 신청.`년도` = ? AND 신청.`학기` = ? AND 선발.신청구분 IS NULL");
			mysql.set(1, Float.toString(std_grade));
			mysql.set(2, rcd.getYear());
			mysql.set(3, rcd.getTerm());
			rs = mysql.select();

			if (rs.next()) {
				waitnumber = rs.getInt("인원");
			}
			else {
				waitnumber = 0;
			}
			
			Protocol sndData = new Protocol(Protocol.TYPE_SELECTION_WAITNUM_RES, 1);
			sndData.setBody(Integer.toString(waitnumber));
			os.write(sndData.getPacket());
		}
		
		// ## 납부 승인 (고지서)
		private void acceptInvoice(Protocol rcvData) throws IOException, SQLException, Exception 
        {
           print(userID + " 클라이언트 : 납부 승인 요청");
           if (!isAdmin)
           {
              Protocol sndData = new Protocol(Protocol.TYPE_ACCEPT_INVOICE_RES,0);
              os.write(sndData.getPacket());
              return;
           }
           
           String vl[] = (String[]) rcvData.getBody(); //받는 데이터는 스트링 배열, 바꾸고자 하는 학생의 학번과 날짜값 값.
           Mysql mysql = Mysql.getConnection();
           
           
           mysql.sql("UPDATE `선발` SET `납부일시` = ? WHERE `학번` = ?");

           mysql.set(1, vl[1]);
           mysql.set(2, vl[0]);
           mysql.update();
           
           Protocol sndData = new Protocol(Protocol.TYPE_ACCEPT_INVOICE_RES,1);
           os.write(sndData.getPacket());
        }
		
		// ## 파일 승인 (결핵진단서)
		private void acceptFile(Protocol rcvData) throws IOException, SQLException, Exception {
			print(userID + " 클라이언트 : 결핵진단서 승인 요청");

			if (!isAdmin) {
				Protocol sndData = new Protocol(Protocol.TYPE_ACCEPT_FILE_RES, 0);
				os.write(sndData.getPacket());
				return;
			}
			
			String IDs[] = (String[]) rcvData.getBody();
			Mysql mysql = Mysql.getConnection();
			
			mysql.setAutoCommit(false);
			for (String id : IDs) {
				SelectionDAO selectionDAO = SelectionDAO.getInstance();
				if (selectionDAO.getSelection(rcd.getYear(), rcd.getTerm(), id) == null) { // 존재하면 안되는 값이 존재하면
					mysql.rollback();
					Protocol sndData = new Protocol(Protocol.TYPE_ACCEPT_FILE_RES, 0);
					os.write(sndData.getPacket());
					return;
				}
				
				mysql.sql("UPDATE `선발` SET `제출확인` = 'Y' WHERE `학번` = ?");
				mysql.set(1, id);
				mysql.update();
			}
			
			mysql.commit();
			mysql.setAutoCommit(true);
			
			Protocol sndData = new Protocol(Protocol.TYPE_ACCEPT_FILE_RES, 1);
			os.write(sndData.getPacket());
		}
		
		// ## 파일 업로드 (결핵진단서)
		private void uploadFile(Protocol rcvData) throws IOException, SQLException, Exception {
			print(userID + " 클라이언트 : 파일 업로드 요청");
			byte[] image = (byte[]) rcvData.getBody();
			
			SelectionDAO DAO = SelectionDAO.getInstance();
			Selection selection = DAO.getSelection(rcd.getYear(), rcd.getTerm(), userID);
			
			if (selection == null) {
				Protocol sndData = new Protocol(Protocol.TYPE_FILE_UPLOAD_RES, 0);
				os.write(sndData.getPacket());
				return;
			}
			
			Mysql mysql = Mysql.getConnection();
			LocalDateTime now = LocalDateTime.now();
			mysql.sql("UPDATE `선발` SET `제출일시`=?, `제출파일`=?, `제출확인`='N' WHERE `년도`=? AND `학기`=? AND `학번` = ?");
			mysql.set(1, now.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
			mysql.set(2, userID + now.format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss")) + ".jpg");
			mysql.set(3, rcd.getYear());
			mysql.set(4, rcd.getTerm());
			mysql.set(5, userID);
			mysql.update();
						
	        File lOutFile = new File("/mnt/VOL1/java/dms_server/images/" + userID + now.format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss")) + ".jpg");
	        lOutFile.createNewFile();
	        FileOutputStream lFileOutputStream = new FileOutputStream(lOutFile);
	        lFileOutputStream.write(image);
	        lFileOutputStream.close();
			
			Protocol sndData = new Protocol(Protocol.TYPE_FILE_UPLOAD_RES, 1);
			os.write(sndData.getPacket());
		}
		
		// ## 파일 다운로드 (결핵진단서)
		private void downloadFile(Protocol rcvData) throws IOException, SQLException, Exception {
			print(userID + " 클라이언트 : 파일 다운로드 요청");
			String id = (String) rcvData.getBody();
			
			SelectionDAO DAO = SelectionDAO.getInstance();
			Selection selection = DAO.getSelection(rcd.getYear(), rcd.getTerm(), id);
			
			if (selection == null || selection.getUploadUrl() == null) {
				Protocol sndData = new Protocol(Protocol.TYPE_FILE_DOWNLOAD_RES, 0);
				os.write(sndData.getPacket());
				return;
			}
			
			File file = new File("/mnt/VOL1/java/dms_server/images/" +  selection.getUploadUrl());
			byte[] bytesArray = new byte[(int) file.length()];
			FileInputStream fis = new FileInputStream(file);
			fis.read(bytesArray);
			fis.close();
			
			Protocol sndData = new Protocol(Protocol.TYPE_FILE_DOWNLOAD_RES, 1);
			sndData.setBody(bytesArray);
			os.write(sndData.getPacket());
		}
		
		// ## 선발 요청
		private void enrollSelection(Protocol rcvData) throws IOException, SQLException, Exception {
			print(userID + " 클라이언트 : 선발 요청");
			
			if (!isAdmin) {
				Protocol sndData = new Protocol(Protocol.TYPE_SELECTION_ENROLL_RES, 0);
				os.write(sndData.getPacket());
				return;
			}
			
			String div = (String)rcvData.getBody();
			
			// 1-1. 모집 정보 로드
			HashMap<String, Recruit> recruitList = new HashMap<String, Recruit>();
			RecruitDAO DAO = RecruitDAO.getInstance();
			RecruitRelationDAO recruitRelationDAO = RecruitRelationDAO.getInstance();
			MealDAO mealDAO = MealDAO.getInstance();
			
			Recruit[] recruits = DAO.getRecruits(rcd.getYear(), rcd.getTerm());
			for (Recruit recruit : recruits) {
				recruit.setSubRecruit(recruitRelationDAO.getRecruitRelations(recruit.getYear(), recruit.getTerm(), recruit.getName()));
				recruit.setMeal(mealDAO.getMeals(recruit.getYear(), recruit.getTerm(), recruit.getName()));
				recruitList.put(recruit.getName(), recruit);
			}
			
			// 1-2. 기선발자 목록 조회 (기선발자 추가안하기 위해 사용)
			HashMap<String, Selection> selectionList = new HashMap<String, Selection>();
			SelectionDAO selectionDAO = SelectionDAO.getInstance();
			Selection[] selections = selectionDAO.getSelections(rcd.getYear(), rcd.getTerm());
			for (Selection selection : selections) {
				selectionList.put(selection.getId(), selection);
			}
			
			// 2-1. 세부모집의 모집가능 인원을 파악
			HashMap<String, Integer> subRecruitList = new HashMap<String, Integer>();
			Mysql mysql = Mysql.getConnection();
			mysql.sql("SELECT 세부모집명, COUNT(*) AS 인원 FROM `입실단위` WHERE `가용여부`='Y' GROUP BY `세부모집명`");
			ResultSet rs = mysql.select();
			
			while (rs.next()) { // 세부모집 존재
				subRecruitList.put(rs.getString("세부모집명"), rs.getInt("인원"));
			}
			
			// 2-2. 해당년도학기에 이미 선발된 인원의 세부모집 인원을 파악하여 2-1의 값에서 빼줌
			mysql.sql("SELECT 세부모집명, COUNT(*) AS 인원 FROM `선발` WHERE `년도` =? AND `학기` =? AND `선발유효` ='Y' GROUP BY 세부모집명");
			mysql.set(1, rcd.getYear());
			mysql.set(2, rcd.getTerm());
			rs = mysql.select();
			
			while (rs.next()) { // 세부모집 존재
				subRecruitList.put(rs.getString("세부모집명"), subRecruitList.get(rs.getString("세부모집명")) - rs.getInt("인원"));
			}		
			
			// 3. 해당 년도학기의 신청자를 성적순으로 정렬한 목록을 가져온다. (취소자는 가져오지 않음)
			ApplyDAO applyDAO = ApplyDAO.getInstance();
			Apply[] applies = applyDAO.getAppliesSet(rcd.getYear(), rcd.getTerm());
			// 4. 높은 성적부터 낮은 순으로 각 신청자 지망정보를 확인하여 세부모집을 선정
			String subRecruitName;
			String mealName;
			Recruit r;
			for (Apply apply : applies) {
				subRecruitName = "";
				mealName = "";
				// 1년 기숙을 신청했다면
				if (apply.getYearSubId() != null) {
					r = recruitList.get(apply.getYearSubId());
					// 세부모집을 탐색하여
					for (String str : r.getSubRecruit()) {
						int count = subRecruitList.get(str);
						// 여석이 있으면 선정
						if (count > 0) {
							subRecruitList.put(str, count - 1);
							subRecruitName = str;
							mealName = apply.getYearMeal();
							break;
						}
					}
				}
				
				// 1년기숙에서 선정 되지 않았고, 학기 기숙을 신청했다면
				if (subRecruitName.equals("") && apply.getFirstSubId() != null) {
					r = recruitList.get(apply.getFirstSubId());
					// 1지망의 세부모집을 탐색
					for (String str : r.getSubRecruit()) {
						int count = subRecruitList.get(str);
						// 여석이 있으면 선정
						if (count > 0) {
							subRecruitList.put(str, count - 1);
							subRecruitName = str;
							mealName = apply.getFirstMeal();
							break;
						}
					}
				}
				
				// 1지망에서 선정 되지 않았고, 2지망 기록이 있다면
				if (subRecruitName.equals("") && apply.getSecondSubId() != null) {
					r = recruitList.get(apply.getSecondSubId());
					// 2지망의 세부모집을 탐색
					for (String str : r.getSubRecruit()) {
						int count = subRecruitList.get(str);
						// 여석이 있으면 선정
						if (count > 0) {
							subRecruitList.put(str, count - 1);
							subRecruitName = str;
							mealName = apply.getSecondMeal();
							break;
						}
					}
				}
			
				// 2지망에서 선정 되지 않았고, 3지망 기록이 있다면
				if (subRecruitName.equals("") && apply.getThirdSubId() != null) {
					r = recruitList.get(apply.getThirdSubId());
					// 3지망의 세부모집을 탐색
					for (String str : r.getSubRecruit()) {
						int count = subRecruitList.get(str);
						// 여석이 있으면 선정
						if (count > 0) {
							subRecruitList.put(str, count - 1);
							subRecruitName = str;
							mealName = apply.getThirdMeal();
							break;
						}
					}
				}
				// 이때 세부모집에 선정됬다면 선발에 신규 등록 (없다면 넘어간당)
				if (!subRecruitName.equals("")) {
					// 단, 선발에 이미 기록이 없는 사람만 추가하고
					if (!selectionList.containsKey(apply.getId())) {
						Selection selection = new Selection();
						selection.setYear(apply.getYear());
						selection.setTerm(apply.getTerm());
						selection.setId(apply.getId());
						selection.setDiv(div);
						selection.setSubRecruit(subRecruitName);
						selection.setMeal(mealName);
						selection.setValided("Y");
						selectionDAO.insertSelection(selection);
					}
					// 아닌 사람은 다시 인원 계산을 되돌려놓자.
					else {
						subRecruitList.put(subRecruitName, subRecruitList.get(subRecruitName) + 1);
					}
				}
			}
			
			Protocol sndData = new Protocol(Protocol.TYPE_SELECTION_ENROLL_RES, 1);
			os.write(sndData.getPacket());
		}
		
		// ## 호실 배정 요청
        private void enrollBed(Protocol rcvData) throws IOException, SQLException, Exception {
              print(userID + " 클라이언트 : 호실 배정 요청");
              
           if (!isAdmin) {
            Protocol sndData = new Protocol(Protocol.TYPE_BED_ENROLL_RES, 0);
            os.write(sndData.getPacket());
            return;
         }
              
              String rname = (String)rcvData.getBody(); //받은 데이터의 바디에 모집명이 기술되어있다.
              Mysql mysql = Mysql.getConnection();
              
			// 1-1. 모집 정보 로드
			HashMap<String, Recruit> recruitList = new HashMap<String, Recruit>();
			RecruitDAO DAO = RecruitDAO.getInstance();
			RecruitRelationDAO recruitRelationDAO = RecruitRelationDAO.getInstance();

			Recruit[] recruits = DAO.getRecruits(rcd.getYear(), rcd.getTerm());
			for (Recruit recruit : recruits) {
				recruit.setSubRecruit(recruitRelationDAO.getRecruitRelations(recruit.getYear(), recruit.getTerm(),
						recruit.getName()));
				recruitList.put(recruit.getName(), recruit);
			}
                      
			// 1-2. 세부모집-모집 관계 MAP 생성
              mysql.sql("SELECT `세부모집명`, `모집명` FROM `모집관계` WHERE `모집명` = ?");
              mysql.set(1, rname);
              ResultSet rs = mysql.select();
              
              Vector<String> v = new Vector<String>();
              HashMap<String, String> relation = new HashMap<String, String>();
              while(rs.next())
              {
                 v.add(rs.getString("세부모집명"));
                 relation.put(rs.getString("세부모집명"), rs.getString("모집명"));
              }
              
              String sname[] = v.toArray(new String[0]);   //세부모집명 불러옴.
              for (int j = 0; j <sname.length; j++)
              {
                 mysql.sql("SELECT `호실번호`, `침대코드` FROM `입실단위` WHERE `세부모집명` = ? AND `가용여부` = ?");
                 mysql.set(1,sname[j]);
                 mysql.set(2, "Y");
                 rs = mysql.select();
                 Vector<Bed> b = new Vector<Bed>();
                 while(rs.next())
                 {
                    Bed bd = new Bed();
                    bd.setRoomNum(rs.getInt("호실번호"));
                    bd.setBedNum(rs.getString("침대코드"));
                    b.add(bd);
                 }
                 
                 Vector<Selection> s = new Vector<Selection>();
                 mysql.sql("SELECT `학번` FROM `선발` WHERE `년도` = ? AND `학기` = ? AND `세부모집명` = ? AND `납부일시` IS NOT NULL AND `제출확인` = ? AND `선발유효` = ?");
                 mysql.set(1, rcd.getYear());
                 mysql.set(2, rcd.getTerm());
                 mysql.set(3, sname[j]);
                 mysql.set(4, "Y");
                 mysql.set(5, "Y");
                 rs = mysql.select();
                 
                 while(rs.next())
                 {
                    Selection sl = new Selection();
                    sl.setId(rs.getString("학번"));
                    s.add(sl);
                 }
                 
                 Bed[] bedlist = b.toArray(new Bed[b.size()]);
                 Selection[] selectlist = s.toArray(new Selection[s.size()]);
                 for (int i = 0; (i <bedlist.length)&&(i < selectlist.length); i++)
                 {
                    mysql.sql("UPDATE `입실단위` SET `가용여부` = ? WHERE `호실번호` = ? AND `침대코드` = ? AND `세부모집명` = ?");
                    if (recruitList.get(relation.get(sname[j])).getRecruitYear().equals("Y")) mysql.set(1, "C");
                    else mysql.set(1, "T");
                    mysql.set(2,bedlist[i].getRoomNum().toString());
                    mysql.set(3,bedlist[i].getBedNum());
                    mysql.set(4, sname[j]);
                    mysql.update();
                    mysql.sql("UPDATE `선발` SET `호실번호` = ? , `침대번호` = ? WHERE `학번`= ?");
                    mysql.set(1,bedlist[i].getRoomNum().toString());
                    mysql.set(2,bedlist[i].getBedNum());
                    mysql.set(3,selectlist[i].getId());
                    mysql.update();
                 }
              }
              Protocol sndData = new Protocol(Protocol.TYPE_BED_ENROLL_RES, 1);
              os.write(sndData.getPacket());
        }
        
        // ## 입실단위 가용여부(T OR C → Y)변경 요청
		private void freeBeds(Protocol rcvData) throws IOException, SQLException, Exception {
			print(userID + " 클라이언트 : 가용여부변경 요청");

			String[] data = (String[]) rcvData.getBody(); // data[0] 세부모집명, data[1] 변경대상
			Mysql mysql = Mysql.getConnection();
			
			if (data[1].equals("1년")) data[1] = "C";
			else if (data[1].equals("학기")) data[1] = "T";
			else data[1] = "";
			
			mysql.sql("UPDATE `입실단위` SET `가용여부`='Y' WHERE `세부모집명`=? AND `가용여부` =?");
			mysql.set(1, data[0]);
			mysql.set(2, data[1]);
			mysql.update();
			
			Protocol sndData = new Protocol(Protocol.TYPE_BED_FREE_RES, 1);
			os.write(sndData.getPacket());
		}
		

		// ## (테스트용) 학생들 자동 신청 메소드
		private void testApplies() throws IOException, SQLException, Exception {
			print(userID + " 클라이언트 : (테스트) 학생 자동신청");
			
			// 1. 해당 년도학기의 모집정보 가져옴
			Vector<Recruit> recruitYearList = new Vector<Recruit>();
			Vector<Recruit> recruitTermList = new Vector<Recruit>();
			RecruitDAO DAO = RecruitDAO.getInstance();
			RecruitRelationDAO recruitRelationDAO = RecruitRelationDAO.getInstance();
			MealDAO mealDAO = MealDAO.getInstance();
			
			Recruit[] recruits = DAO.getRecruits(rcd.getYear(), rcd.getTerm());
			for (Recruit recruit : recruits) {
				recruit.setSubRecruit(recruitRelationDAO.getRecruitRelations(recruit.getYear(), recruit.getTerm(), recruit.getName()));
				recruit.setMeal(mealDAO.getMeals(recruit.getYear(), recruit.getTerm(), recruit.getName()));
				if (recruit.getRecruitYear().equals("Y")) recruitYearList.add(recruit); // 1년모집이면 1년모집에 추가
				else if (recruit.getRecruitYear().equals("N")) recruitTermList.add(recruit); // 학기모집이면 학기모집에 추가
			}
			Recruit[] recruitYear = recruitYearList.toArray(new Recruit[0]);
			Recruit[] recruitTerm = recruitTermList.toArray(new Recruit[0]);
			
			StudentDAO studentDAO = StudentDAO.getInstance();
			
			// 2. 학생 2000명을 뽑아서 돌린다
			Mysql mysql = Mysql.getConnection();
			mysql.sql("SELECT * FROM `학생` WHERE `학번` >= '20120000' ORDER BY `보호자전화번호` ASC LIMIT 2000");
			ResultSet rs = mysql.select();
			
			boolean yearFlg;
			Apply apply;
			while (rs.next()) {
				apply = new Apply();
				apply.setYear(rcd.getYear());
				apply.setTerm(rcd.getTerm());
				apply.setId(rs.getString("학번"));
				// 신청정보에 GPA와 Point 채우기
				float GPA = studentDAO.getGPA(apply.getYear(), apply.getTerm(), apply.getId());
				if (Float.isNaN(GPA)) apply.setGPA("0");
				else apply.setGPA(Float.toString(GPA));
				apply.setGPA(Float.toString(GPA));
				String RAP = studentDAO.getRAP(apply.getId());
				print(apply.getId() + "'s Point: " + RAP);
				apply.setPoint(RAP);
				apply.setApplyDate(LocalDateTime.now());
				
				yearFlg = false;
				// 3. (10% 확률로) 1년에서 하나를 골라 선택
				if (Math.random() < 0.1) {
					yearFlg = true;
					int recruitIdx;
					int mealIdx;
					do {
					recruitIdx = Math.min(recruitYear.length - 1, (int)((double)Math.random() * recruitYear.length));
					mealIdx = Math.min(recruitYear[recruitIdx].getMeal().length - 1, (int)((double)Math.random() * recruitYear[recruitIdx].getMeal().length));
					apply.setYearSubId(recruitYear[recruitIdx].getName());
					apply.setYearMeal(recruitYear[recruitIdx].getMeal()[mealIdx].getMealType());
					} while (!recruitYear[recruitIdx].getRecruitSex().equals(rs.getString("성별"))); // 학생 성별과 모집 성별이 같아질때까지 돌림
				}
				
				if (yearFlg == false || Math.random() < 0.5) {
					// 4. (1년을 신청 안했거나, 신청했을때 50% 확률로) 학기 선택
					// 1지망
					int firstIdx, secondIdx, thirdIdx;
					int firstMeal, secondMeal, thirdMeal;
					do {
					firstIdx =  Math.min(recruitTerm.length - 1, (int)((double)Math.random() * recruitTerm.length));
					firstMeal = Math.min(recruitTerm[firstIdx].getMeal().length - 1, (int)((double)Math.random() * recruitTerm[firstIdx].getMeal().length));
					apply.setFirstSubId(recruitTerm[firstIdx].getName());
					apply.setFirstMeal(recruitTerm[firstIdx].getMeal()[firstMeal].getMealType());
					} while (!recruitTerm[firstIdx].getRecruitSex().equals(rs.getString("성별"))); // 학생 성별과 모집 성별이 같아질때까지 돌림
					// 2지망
					do {
					secondIdx = Math.min(recruitTerm.length - 1, (int)((double)Math.random() * recruitTerm.length));
					secondMeal = Math.min(recruitTerm[secondIdx].getMeal().length - 1, (int)((double)Math.random() * recruitTerm[secondIdx].getMeal().length));
					apply.setSecondSubId(recruitTerm[secondIdx].getName());
					apply.setSecondMeal(recruitTerm[secondIdx].getMeal()[secondMeal].getMealType());
					} while (!recruitTerm[secondIdx].getRecruitSex().equals(rs.getString("성별"))); // 학생 성별과 모집 성별이 같아질때까지 돌림
					// 3지망
					do {
					thirdIdx = Math.min(recruitTerm.length - 1, (int)((double)Math.random() * recruitTerm.length));
					thirdMeal = Math.min(recruitTerm[thirdIdx].getMeal().length - 1, (int)((double)Math.random() * recruitTerm[thirdIdx].getMeal().length));
					apply.setThirdSubId(recruitTerm[thirdIdx].getName());
					apply.setThirdMeal(recruitTerm[thirdIdx].getMeal()[thirdMeal].getMealType());
					} while (!recruitTerm[thirdIdx].getRecruitSex().equals(rs.getString("성별"))); // 학생 성별과 모집 성별이 같아질때까지 돌림
				}
				
		         // 서약정보 생성
		         mysql.sql("INSERT INTO `서약정보` (`년도`, `학기`, `학번`, `개인정보동의여부`, `입사서약여부`) VALUES (?, ?, ?, ?, ?)");
		         mysql.set(1, apply.getYear());
		         mysql.set(2, apply.getTerm());
		         mysql.set(3, apply.getId());
		         mysql.set(4, "Y");
		         mysql.set(5, "Y");
		         mysql.insert();
		         
				// 데이터 삽입
				ApplyDAO applyDAO = ApplyDAO.getInstance();
				applyDAO.insertApply(apply);
			} // 학생 반복문 종료
		}
	}
}