package kumoh.DMSserver;

import java.io.File;

public class App {
	public static void main(String[] args) {
		System.out.println("[DMS Server]");
		Server.start();
	}
}
