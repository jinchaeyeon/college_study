package kumoh.DMSserver.DAO;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import kumoh.DMSserver.Mysql;
import kumoh.core.model.Student;
import kumoh.core.model.StudentGrade;

public class StudentDAO {
	public static final String SQL_SELECT = "SELECT * FROM `입실단위`";

	private StudentDAO() {
	}

	private static class LazyHolder {
		public static final StudentDAO INSTANCE = new StudentDAO();
	}

	public static StudentDAO getInstance() {
		return LazyHolder.INSTANCE;
	}

	// ## ResultSet 결과를 객체에 담기
	public Student match(ResultSet rs) throws IOException, SQLException, Exception {
		Student std = new Student();
		std.setUnivType(rs.getString("대학구분"));
		std.setId(rs.getString("학번"));
		std.setPwd(rs.getString("패스워드"));
		std.setName(rs.getString("성명"));
		std.setSex(rs.getString("성별"));
		std.setDepCode(rs.getString("주민등록번호"));
		std.setDepName(rs.getString("학과코드"));
		std.setGrade(rs.getString("학과명"));
		std.setMajor(rs.getString("학년"));
		std.setClassType(rs.getString("전공구분"));
		std.setStdZip(rs.getString("주야구분"));
		std.setStdAddress(rs.getString("학생우편번호"));
		std.setStdPhone(rs.getString("학생주소"));
		std.setPrtName(rs.getString("학생전화번호"));
		std.setPrtZip(rs.getString("보호자성명"));
		std.setPrtAddress(rs.getString("보호자우편번호"));
		std.setPrtPhone(rs.getString("보호자주소"));
		std.setPrtRelation(rs.getString("보호자와의관계"));

		return std;
	}

	// ## 학생 조회 (단일)
	public Student getStudent(String id) throws IOException, SQLException, Exception {
		Mysql mysql = Mysql.getConnection();
		mysql.sql("SELECT * FROM `학생` WHERE `학번` = ?");
		mysql.set(1, id);
		ResultSet rs = mysql.select();

		if (rs.next()) { // 학생
			return match(rs);
		}
		return null;
	}
	
	// ## 학생의 GPA 조회
	public float getGPA(String year, String term, String id) throws IOException, SQLException, Exception {
	      Mysql mysql = Mysql.getConnection();
	      mysql.sql("SELECT * FROM 성적  WHERE 학번 =?  ORDER BY 개설년도 DESC, 개설학기 DESC");
	      mysql.set(1, id);
	      ResultSet rs = mysql.select();

	      String recentyear = ""; // 최근 년도
	      String recentterm = ""; // 최근 학기
	      int totalgrade = 0; // 총학점
	      double totalpoint = 0; // 총점수

	      while (rs.next()) {
	         StudentGrade stg = new StudentGrade();
	         stg.setId(rs.getString("학번"));
	         stg.setYear(rs.getString("개설년도"));
	         stg.setTerm(rs.getString("개설학기"));
	         stg.setName(rs.getString("교과목명"));
	         stg.setGrade(rs.getInt("학점"));
	         stg.setPoint(rs.getString("등급"));
	         
	         if((!recentyear.equals("")&&!recentyear.equals(stg.getYear()))||(!recentterm.equals("")&&!recentterm.equals(stg.getTerm()))) break; // 년도가 다르거나 학기가 다르면 직전학기가 아님
	         
	            
	         recentyear = stg.getYear();
	         recentterm = stg.getTerm();

	         totalgrade += stg.getGrade();

	         if (stg.getPoint().equals("A+"))
	            totalpoint += stg.getGrade() * 4.5;
	         else if (stg.getPoint().equals("A"))
	            totalpoint += stg.getGrade() * 4.0;
	         else if (stg.getPoint().equals("B+"))
	            totalpoint += stg.getGrade() * 3.5;
	         else if (stg.getPoint().equals("B"))
	            totalpoint += stg.getGrade() * 3.0;
	         else if (stg.getPoint().equals("C+"))
	            totalpoint += stg.getGrade() * 2.5;
	         else if (stg.getPoint().equals("C"))
	            totalpoint += stg.getGrade() * 2.0;
	         else if (stg.getPoint().equals("D+"))
	            totalpoint += stg.getGrade() * 1.5;
	         else if (stg.getPoint().equals("D"))
	            totalpoint += stg.getGrade() * 1.0;
	         else if (stg.getPoint().equals("F"))
	            totalpoint += stg.getGrade() * 0.0;
	      }
	      float GPA =  ((float)totalpoint / (float)totalgrade);
	      if (Float.isNaN(GPA)) GPA = 0;
	      return GPA;
	   }
	
    public String getRAP(String id) throws IOException, SQLException, Exception {
        Mysql mysql = Mysql.getConnection();
        mysql.sql("SELECT `학번`, `성명`, `보호자주소`, `가산점`\r\n" + 
              "FROM 학생\r\n" + 
              "LEFT JOIN 지역가산점\r\n" + 
              "ON IF(`보호자주소` LIKE '%울릉군%', '울릉군', IF(`보호자주소` LIKE '경상북도 구미시 %' && `보호자주소` NOT LIKE '경상북도 구미시 __읍%' && `보호자주소` NOT LIKE '경상북도 구미시 __면%', '구미시 동지역', SUBSTRING_INDEX(`보호자주소`, ' ', 1))) = 지역가산점.지역명\r\n"+
              "WHERE 학번 =?");
        mysql.set(1, id);
        ResultSet rs = mysql.select();
        String RAP="";
  

        if (rs.next()) {
           RAP = rs.getString("가산점");
        }
        
        if (RAP == null) RAP = "0";
        return RAP;
     }
}