package kumoh.DMSserver.DAO;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;
import kumoh.DMSserver.Mysql;
import kumoh.core.model.RecruitDate;

public class RecruitDateDAO {
	public static final String SQL_SELECT = "SELECT *  FROM `년도학기`";

	private RecruitDateDAO() {
	}

	private static class LazyHolder {
		public static final RecruitDateDAO INSTANCE = new RecruitDateDAO();
	}

	public static RecruitDateDAO getInstance() {
		return LazyHolder.INSTANCE;
	}

	// ## ResultSet 결과를 객체에 담기
	public RecruitDate match(ResultSet rs) throws IOException, SQLException, Exception {
		RecruitDate rcd = new RecruitDate();

		rcd.setYear(rs.getString("년도"));
		rcd.setTerm(rs.getString("학기"));
		rcd.setNotice(rs.getString("공지사항"));
		rcd.setInvoice(rs.getString("고지서정보"));
		rcd.setPledge(rs.getString("서약정보"));
		return rcd;
	}

	// ## 년도학기 조회 (전체)
	public RecruitDate[] getRecruitDates() throws IOException, SQLException, Exception {
		Mysql mysql = Mysql.getConnection();
		mysql.sql(SQL_SELECT);
		ResultSet rs = mysql.select();

		Vector<RecruitDate> v = new Vector<RecruitDate>();
		while (rs.next()) { // 년도학기 존재
			v.add(match(rs));
		}
		return v.toArray(new RecruitDate[0]);
	}

	// ## 년도학기 조회 (단일)
	public RecruitDate getRecruitDate(String year, String term) throws IOException, SQLException, Exception {
		Mysql mysql = Mysql.getConnection();
		mysql.sql(SQL_SELECT + "WHERE `년도` = ? AND `학기` = ?");
		mysql.set(1, year);
		mysql.set(2, term);
		ResultSet rs = mysql.select();

		if (rs.next()) { // 년도학기 존재
			return match(rs);
		}
		return null;
	}
	
	// ## 년도학기 등록 (단일)
	public void insertRecruitDate(RecruitDate recruitDate) throws IOException, SQLException, Exception {
		if (recruitDate == null) return;
		Mysql mysql = Mysql.getConnection();
		mysql.sql("INSERT INTO 년도학기 (`년도`, `학기`, `공지사항`, `서약정보`, `고지서정보`) VALUES (?, ?, ?, ?, ?)");
		mysql.set(1, recruitDate.getYear());
		mysql.set(2, recruitDate.getTerm());
		mysql.set(3, recruitDate.getNotice());
		mysql.set(4, recruitDate.getPledge());
		mysql.set(5, recruitDate.getInvoice());
		mysql.insert();
	}
	
	// ## 년도학기 갱신 (단일)
	public void updateRecruitDate(RecruitDate recruitDate) throws IOException, SQLException, Exception {
		Mysql mysql = Mysql.getConnection();
		mysql.sql("UPDATE 년도학기 SET `공지사항`=?, `서약정보`=?, `고지서정보`=? WHERE `년도`=? AND `학기`=?");
		mysql.set(1, recruitDate.getNotice());
		mysql.set(2, recruitDate.getPledge());
		mysql.set(3, recruitDate.getInvoice());
		mysql.set(4, recruitDate.getYear());
		mysql.set(5, recruitDate.getTerm());
		mysql.update();
	}
	
}