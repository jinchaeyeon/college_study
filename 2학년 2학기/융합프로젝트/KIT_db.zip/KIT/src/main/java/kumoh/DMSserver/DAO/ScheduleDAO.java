package kumoh.DMSserver.DAO;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Vector;
import kumoh.DMSserver.Mysql;
import kumoh.core.model.Schedule;

public class ScheduleDAO {
	public static final String SQL_SELECT = "SELECT 년도, 학기, 일정명, CAST(시작시간 AS CHAR) AS 시작시간, CAST(종료시간 AS CHAR) AS 종료시간 FROM `일정`";

	private ScheduleDAO() {
	}

	private static class LazyHolder {
		public static final ScheduleDAO INSTANCE = new ScheduleDAO();
	}

	public static ScheduleDAO getInstance() {
		return LazyHolder.INSTANCE;
	}
	
	// ## ResultSet 결과를 객체에 담기
	public Schedule match(ResultSet rs) throws IOException, SQLException, Exception {
		Schedule schedule = new Schedule();
		schedule.setYear(rs.getString("년도"));
		schedule.setTerm(rs.getString("학기"));
		schedule.setName(rs.getString("일정명"));
		if (rs.getString("시작시간") != null && !rs.getString("시작시간").equals("0000-00-00 00:00:00"))
			schedule.setStartDate(
				LocalDateTime.parse(rs.getString("시작시간"), DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
		if (rs.getString("종료시간") != null && !rs.getString("종료시간").equals("0000-00-00 00:00:00"))
			schedule.setEndDate(
				LocalDateTime.parse(rs.getString("종료시간"), DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
		return schedule;
	}

	// ## 일정 조회 (전체)
	public Schedule[] getSchedules(String year, String term) throws IOException, SQLException, Exception {
		Mysql mysql = Mysql.getConnection();
		mysql.sql(SQL_SELECT + "WHERE `년도` = ? AND `학기` = ?");
		mysql.set(1, year);
		mysql.set(2, term);
		ResultSet rs = mysql.select();

		Vector<Schedule> v = new Vector<Schedule>();
		while (rs.next()) { // 일정 존재
			v.add(match(rs));
		}
		return v.toArray(new Schedule[0]);
	}

	// ## 일정 조회 (단일)
	public Schedule getSchedule(String year, String term, String name) throws IOException, SQLException, Exception {
		Mysql mysql = Mysql.getConnection();
		mysql.sql(SQL_SELECT + "WHERE `년도` = ? AND `학기` = ? AND `일정명` = ?");
		mysql.set(1, year);
		mysql.set(2, term);
		mysql.set(3, name);
		ResultSet rs = mysql.select();

		if (rs.next()) { // 일정 존재
			return match(rs);
		}
		return null;
	}
	
	// ## 일정 등록 (단일)
	public void insertSchedule(Schedule schedule) throws IOException, SQLException, Exception {
		if (schedule == null) return;
		Mysql mysql = Mysql.getConnection();
		mysql.sql("INSERT INTO `일정` (`년도`, `학기`, `일정명`, `시작시간`, `종료시간`) VALUES (?, ?, ?, ?, ?)");
		mysql.set(1, schedule.getYear());
		mysql.set(2, schedule.getTerm());
		mysql.set(3, schedule.getName());
		mysql.set(4, schedule.getStartDate().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
		mysql.set(5, schedule.getEndDate().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
		mysql.insert();
	}
	
	// ## 일정 삭제 (다중)
	public void deleteSchedules(String year, String term) throws IOException, SQLException, Exception {
		Mysql mysql = Mysql.getConnection();
		mysql.sql("DELETE FROM `일정` WHERE `년도`=? AND `학기`=?");
		mysql.set(1, year);
		mysql.set(2, term);
		mysql.delete();
	}
}
