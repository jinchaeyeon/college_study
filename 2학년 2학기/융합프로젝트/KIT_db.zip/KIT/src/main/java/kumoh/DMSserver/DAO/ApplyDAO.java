package kumoh.DMSserver.DAO;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Vector;
import kumoh.DMSserver.Mysql;
import kumoh.core.model.Apply;

public class ApplyDAO {
	public static final String SQL_SELECT = "SELECT 년도, 학기, 학번, 평점평균, 지역가산점, CAST(신청일시 AS CHAR) AS 신청일시, CAST(취소일시 AS CHAR) AS 취소일시, 1년, 1년식사, 1지망, 1지망식사, 2지망, 2지망식사, 3지망, 3지망식사, (평점평균+지역가산점) AS 점수 FROM `신청`";
	
	private ApplyDAO() {
	    }

	private static class LazyHolder {
		public static final ApplyDAO INSTANCE = new ApplyDAO();
	}

	public static ApplyDAO getInstance() {
		return LazyHolder.INSTANCE;
	}

	// ## ResultSet 결과를 객체에 담기
	public Apply match(ResultSet rs) throws IOException, SQLException, Exception {
        Apply ap = new Apply();
        ap.setYear(rs.getString("년도"));
        ap.setTerm(rs.getString("학기"));
        ap.setId(rs.getString("학번"));
        ap.setGPA(rs.getString("평점평균"));
        ap.setPoint(rs.getString("지역가산점"));
		if (rs.getString("신청일시") != null && !rs.getString("신청일시").equals("0000-00-00 00:00:00")) {
			ap.setApplyDate(LocalDateTime.parse(rs.getString("신청일시"), DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
		}
		if (rs.getString("취소일시") != null && !rs.getString("취소일시").equals("0000-00-00 00:00:00")) {
			ap.setCancelDate(LocalDateTime.parse(rs.getString("취소일시"), DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
		}
	    ap.setYearSubId(rs.getString("1년"));
        ap.setYearMeal(rs.getString("1년식사"));
        ap.setFirstSubId(rs.getString("1지망"));
        ap.setFirstMeal(rs.getString("1지망식사"));
        ap.setSecondSubId(rs.getString("2지망"));
        ap.setSecondMeal(rs.getString("2지망식사"));
        ap.setThirdSubId(rs.getString("3지망"));
        ap.setThirdMeal(rs.getString("3지망식사"));
		return ap;
	}

	// ## 신청정보 조회 (전체)
	public Apply[] getApplies(String year, String term) throws IOException, SQLException, Exception {
		Mysql mysql = Mysql.getConnection();
		mysql.sql(SQL_SELECT + "WHERE `년도` = ? AND `학기` = ? ORDER BY 점수 DESC");
		mysql.set(1, year);
		mysql.set(2, term);
		ResultSet rs = mysql.select();

		Vector<Apply> v = new Vector<Apply>();
		while (rs.next()) { // 신청 존재
			v.add(match(rs));
		}
		return v.toArray(new Apply[0]);
	}
	
	// ## 신청정보 조회 (단일)
	public Apply getApply(String year, String term, String id) throws IOException, SQLException, Exception {
		Mysql mysql = Mysql.getConnection();
		mysql.sql(SQL_SELECT + "WHERE `년도` = ? AND `학기` = ? AND `학번` = ?");
		mysql.set(1, year);
		mysql.set(2, term);
		mysql.set(3, id);
		ResultSet rs = mysql.select();

		if (rs.next()) { // 신청존재
			return match(rs);
		}
		return null;
	}
	
	// ## 신청정보 조회 (전체, 취소자는 보여주지 않음)
	public Apply[] getAppliesSet(String year, String term) throws IOException, SQLException, Exception {
		Mysql mysql = Mysql.getConnection();
		mysql.sql(SQL_SELECT + "WHERE `년도` = ? AND `학기` = ? AND `취소일시` IS NULL ORDER BY 점수 DESC");
		mysql.set(1, year);
		mysql.set(2, term);
		ResultSet rs = mysql.select();

		Vector<Apply> v = new Vector<Apply>();
		while (rs.next()) { // 신청 존재
			v.add(match(rs));
		}
		return v.toArray(new Apply[0]);
	}
	
	// ## 신청정보 등록 (단일)
	public void insertApply(Apply apply) throws IOException, SQLException, Exception {
		Mysql mysql = Mysql.getConnection();
        mysql.sql(
                "INSERT INTO `신청` (`년도`, `학기`, `학번`, `평점평균`, `지역가산점`, `신청일시`, `1년`, `1년식사`, `1지망`, `1지망식사`, `2지망`, `2지망식사`, `3지망`, `3지망식사`) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
          mysql.set(1, apply.getYear());
          mysql.set(2, apply.getTerm());
          mysql.set(3, apply.getId());
          mysql.set(4, apply.getGPA().toString());
          mysql.set(5, apply.getPoint().toString());
          mysql.set(6, apply.getApplyDate().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
          mysql.set(7, apply.getYearSubId());
          mysql.set(8, apply.getYearMeal());
          mysql.set(9, apply.getFirstSubId());
          mysql.set(10, apply.getFirstMeal());
          mysql.set(11, apply.getSecondSubId());
          mysql.set(12, apply.getSecondMeal());
          mysql.set(13, apply.getThirdSubId());
          mysql.set(14, apply.getThirdMeal());
          mysql.insert();
	}
	
	// ## 신청정보 갱신 (단일)
	public void updateApply(Apply apply) throws IOException, SQLException, Exception {
		Mysql mysql = Mysql.getConnection();
        mysql.sql("UPDATE `신청` SET 취소일시=?, 1년=?, 1년식사=?, 1지망=?, 1지망식사=?, 2지망=?, 2지망식사=?, 3지망=?, 3지망식사=? WHERE 년도=? AND 학기=? AND 학번=?");
        mysql.set(1, apply.getCancelDate().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
        mysql.set(2, apply.getYearSubId());
        mysql.set(3, apply.getYearMeal());
        mysql.set(4, apply.getFirstSubId());
        mysql.set(5, apply.getFirstMeal());
        mysql.set(6, apply.getSecondSubId());
        mysql.set(7, apply.getSecondMeal());
        mysql.set(8, apply.getThirdSubId());
        mysql.set(9, apply.getThirdMeal());
        mysql.set(10, apply.getYear());
        mysql.set(11, apply.getTerm());
        mysql.set(12, apply.getId());
        mysql.update();
	}
	
	// ## 신청정보 삭제 (단일)
	public void deleteApply(Apply apply) throws IOException, SQLException, Exception {
		Mysql mysql = Mysql.getConnection();
        mysql.sql("DELETE FROM `신청` WHERE 년도=? AND 학기=? AND 학번=?");
        mysql.set(1, apply.getYear());
        mysql.set(2, apply.getTerm());
        mysql.set(3, apply.getId());
        mysql.delete();
        
        mysql.sql("DELETE FROM `서약정보` WHERE 년도=? AND 학기=? AND 학번=?");
        mysql.set(1, apply.getYear());
        mysql.set(2, apply.getTerm());
        mysql.set(3, apply.getId());
        mysql.delete();
	}
}