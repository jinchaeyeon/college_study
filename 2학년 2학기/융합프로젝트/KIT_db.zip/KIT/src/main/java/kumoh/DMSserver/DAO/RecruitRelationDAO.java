package kumoh.DMSserver.DAO;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;
import kumoh.DMSserver.Mysql;

public class RecruitRelationDAO {
	public static final String SQL_SELECT = "SELECT * FROM `모집관계`";

	private RecruitRelationDAO() {
	}

	private static class LazyHolder {
		public static final RecruitRelationDAO INSTANCE = new RecruitRelationDAO();
	}

	public static RecruitRelationDAO getInstance() {
		return LazyHolder.INSTANCE;
	}

	// ## ResultSet 결과를 객체에 담기
	public String match(ResultSet rs) throws IOException, SQLException, Exception {
		return rs.getString("세부모집명");
	}

	// ## 모집 관계 조회 (전체)
	public String[] getRecruitRelations(String year, String term, String name)
			throws IOException, SQLException, Exception {
		Mysql mysql = Mysql.getConnection();
		mysql.sql(SQL_SELECT + "WHERE `년도` = ? AND `학기` = ? AND `모집명` = ?");
		mysql.set(1, year);
		mysql.set(2, term);
		mysql.set(3, name);
		ResultSet rs = mysql.select();

		Vector<String> v = new Vector<String>();
		while (rs.next()) { // 관계 존재
			v.add(match(rs));
		}
		return v.toArray(new String[0]);
	}
	
	// ## 모집관계 등록 (단일)
	public void insertRecruitRelation(String year, String term, String name, String str) throws IOException, SQLException, Exception {
		Mysql mysql = Mysql.getConnection();
		mysql.sql("INSERT INTO 모집관계 (`년도`, `학기`, `모집명`, `세부모집명`) VALUES (?, ?, ?, ?)");
		mysql.set(1, year);
		mysql.set(2, term);
		mysql.set(3, name);
		mysql.set(4, str);
		mysql.insert();
	}
	
	// ## 모집관계 삭제 (다중)
	public void deleteRecruitRelations(String year, String term, String name) throws IOException, SQLException, Exception {
		Mysql mysql = Mysql.getConnection();
		mysql.sql("DELETE FROM `모집관계` WHERE `년도`=? AND `학기`=? AND `모집명`=?");
		mysql.set(1, year);
		mysql.set(2, term);
		mysql.set(3, name);
		mysql.delete();
	}
}