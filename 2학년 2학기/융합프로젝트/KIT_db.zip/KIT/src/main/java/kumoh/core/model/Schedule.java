package kumoh.core.model;

import java.io.Serializable;
import java.time.LocalDateTime;

public class Schedule implements Serializable {
	private static final long serialVersionUID = 1L;

	private String year;
	private String term;
	private String name;
	private LocalDateTime startDate;
	private LocalDateTime endDate;

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public String getTerm() {
		return term;
	}

	public void setTerm(String term) {
		this.term = term;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public LocalDateTime getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDateTime startDate) {
		this.startDate = startDate;
	}

	public LocalDateTime getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDateTime endDate) {
		this.endDate = endDate;
	}

	@Override
	public String toString() {
		return this.getName();
	}
}