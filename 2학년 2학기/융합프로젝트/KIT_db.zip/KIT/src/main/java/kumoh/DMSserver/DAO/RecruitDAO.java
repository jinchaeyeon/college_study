package kumoh.DMSserver.DAO;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Vector;
import kumoh.DMSserver.Mysql;
import kumoh.core.model.Recruit;

public class RecruitDAO {
	public static final String SQL_SELECT = "SELECT 년도, 학기, 모집명, 모집성별, 1년기숙여부, 사용료, CAST(입사시작일 AS CHAR) AS 입사시작일, CAST(입사종료일 AS CHAR) AS 입사종료일 FROM `모집`";

	private RecruitDAO() {
	}

	private static class LazyHolder {
		public static final RecruitDAO INSTANCE = new RecruitDAO();
	}

	public static RecruitDAO getInstance() {
		return LazyHolder.INSTANCE;
	}

	// ## ResultSet 결과를 객체에 담기
	public Recruit match(ResultSet rsRecruit) throws IOException, SQLException, Exception {
		Recruit recruit = new Recruit();
		recruit.setYear(rsRecruit.getString("년도"));
		recruit.setTerm(rsRecruit.getString("학기"));
		recruit.setName(rsRecruit.getString("모집명"));
		recruit.setRecruitSex(rsRecruit.getString("모집성별"));
		recruit.setRecruitYear(rsRecruit.getString("1년기숙여부"));
		recruit.setFee(rsRecruit.getInt("사용료"));
		if (rsRecruit.getString("입사시작일") != null && !rsRecruit.getString("입사시작일").equals("0000-00-00"))
			recruit.setStart(LocalDate.parse(rsRecruit.getString("입사시작일"), DateTimeFormatter.ofPattern("yyyy-MM-dd")));
		if (rsRecruit.getString("입사종료일") != null && !rsRecruit.getString("입사종료일").equals("0000-00-00"))
			recruit.setEnd(LocalDate.parse(rsRecruit.getString("입사종료일"), DateTimeFormatter.ofPattern("yyyy-MM-dd")));

		return recruit;
	}

	// ## 모집 조회 (전체)
	public Recruit[] getRecruits(String year, String term) throws IOException, SQLException, Exception {
		Mysql mysql = Mysql.getConnection();
		mysql.sql(SQL_SELECT + "WHERE `년도` = ? AND `학기` = ?");
		mysql.set(1, year);
		mysql.set(2, term);
		ResultSet rs = mysql.select();

		Vector<Recruit> v = new Vector<Recruit>();
		while (rs.next()) { // 세부모집 존재
			v.add(match(rs));
		}
		return v.toArray(new Recruit[0]);
	}

	// ## 모집 조회 (단일)
	public Recruit getRecruit(String year, String term, String name) throws IOException, SQLException, Exception {
		Mysql mysql = Mysql.getConnection();
		mysql.sql(SQL_SELECT + "WHERE `년도` = ? AND `학기` = ? AND `모집명` = ?");
		mysql.set(1, year);
		mysql.set(2, term);
		mysql.set(3, name);
		ResultSet rs = mysql.select();

		if (rs.next()) { // 세부모집 존재
			return match(rs);
		}
		return null;
	}

	// ## 모집 등록 (단일)
	public void insertRecruit(Recruit recruit) throws IOException, SQLException, Exception {
		if (recruit == null) return;
		Mysql mysql = Mysql.getConnection();
		mysql.sql(
				"INSERT INTO 모집 (`년도`, `학기`, `모집명`, `모집성별`, `1년기숙여부`, `사용료`) VALUES (?, ?, ?, ?, ?, ?)");
		mysql.set(1, recruit.getYear());
		mysql.set(2, recruit.getTerm());
		mysql.set(3, recruit.getName());
		mysql.set(4, recruit.getRecruitSex());
		mysql.set(5, recruit.getRecruitYear());
		mysql.set(6, recruit.getFee().toString());
		mysql.insert();
	}

	// ## 모집 갱신 (단일)
	public void updateRecruit(Recruit recruit) throws IOException, SQLException, Exception {
		Mysql mysql = Mysql.getConnection();
		mysql.sql("UPDATE 모집 SET `모집성별` = ?, `1년기숙여부` = ?, `사용료` = ? WHERE `년도` = ? AND `학기` = ? AND `모집명` = ?");
		mysql.set(1, recruit.getRecruitSex());
		mysql.set(2, recruit.getRecruitYear());
		mysql.set(3, recruit.getFee().toString());
		mysql.set(4, recruit.getYear());
		mysql.set(5, recruit.getTerm());
		mysql.set(6, recruit.getName());
		mysql.update();
	}
	
	// ## 모집 삭제 (다중)
	public void deleteRecruits(String year, String term) throws IOException, SQLException, Exception {
		Mysql mysql = Mysql.getConnection();
		mysql.sql("DELETE FROM `모집` WHERE `년도`=? AND `학기`=?");
		mysql.set(1, year);
		mysql.set(2, term);
		mysql.delete();
	}
}