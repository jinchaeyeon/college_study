package kumoh.DMSserver.DAO;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;
import kumoh.DMSserver.Mysql;
import kumoh.core.model.SubRecruit;

public class SubRecruitDAO {
	public static final String SQL_SELECT = "SELECT * FROM `세부모집`";
	public static final String SQL_INSERT = "INSERT INTO 세부모집 VALUES (?, ?)";
	public static final String SQL_UPDATE = "UPDATE 세부모집 SET `가용여부` = ? WHERE `세부모집명` = ?";
	
	private SubRecruitDAO() {
	}

	private static class LazyHolder {
		public static final SubRecruitDAO INSTANCE = new SubRecruitDAO();
	}

	public static SubRecruitDAO getInstance() {
		return LazyHolder.INSTANCE;
	}
	
	// ## ResultSet 결과를 객체에 담기
	public SubRecruit match(ResultSet rs) throws IOException, SQLException, Exception {
		SubRecruit sre = new SubRecruit();
		sre.setName(rs.getString("세부모집명"));
		sre.setValid(rs.getString("가용여부"));
		return sre;
	}
	
	// ## 세부모집 조회 (전체)
	public SubRecruit[] getSubRecruits() throws IOException, SQLException, Exception {
		Mysql mysql = Mysql.getConnection();
		mysql.sql(SQL_SELECT);
		ResultSet rs = mysql.select();

		Vector<SubRecruit> v = new Vector<SubRecruit>();
		while (rs.next()) { // 세부모집 존재
			v.add(match(rs));
		}
		return v.toArray(new SubRecruit[0]);
	}

	// ## 세부모집 조회 (단일)
	public SubRecruit getSubRecruit(String name) throws IOException, SQLException, Exception {
		Mysql mysql = Mysql.getConnection();
		mysql.sql(SQL_SELECT + "WHERE `세부모집명` = ?");
		mysql.set(1, name);
		ResultSet rs = mysql.select();

		if (rs.next()) { // 세부모집 존재
			return match(rs);
		}
		return null;
	}
	
	// ## 세부모집 등록 (단일)
	public void insertSubRecruit(SubRecruit sre) throws IOException, SQLException, Exception {
		Mysql mysql = Mysql.getConnection();
		mysql.sql("INSERT INTO 세부모집 VALUES (?, ?)");
		mysql.set(1, sre.getName());
		mysql.set(2, sre.getValid());
		mysql.insert();
	}
	
	// ## 세부모집 갱신 (단일)
	public void updateSubRecruit(SubRecruit sre) throws IOException, SQLException, Exception {
		Mysql mysql = Mysql.getConnection();
		mysql.sql("UPDATE 세부모집 SET `가용여부` = ? WHERE `세부모집명` = ?");
		mysql.set(1, sre.getValid());
		mysql.set(2, sre.getName());
		mysql.update();
	}

}
