package kumoh.DMSserver.DAO;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;
import kumoh.DMSserver.Mysql;
import kumoh.core.model.Meal;

public class MealDAO {
	public static final String SQL_SELECT = "SELECT * FROM `식사`";

	private MealDAO() {
	}

	private static class LazyHolder {
		public static final MealDAO INSTANCE = new MealDAO();
	}

	public static MealDAO getInstance() {
		return LazyHolder.INSTANCE;
	}

	// ## ResultSet 결과를 객체에 담기
	public Meal match(ResultSet rsMeal) throws IOException, SQLException, Exception {
		Meal meal = new Meal();
		meal.setYear(rsMeal.getString("년도"));
		meal.setTerm(rsMeal.getString("학기"));
		meal.setRecruit(rsMeal.getString("모집명"));
		meal.setMealType(rsMeal.getString("식사구분"));
		meal.setMealFee(Integer.parseInt(rsMeal.getString("식사비용")));

		return meal;
	}

	// ## 식사정보 조회 (전체)
	public Meal[] getMeals(String year, String term, String name) throws IOException, SQLException, Exception {
		Mysql mysql = Mysql.getConnection();
		mysql.sql(SQL_SELECT + "WHERE `년도` = ? AND `학기` = ? AND `모집명` = ?");
		mysql.set(1, year);
		mysql.set(2, term);
		mysql.set(3, name);
		ResultSet rs = mysql.select();

		Vector<Meal> v = new Vector<Meal>();
		while (rs.next()) { // 관계 존재
			v.add(match(rs));
		}
		return v.toArray(new Meal[0]);
	}
	
	// ## 식사정보 등록 (단일)
	public void insertMeal(Meal meal) throws IOException, SQLException, Exception {
		Mysql mysql = Mysql.getConnection();
		mysql.sql("INSERT INTO 식사 (`년도`, `학기`, `모집명`, `식사구분`, `식사비용`) VALUES (?, ?, ?, ?, ?)");
		mysql.set(1, meal.getYear());
		mysql.set(2, meal.getTerm());
		mysql.set(3, meal.getRecruit());
		mysql.set(4, meal.getMealType());
		mysql.set(5, meal.getMealFee().toString());
		mysql.insert();
	}
	
	// ## 식사 삭제 (다중)
	public void deleteMeals(String year, String term, String name) throws IOException, SQLException, Exception {
		Mysql mysql = Mysql.getConnection();
		mysql.sql("DELETE FROM `식사` WHERE `년도`=? AND `학기`=? AND `모집명`=?");
		mysql.set(1, year);
		mysql.set(2, term);
		mysql.set(3, name);
		mysql.delete();
	}
}