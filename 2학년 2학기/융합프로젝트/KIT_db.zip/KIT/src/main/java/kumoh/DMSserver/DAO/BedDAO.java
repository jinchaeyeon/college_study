package kumoh.DMSserver.DAO;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;
import kumoh.DMSserver.Mysql;
import kumoh.core.model.Bed;

public class BedDAO {
	public static final String SQL_SELECT = "SELECT * FROM `입실단위`";

	private BedDAO() {
    }

	private static class LazyHolder {
		public static final BedDAO INSTANCE = new BedDAO();
	}

	public static BedDAO getInstance() {
		return LazyHolder.INSTANCE;
	}

	// ## ResultSet 결과를 객체에 담기
	public Bed match(ResultSet rs) throws IOException, SQLException, Exception {
		Bed bed = new Bed();
		bed.setSubRecruit(rs.getString("세부모집명"));
		bed.setRoomNum(rs.getInt("호실번호"));
		bed.setBedNum(rs.getString("침대코드"));
		bed.setValid(rs.getString("가용여부"));
		return bed;
	}

	// ## 입실단위 조회 (전체)
	public Bed[] getBeds(String name) throws IOException, SQLException, Exception {
		Mysql mysql = Mysql.getConnection();
		mysql.sql(SQL_SELECT + "WHERE `세부모집명` = ?");
		mysql.set(1, name);
		ResultSet rs = mysql.select();

		Vector<Bed> v = new Vector<Bed>();
		while (rs.next()) { // 입실단위 존재
			v.add(match(rs));
		}
		return v.toArray(new Bed[0]);
	}
	
	// ## 입실단위 등록 (단일)
	public void insertBed(Bed bed) throws IOException, SQLException, Exception {
		Mysql mysql = Mysql.getConnection();
		mysql.sql("INSERT INTO `입실단위` (`세부모집명`, `호실번호`, `침대코드`, `가용여부`) VALUES (?, ?, ?, ?)");
		mysql.set(1, bed.getSubRecruit());
		mysql.set(2, bed.getRoomNum().toString());
		mysql.set(3, bed.getBedNum());
		mysql.set(4, bed.getValid());
		mysql.insert();
	}

	// ## 입실단위 갱신 (단일)
	public void updateBed(Bed bed) throws IOException, SQLException, Exception {
		Mysql mysql = Mysql.getConnection();
		mysql.sql("UPDATE 입실단위 SET `가용여부` = ? WHERE `세부모집명`= ? AND `호실번호`= ? AND `침대코드`= ?");
		mysql.set(1, bed.getValid());
		mysql.set(2, bed.getSubRecruit());
		mysql.set(3, bed.getRoomNum().toString());
		mysql.set(4, bed.getBedNum());
		mysql.update();
	}
	
	// ## 입실단위 삭제 (다중)
	public void deleteBeds(String name) throws IOException, SQLException, Exception {
		Mysql mysql = Mysql.getConnection();
		mysql.sql("DELETE FROM `입실단위` WHERE 세부모집명=?");
		mysql.set(1, name);
		mysql.delete();
	}
}
