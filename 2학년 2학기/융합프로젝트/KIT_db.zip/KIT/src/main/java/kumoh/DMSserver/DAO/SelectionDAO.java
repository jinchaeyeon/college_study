package kumoh.DMSserver.DAO;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Vector;
import kumoh.DMSserver.Mysql;
import kumoh.core.model.Selection;

public class SelectionDAO {
	public static final String SQL_SELECT = "SELECT 년도, 학기, 학번, 신청구분, 세부모집명, 식사구분, CAST(납부일시 AS CHAR) AS 납부일시, CAST(제출일시 AS CHAR) AS 제출일시, 제출확인, 제출파일, 선발유효, 호실번호, 침대번호 FROM `선발`";

	private SelectionDAO() {
	}

	private static class LazyHolder {
		public static final SelectionDAO INSTANCE = new SelectionDAO();
	}

	public static SelectionDAO getInstance() {
		return LazyHolder.INSTANCE;
	}

	// ## ResultSet 결과를 객체에 담기
	public Selection match(ResultSet rs) throws IOException, SQLException, Exception {
		Selection s = new Selection();
		s.setYear(rs.getString("년도"));
		s.setTerm(rs.getString("학기"));
		s.setId(rs.getString("학번"));
		s.setDiv(rs.getString("신청구분"));
		s.setSubRecruit(rs.getString("세부모집명"));
		s.setMeal(rs.getString("식사구분"));
		if (rs.getString("납부일시") != null && !rs.getString("납부일시").contains("0000-00-00 00:00:00")) 
			s.setDepositDate(
					LocalDateTime.parse(rs.getString("납부일시"), DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
		if (rs.getString("제출일시") != null && !rs.getString("제출일시").contains("0000-00-00 00:00:00"))
			s.setUploadDate(
					LocalDateTime.parse(rs.getString("제출일시"), DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
		s.setUploaded(rs.getString("제출확인"));
		s.setUploadUrl(rs.getString("제출파일"));
		s.setValided(rs.getString("선발유효"));
		s.setRoomNum(rs.getInt("호실번호"));
		s.setRoomBed(rs.getString("침대번호"));
		return s;
	}

	// ## 선발정보 조회 (전체)
	public Selection[] getSelections(String year, String term) throws IOException, SQLException, Exception {
		Mysql mysql = Mysql.getConnection();
		mysql.sql(SQL_SELECT + "WHERE `년도` = ? AND `학기` = ?");
		mysql.set(1, year);
		mysql.set(2, term);
		ResultSet rs = mysql.select();

		Vector<Selection> v = new Vector<Selection>();
		while (rs.next()) { // 선발 존재
			v.add(match(rs));
		}
		return v.toArray(new Selection[0]);
	}
	
	// ## 선발정보 조회 (단일)
	public Selection getSelection(String year, String term, String id) throws IOException, SQLException, Exception {
		Mysql mysql = Mysql.getConnection();
		mysql.sql(SQL_SELECT + "WHERE `년도` = ? AND `학기` = ? AND `학번` = ?");
		mysql.set(1, year);
		mysql.set(2, term);
		mysql.set(3, id);
		ResultSet rs = mysql.select();

		if (rs.next()) { // 선발 존재
			return match(rs);
		}
		return null;
	}
	
	// ## 선발정보 등록 (단일)
	public void insertSelection(Selection selection) throws IOException, SQLException, Exception {
		Mysql mysql = Mysql.getConnection();
		
        mysql.sql("INSERT INTO `선발`(`년도`, `학기`, `학번`, `신청구분`, `세부모집명`, `식사구분`, `선발유효`) VALUES (?, ?, ?, ?, ?, ?, ?)");
          mysql.set(1, selection.getYear());
          mysql.set(2, selection.getTerm());
          mysql.set(3, selection.getId());
          mysql.set(4, selection.getDiv());
          mysql.set(5, selection.getSubRecruit());
          mysql.set(6, selection.getMeal());
          mysql.set(7, selection.getValided());
          mysql.insert();
          
	}
	
	// ## 선발정보 갱신 (단일)
	public void updateSelection(Selection selection) throws IOException, SQLException, Exception {
		
	}
}